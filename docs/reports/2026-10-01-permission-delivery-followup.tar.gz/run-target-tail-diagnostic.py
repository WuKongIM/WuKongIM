import os,subprocess,json,hashlib,time,datetime,tempfile,tomllib,urllib.request,urllib.parse
from pathlib import Path
root=Path('/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM');a=root/'tmp/issue-977-sequential-20261001';w=root/'.worktrees/issue-977-permission-baseline'
binary=a/'wukongim-runtime-final-source-bound';probe=root/'tmp/issue-977-request-timeline-20260930/permission-cpu-darwin';target='two-slots-one-remote-leader-c1-038'
rule=[{'client_msg_no':target,'sample_rate':1,'ttl_seconds':120}]
plan={'purpose':'Preserve the full four-placement prefix, add only one exact-client-number debug sampling rule, query only that completed SEND after the two-Slot case. Diagnostic only, not acceptance replacement.','driver_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'runtime_revision':'ec21c1a586941ffd74cfb497f0da4522941bc1a4','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'target':target,'runtime_env_override':{'WK_DIAGNOSTICS_DEBUG_MATCHES':rule},'query_bounds':{'requests':3,'seconds_each':2,'bytes_each':65536,'events_each':32},'profiles':False,'gctrace':False,'observer':'50-ms host poll of only owned temporary configs/test progress; overhead unqualified','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert not (a/'target-tail-diagnostic-plan.json').exists();(a/'target-tail-diagnostic-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
tmp=Path(tempfile.mkdtemp(prefix='wktail-',dir='/tmp'));env={k:v for k,v in os.environ.items() if not k.startswith('WK_E2E_') and not k.lower().endswith('_proxy') and k!='GODEBUG'}
env.update(GOWORK='off',GOMAXPROCS='4',GOMODCACHE=str(root/'tmp/issue-977-permission-baseline-20260930/modcache'),TMPDIR=str(tmp),WK_E2E_BINARY=str(binary),WK_E2E_PERMISSION_CPU_PROBE=str(probe),WK_E2E_PERMISSION_COHORTS='1',WK_E2E_PERMISSION_COHORT_REPORT=str(a/'target-tail-new.json'),WK_DIAGNOSTICS_DEBUG_MATCHES=json.dumps(rule))
cmd=['go','test','-tags=e2e','./test/e2e/message/send_ban','-run','^TestPermissionCallerCohorts$','-count=1','-timeout=4m','-p=1','-v'];queried=False;configs=[];replies=[];start=time.monotonic();opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def unsafe(v):
 if isinstance(v,dict):return any(k.lower() in ['from_uid','payload','token'] or unsafe(x) for k,x in v.items())
 if isinstance(v,list):return any(unsafe(x) for x in v)
 return False
logpath=a/'target-tail-new.log'
with logpath.open('w') as log:
 child=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
 while child.poll() is None:
  if time.monotonic()-start>270:child.terminate();raise RuntimeError('bounded diagnostic exceeded deadline')
  if not configs:
   for f in tmp.glob('TestPermissionCaller*/*/node*/wukongim.toml'):
    try:data=f.read_bytes()
    except FileNotFoundError:continue
    cfg=tomllib.loads(data.decode());addr=cfg['api']['listen_addr'];assert addr.startswith('127.0.0.1:')
    configs.append({'node_id':cfg['node']['id'],'api_addr':addr,'config_sha256':hashlib.sha256(data).hexdigest()})
   if len(configs)!=3:configs=[]
  if not queried and len(configs)==3 and '=== RUN   TestPermissionCallerCohorts/two-remote-leaders' in logpath.read_text():
   queried=True
   for c in sorted(configs,key=lambda c:c['node_id']):
    reply={'node_id':c['node_id'],'queried_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
     url='http://'+c['api_addr']+'/debug/diagnostics/message?'+urllib.parse.urlencode({'client_msg_no':target,'limit':32})
     with opener.open(url,timeout=2) as r:
      assert r.status==200;data=r.read(65537);assert len(data)<=65536
     value=json.loads(data);assert not unsafe(value) and value['node_id']==c['node_id'] and len(value['events'])<32
     assert all(e.get('client_msg_no')==target and e.get('duration',0)>=0 for e in value['events']);reply['reply']=value
    except Exception as e:reply['error_type']=type(e).__name__
    replies.append(reply);(a/'target-tail-timelines.json').write_text(json.dumps(replies,indent=2)+'\n')
  time.sleep(.05)
 code=child.wait()
result={'exit_code':code,'command':cmd,'owned_tmpdir':str(tmp),'configs':configs,'queries_executed':len(replies),'query_errors':[r for r in replies if 'error_type' in r],'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(a/'target-tail-diagnostic-execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
