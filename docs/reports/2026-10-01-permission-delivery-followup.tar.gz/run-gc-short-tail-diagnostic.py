import os,subprocess,json,hashlib,time,datetime,tempfile
from pathlib import Path
root=Path('/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM')
a=root/'tmp/issue-977-sequential-20261001';w=root/'.worktrees/issue-977-permission-baseline'
paths={'old':root/'tmp/issue-977-permission-baseline-20260930/wukongim-424d03eb2','new':a/'wukongim-runtime-final-source-bound'}
probe=root/'tmp/issue-977-request-timeline-20260930/permission-cpu-darwin'
plan={'purpose':'Test whether the deterministic c1-038 tail overlaps a Go GC event; diagnostic only, not a replacement/retry of any comparative qualification','order':['old','new'],'driver_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'godebug':'gctrace=1','observer':'owned TMPDIR only, <=64 KiB stderr per node, 50-ms host poll; observer and GC output overhead unqualified','timeline':False,'profiles':False,'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in paths.items()},'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert not (a/'gc-short-tail-diagnostic-plan.json').exists()
(a/'gc-short-tail-diagnostic-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
rows=[]
for side in plan['order']:
 tmp=Path(tempfile.mkdtemp(prefix='wkgc-'+side+'-',dir='/tmp'))
 env={k:v for k,v in os.environ.items() if not k.startswith('WK_E2E_') and not k.lower().endswith('_proxy')}
 env.update(GOWORK='off',GOMAXPROCS='4',GOMODCACHE=str(root/'tmp/issue-977-permission-baseline-20260930/modcache'),GODEBUG='gctrace=1',TMPDIR=str(tmp),WK_E2E_BINARY=str(paths[side]),WK_E2E_PERMISSION_CPU_PROBE=str(probe))
 env.update({'WK_E2E_PERMISSION_BASELINE' if side=='old' else 'WK_E2E_PERMISSION_COHORTS':'1','WK_E2E_PERMISSION_BASELINE_REPORT' if side=='old' else 'WK_E2E_PERMISSION_COHORT_REPORT':str(a/('gc-short-tail-'+side+'.json'))})
 cmd=['go','test','-tags=e2e','./test/e2e/message/send_ban','-run','^TestPermissionCaller'+('Baseline' if side=='old' else 'Cohorts')+'$','-count=1','-timeout=4m','-p=1','-v']
 captures={};start=time.monotonic()
 with (a/('gc-short-tail-'+side+'.log')).open('w') as log:
  child=subprocess.Popen(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
  while child.poll() is None:
   if time.monotonic()-start>270:child.terminate();raise RuntimeError('bounded diagnostic child exceeded deadline')
   for f in tmp.glob('TestPermissionCaller*/*/node*/stderr.log'):
    try: data=f.read_bytes()
    except FileNotFoundError: continue
    assert len(data)<=65536
    output=a/('gc-short-tail-'+side+'-'+f.parent.name+'-stderr.log');output.write_bytes(data)
    captures[str(f)]=dict(path=output.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
   time.sleep(.05)
  code=child.wait()
 rows.append({'side':side,'exit_code':code,'command':cmd,'captured_logs':list(captures.values()),'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owned_tmpdir':str(tmp)})
 (a/'gc-short-tail-diagnostic-execution.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
