"""Independently replay the bounded diagnosis and unchanged red acceptance."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile


def verify(archive):
    with tempfile.TemporaryDirectory(prefix="permission-sequential-replay-") as directory:
        root = Path(directory)
        with tarfile.open(archive, "r:gz") as t:
            names = set()
            members = t.getmembers()
            assert len(members) <= 250
            for m in members:
                p = Path(m.name)
                assert m.isfile() and not p.is_absolute() and ".." not in p.parts and m.name not in names
                names.add(m.name)
                assert 0 <= m.size <= 100 << 20
            manifest = json.load(t.extractfile("MANIFEST.json"))
            assert names == set(manifest["files"]) | {"MANIFEST.json"}
            for m in members:
                raw = t.extractfile(m).read()
                if m.name != "MANIFEST.json":
                    record = manifest["files"][m.name]
                    assert len(raw) == record["bytes"] and hashlib.sha256(raw).hexdigest() == record["sha256"]
                p = root / m.name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(raw)
        expected = {f: (root / f).read_bytes() for f in ["diagnosis.json", "cpu-breakdown.json", "original/reviewed-pair-verdict.json"]}
        for script in ["analyze-diagnostics.py", "derive-cpu.py"]:
            run = subprocess.run([sys.executable, str(root / script)], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
            assert run.returncode == 0, run.stdout
        run = subprocess.run([sys.executable, str(root / "original/verify-reviewed-pairs.py")], cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=30)
        assert run.returncode == 1, run.stdout
        verdict = json.loads((root / "original/reviewed-pair-verdict.json").read_text())
        assert len(verdict["sequential_over_threshold"]) == 6 and verdict["burst_gate_passed"] and not verdict["all_performance_gates_passed"]
        for f, before in expected.items():
            assert (root / f).read_bytes() == before, "replay drift: " + f
        return {"archive": Path(archive).name, "verified_members": len(members), "diagnostic_replay": "pass",
                "native_tick_controls": 6, "diagnostic_corruption_controls": 10, "original_performance_exit": 1,
                "original_sequential_rejects": 6, "original_burst_passes": 12}


if __name__ == "__main__":
    print(json.dumps(verify(sys.argv[1]), indent=2))
