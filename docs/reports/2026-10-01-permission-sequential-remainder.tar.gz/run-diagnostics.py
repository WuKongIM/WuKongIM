import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "issue-977-darwin-sync-20261001"
REPO = ROOT.parent.parent
DRIVER = REPO / ".worktrees/issue-977-remaining-driver"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

assert not (ROOT / "diagnostic-execution.json").exists(), "never replace observations"
plan = json.loads((ROOT / "diagnostic-plan.json").read_text())
assert not subprocess.check_output(["git", "-C", str(DRIVER), "status", "--porcelain"], text=True)
plan["driver_revision"] = subprocess.check_output(["git", "-C", str(DRIVER), "rev-parse", "HEAD"], text=True).strip()
plan["driver_binary_sha256"] = sha(ROOT / "permission-driver")
plan["runner_sha256"] = sha(Path(__file__))
plan["driver_sources"] = {str(p.relative_to(DRIVER)): sha(p) for p in sorted((DRIVER / "test/e2e/message/send_ban").glob("permission*go"))}
for side in ("old", "new"):
    assert sha(Path(plan["binaries"][side]["path"])) == plan["binaries"][side]["sha256"]
assert sha(SOURCE / "permission-cpu-darwin") == plan["probe_sha256"]
(ROOT / "diagnostic-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
env_base = {k: v for k, v in os.environ.items() if not k.startswith("WK_E2E_")}
env_base.update(GOMAXPROCS="4", GOTOOLCHAIN="local", GOWORK="off", WK_E2E_PERMISSION_CPU_PROBE=str(SOURCE / "permission-cpu-darwin"))
with (ROOT / "probe-calibration.log").open("x") as log:
    subprocess.run([str(ROOT / "permission-driver"), "-test.run", "^TestPermissionCPUProbeCalibration$", "-test.count=1", "-test.v"], cwd=DRIVER, env=env_base, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=30)
executions = []
for label in plan["fixed_order"]:
    side = label.split("-")[0]
    env = dict(env_base)
    env.update(WK_E2E_PERMISSION_PREFIX_DIAGNOSTICS="1", WK_E2E_BINARY=plan["binaries"][side]["path"])
    if side == "new":
        env.update(WK_E2E_PERMISSION_COHORTS="1", WK_E2E_PERMISSION_COHORT_REPORT=str(ROOT / (label + ".json")))
    else:
        env.update(WK_E2E_PERMISSION_BASELINE="1", WK_E2E_PERMISSION_BASELINE_REPORT=str(ROOT / (label + ".json")))
    if "profile" in label:
        env["WK_E2E_PERMISSION_SEQUENTIAL_PROFILES"] = "1"
        if label.endswith("-sampler") and not label.endswith("-no-sampler"):
            env["WK_E2E_PERMISSION_PROFILE_OWNERSHIP"] = "1"
    else:
        env["WK_E2E_PERMISSION_TIMELINE_SEQUENTIAL"] = "1"
    command = [str(ROOT / "permission-driver"), "-test.run", "^TestPermissionSequentialPrefixDiagnostics$", "-test.count=1", "-test.timeout=4m", "-test.v"]
    started = now()
    with (ROOT / (label + ".log")).open("x") as log:
        run = subprocess.run(command, cwd=DRIVER, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=255)
    executions.append({"label": label, "started_at": started, "finished_at": now(), "exit_code": run.returncode, "command": command,
                       "report": label + ".json", "expected_exit_code": 1 if label == "old-timeline-negative-control" else 0})
    (ROOT / "diagnostic-execution.json").write_text(json.dumps(executions, indent=2) + "\n")
    print(label, "exit", run.returncode, flush=True)
    # Preserve an unexpected failure without retrying or replacing any window.
    if run.returncode != executions[-1]["expected_exit_code"]:
        raise SystemExit(run.returncode or 1)
