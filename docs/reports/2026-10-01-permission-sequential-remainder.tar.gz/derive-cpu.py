"""Offline diagnosis; retains every original window and checks native identity."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "original"


def derive(report):
    pids = report["cpu_node_pids_in_id_order"]
    assert len(pids) == len(set(pids)) == 3 and all(p > 0 for p in pids)
    rows = []
    assert len(report["cases"]) == 4
    for case in report["cases"]:
        assert len(case["windows"]) == 2
        for w in case["windows"]:
            b, a = w["cpu_before"], w["cpu_after"]
            numer, denom = b["timebase_numer"], b["timebase_denom"]
            assert numer > 0 and denom > 0
            assert (numer, denom) == (a["timebase_numer"], a["timebase_denom"])
            assert b["started_monotonic_ns"] <= b["finished_monotonic_ns"] <= a["started_monotonic_ns"] <= a["finished_monotonic_ns"]
            assert len(b["processes"]) == len(a["processes"]) == 3
            nodes = []
            for i, (bp, ap) in enumerate(zip(b["processes"], a["processes"])):
                assert bp["pid"] == ap["pid"] == pids[i]
                assert bp["start_abstime"] == ap["start_abstime"] > 0
                for cut, proc in ((b, bp), (a, ap)):
                    assert cut["started_monotonic_ns"] <= proc["sampled_monotonic_ns"] <= cut["finished_monotonic_ns"]
                user, system = ap["user_ticks"] - bp["user_ticks"], ap["system_ticks"] - bp["system_ticks"]
                assert user >= 0 and system >= 0
                nodes.append({"node_id": i + 1, "pid": pids[i], "start_abstime": bp["start_abstime"],
                              "user_ticks_delta": user, "system_ticks_delta": system,
                              "user_cpu_ns": user * numer / denom, "system_cpu_ns": system * numer / denom,
                              "total_cpu_ns": (user + system) * numer / denom,
                              "native_cut_elapsed_ns": ap["sampled_monotonic_ns"] - bp["sampled_monotonic_ns"]})
            total = sum(n["total_cpu_ns"] for n in nodes)
            assert abs(total - w["cluster_cpu_ns"]) <= 0.5
            assert w["completed"] and len(w["acks"]) == 64
            rows.append({"placement": case["name"], "concurrency": w["concurrency"], "ingress": case["ingress"],
                         "user_slot_leader": case["user_slot"]["runtime"]["leader_id"],
                         "channel_slot_leader": case["channel_slot"]["runtime"]["leader_id"],
                         "channel_leader": case["channel_runtime"]["leader"],
                         "sendack_p99_us": w["sendack_p99_us"], "elapsed_ms": w["elapsed_ms"],
                         "cluster_cpu_ns": total, "nodes": nodes})
    return rows


def main():
    plan = json.loads((ROOT / "cpu-derivation-plan.json").read_text())
    reports = {}
    out = {"scope": plan["scope"], "scope_limit": "Whole-node integral encloses workload and probe overhead; node roles do not establish causality or per-request CPU.",
           "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "reports": {}, "controls": []}
    for filename, expected in plan["inputs"].items():
        raw = (SOURCE / filename).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == expected
        reports[filename] = json.loads(raw)
        out["reports"][filename] = derive(reports[filename])
    sample = next(iter(reports.values()))
    mutations = {
        "reordered_pid": lambda d: d["cpu_node_pids_in_id_order"].reverse(),
        "reused_process": lambda d: d["cases"][0]["windows"][0]["cpu_after"]["processes"][0].update(start_abstime=1),
        "tick_regression": lambda d: d["cases"][0]["windows"][0]["cpu_after"]["processes"][0].update(user_ticks=0),
        "changed_timebase": lambda d: d["cases"][0]["windows"][0]["cpu_after"].update(timebase_denom=1),
        "sample_outside_cut": lambda d: d["cases"][0]["windows"][0]["cpu_after"]["processes"][0].update(sampled_monotonic_ns=1),
        "inconsistent_integral": lambda d: d["cases"][0]["windows"][0].update(cluster_cpu_ns=1),
    }
    for name, mutate in mutations.items():
        corrupted = copy.deepcopy(sample)
        mutate(corrupted)
        try:
            derive(corrupted)
        except AssertionError:
            out["controls"].append({"mutation": name, "rejected": True})
        else:
            raise AssertionError("Accepted corruption: " + name)
    (ROOT / "cpu-breakdown.json").write_text(json.dumps(out, indent=2) + "\n")
    print("Validated 48 windows and rejected six corruptions; CPU deltas below are milliseconds.")
    print("pair placement oldTotal newTotal | n1 delta(user,sys) | n2 delta(user,sys) | n3 delta(user,sys)")
    for pair in range(1, 4):
        old = out["reports"][f"old-reviewed-pair-{pair}.json"]
        new = out["reports"][f"new-reviewed-pair-{pair}.json"]
        for b, a in zip(old, new):
            assert (b["placement"], b["concurrency"]) == (a["placement"], a["concurrency"])
            if b["concurrency"] != 1:
                continue
            delta = [f'{(an["total_cpu_ns"]-bn["total_cpu_ns"])/1e6:+.2f}({(an["user_cpu_ns"]-bn["user_cpu_ns"])/1e6:+.2f},{(an["system_cpu_ns"]-bn["system_cpu_ns"])/1e6:+.2f})' for bn, an in zip(b["nodes"], a["nodes"])]
            print(pair, b["placement"], round(b["cluster_cpu_ns"]/1e6,2), round(a["cluster_cpu_ns"]/1e6,2), " | ".join(delta))


if __name__ == "__main__":
    main()
