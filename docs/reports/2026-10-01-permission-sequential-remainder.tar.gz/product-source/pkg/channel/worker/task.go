package worker

import (
	"context"
	"sync"
	"time"

	ch "github.com/WuKongIM/WuKongIM/pkg/channel"
	"github.com/WuKongIM/WuKongIM/pkg/channel/replication"
	"github.com/WuKongIM/WuKongIM/pkg/channel/store"
	"github.com/WuKongIM/WuKongIM/pkg/channel/transport"
	goruntimeregistry "github.com/WuKongIM/WuKongIM/pkg/goroutine"
)

// TaskKind identifies one blocking work category.
type TaskKind uint8

const (
	TaskFunc TaskKind = iota + 1
	TaskStoreAppend
	TaskStoreLoad
	TaskStoreApply
	TaskStoreReadLog
	TaskRPCPull
	TaskRPCAck
	TaskRPCNotify
	TaskStoreCheckpoint
	TaskRPCPullHint
	TaskStoreLookupMessage
	TaskStoreClose
	TaskStoreRetention
	TaskMetaResolve
	// TaskColdMetaResolve resolves authoritative metadata for an unloaded channel.
	TaskColdMetaResolve
	// TaskColdStoreLoad opens storage only after cold-channel authority is proven.
	TaskColdStoreLoad
	// TaskQuorumInstall recovers and installs one leader authority before admission opens.
	TaskQuorumInstall
	// TaskQuorumCommit executes one exact durable quorum proposal.
	TaskQuorumCommit
)

// Task describes blocking work submitted to a bounded pool.
type Task struct {
	Kind  TaskKind
	Fence ch.Fence
	// Context cancels this task when the original caller gives up, in addition to pool shutdown.
	Context context.Context

	StoreAppend  *StoreAppendTask
	StoreLoad    *StoreLoadTask
	StoreReadLog *StoreReadLogTask
	// StoreLookupMessage asks storage for one durable message row by message id.
	StoreLookupMessage *StoreLookupMessageTask
	StoreApply         *StoreApplyTask
	// StoreCheckpoint persists a checkpoint before runtime eviction.
	StoreCheckpoint *StoreCheckpointTask
	// StoreClose releases a store handle after the reactor has detached it.
	StoreClose *StoreCloseTask
	// StoreRetention adopts a logical retention boundary and optionally trims a safe prefix.
	StoreRetention *StoreRetentionTask
	RPCPull        *RPCPullTask
	RPCAck         *RPCAckTask
	// RPCNotify sends legacy transport compatibility nudges.
	RPCNotify *RPCNotifyTask
	// RPCPullHint sends a prompt pull nudge to a follower.
	RPCPullHint *RPCPullHintTask
	// MetaResolve loads authoritative channel metadata without occupying store or RPC workers.
	MetaResolve *MetaResolveTask
	// QuorumInstall carries one authoritative leader generation into the durable log owner.
	QuorumInstall *QuorumInstallTask
	// QuorumCommit carries one immutable proposal into the durable log owner.
	QuorumCommit *QuorumCommitTask

	RunFunc func(context.Context) Result
}

// StoreLoadTask asks a worker to open and load a channel store before runtime activation.
type StoreLoadTask struct {
	ChannelID ch.ChannelID
}

// MetaResolveTask asks the authoritative metadata resolver for one channel identity.
type MetaResolveTask struct {
	// ChannelID is the client-visible channel identity to resolve.
	ChannelID ch.ChannelID
}

// QuorumInstallTask asks the durable log to recover and install authority.
type QuorumInstallTask struct {
	Authority replication.Authority
}

// QuorumCommitTask asks the durable log to commit one immutable proposal.
type QuorumCommitTask struct {
	Proposal replication.Proposal
}

// StoreAppendTask asks a worker to durably append leader records.
type StoreAppendTask struct {
	ChannelID                 ch.ChannelID
	Records                   []ch.Record
	ServerAllocatedMessageIDs bool
}

// StoreReadLogTask asks a worker to read raw records for replication.
type StoreReadLogTask struct {
	ChannelID  ch.ChannelID
	FromOffset uint64
	MaxOffset  uint64
	MaxBytes   int
}

// StoreLookupMessageTask asks a worker to look up one durable message by id.
type StoreLookupMessageTask struct {
	ChannelID ch.ChannelID
	MessageID uint64
}

// StoreApplyTask asks a worker to persist follower records.
type StoreApplyTask struct {
	ChannelID ch.ChannelID
	Records   []ch.Record
	LeaderHW  uint64
}

// StoreCheckpointTask asks a worker to persist a channel checkpoint before eviction.
type StoreCheckpointTask struct {
	// ChannelID identifies the store that owns the checkpoint.
	ChannelID ch.ChannelID
	// Checkpoint is the durable committed frontier to persist.
	Checkpoint ch.Checkpoint
}

// StoreCloseTask asks a worker to release a detached store handle.
// A successful Pool.Submit transfers handle ownership to the pool; execution
// and accepted-task cancellation share the same exactly-once finalizer.
type StoreCloseTask struct {
	// Store is the detached handle to close outside the reactor loop.
	Store store.ChannelStore
	// closeOnce coordinates execution and accepted-task cancellation ownership.
	closeOnce sync.Once
	// closeErr preserves the first terminal close result for repeated completion attempts.
	closeErr error
}

func (t *StoreCloseTask) finalize() error {
	if t == nil || t.Store == nil {
		return nil
	}
	t.closeOnce.Do(func() {
		t.closeErr = t.Store.Close()
	})
	return t.closeErr
}

// StoreRetentionTask asks a worker to adopt and optionally physically trim a retention boundary.
type StoreRetentionTask struct {
	// ChannelID identifies the store that owns the retention boundary.
	ChannelID ch.ChannelID
	// ThroughSeq is the inclusive logical retention boundary.
	ThroughSeq uint64
	// TrimAllowed reports whether reactor-local safety checks allow physical deletion.
	TrimAllowed bool
	// BlockedReason explains why physical deletion was skipped when TrimAllowed is false.
	BlockedReason string
	// Options bounds one physical trim.
	Options store.RetentionTrimOptions
}

// RPCPullTask asks a remote leader for records.
type RPCPullTask struct {
	Node ch.NodeID
	// Timeout bounds the transport call after a worker starts executing the task; queue wait is excluded.
	Timeout time.Duration
	Request transport.PullRequest
}

// RPCAckTask reports follower progress to the remote leader.
type RPCAckTask struct {
	Node    ch.NodeID
	Request transport.AckRequest
}

// RPCNotifyTask is the legacy compatibility payload for follower nudges.
type RPCNotifyTask struct {
	Node    ch.NodeID
	Request transport.NotifyRequest
}

// RPCPullHintTask asks a remote follower to pull leader progress promptly.
type RPCPullHintTask struct {
	// Node is the target follower node.
	Node ch.NodeID
	// Request is the pull hint payload sent to the follower.
	Request transport.PullHintRequest
}

// Run executes the task payload with the provided blocking dependencies.
func (t Task) Run(ctx context.Context, deps Deps) Result {
	ctx, cancel := taskContext(ctx, t.Context)
	defer cancel()
	var res Result
	switch t.Kind {
	case TaskFunc:
		if t.RunFunc == nil {
			res = invalidResult(t)
			break
		}
		res = t.RunFunc(ctx)
		res.Kind = t.Kind
		if res.Fence == (ch.Fence{}) {
			res.Fence = t.Fence
		}
	case TaskStoreAppend:
		res = runStoreAppend(ctx, deps, t)
	case TaskStoreLoad, TaskColdStoreLoad:
		res = runStoreLoad(ctx, deps, t)
	case TaskStoreReadLog:
		res = runStoreReadLog(ctx, deps, t)
	case TaskStoreLookupMessage:
		res = runStoreLookupMessage(ctx, deps, t)
	case TaskStoreApply:
		res = runStoreApply(ctx, deps, t)
	case TaskStoreCheckpoint:
		res = runStoreCheckpoint(ctx, deps, t)
	case TaskStoreClose:
		res = runStoreClose(ctx, deps, t)
	case TaskStoreRetention:
		res = runStoreRetention(ctx, deps, t)
	case TaskRPCPull:
		res = runRPCPull(ctx, deps, t)
	case TaskRPCAck:
		res = runRPCAck(ctx, deps, t)
	case TaskRPCNotify:
		res = runRPCNotify(ctx, deps, t)
	case TaskRPCPullHint:
		res = runRPCPullHint(ctx, deps, t)
	case TaskMetaResolve, TaskColdMetaResolve:
		res = runMetaResolve(ctx, deps, t)
	case TaskQuorumInstall:
		res = runQuorumInstall(ctx, deps, t)
	case TaskQuorumCommit:
		res = runQuorumCommit(ctx, deps, t)
	default:
		res = invalidResult(t)
	}
	return normalizeContextErr(ctx, res)
}

func runQuorumInstall(ctx context.Context, deps Deps, t Task) Result {
	if t.QuorumInstall == nil || deps.QuorumLog == nil {
		return invalidResult(t)
	}
	installed, err := deps.QuorumLog.Install(ctx, t.QuorumInstall.Authority)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, QuorumInstall: &QuorumInstallResult{Installed: installed}}
}

func runQuorumCommit(ctx context.Context, deps Deps, t Task) Result {
	if t.QuorumCommit == nil || deps.QuorumLog == nil {
		return invalidResult(t)
	}
	receipt, err := deps.QuorumLog.Commit(ctx, t.QuorumCommit.Proposal)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, QuorumCommit: &QuorumCommitResult{Receipt: receipt}}
}

func taskContext(parent context.Context, task context.Context) (context.Context, context.CancelFunc) {
	if parent == nil {
		parent = context.Background()
	}
	if task == nil || task.Done() == nil {
		return parent, func() {}
	}
	ctx, cancel := context.WithCancelCause(parent)
	cancelTask := func() {
		cancel(contextFromTaskCause(task))
	}
	if task.Err() != nil {
		cancelTask()
		return ctx, func() { cancel(context.Canceled) }
	}
	goruntimeregistry.SafeGo(nil, goruntimeregistry.TaskChannelTaskCancellation, func() {
		select {
		case <-task.Done():
			cancelTask()
		case <-ctx.Done():
		}
	})
	return ctx, func() { cancel(context.Canceled) }
}

func contextFromTaskCause(task context.Context) error {
	if cause := context.Cause(task); cause != nil {
		return cause
	}
	if err := task.Err(); err != nil {
		return err
	}
	return context.Canceled
}

func normalizeContextErr(ctx context.Context, res Result) Result {
	// WithCancelCause preserves why the bridge canceled; Err still reports Canceled.
	if res.Err == context.Canceled {
		if cause := context.Cause(ctx); cause != nil && cause != context.Canceled {
			res.Err = cause
		}
	}
	return res
}

func runStoreClose(ctx context.Context, deps Deps, t Task) Result {
	_ = ctx
	_ = deps
	payload := t.StoreClose
	if payload == nil || payload.Store == nil {
		return invalidResult(t)
	}
	err := payload.finalize()
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreClose: &StoreCloseResult{}}
}

func runStoreRetention(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreRetention
	if payload == nil || deps.Stores == nil || payload.ThroughSeq == 0 {
		return invalidResult(t)
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	defer func() { _ = cs.Close() }()
	retainedMaxSeq, err := cs.AdoptRetentionBoundary(ctx, payload.ThroughSeq, ch.RetentionCursorCommitted)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreRetention: &StoreRetentionResult{ThroughSeq: payload.ThroughSeq, BlockedReason: payload.BlockedReason}}
	}
	result := StoreRetentionResult{
		ThroughSeq:      payload.ThroughSeq,
		RetainedMaxSeq:  retainedMaxSeq,
		BlockedReason:   payload.BlockedReason,
		TrimAllowed:     payload.TrimAllowed,
		TrimSkippedSafe: !payload.TrimAllowed,
	}
	if payload.TrimAllowed {
		trimmed, trimErr := cs.TrimMessagesThrough(ctx, payload.ThroughSeq, payload.Options)
		if trimErr != nil {
			return Result{Kind: t.Kind, Fence: t.Fence, Err: trimErr, StoreRetention: &result}
		}
		result.DeletedThroughSeq = trimmed.DeletedThroughSeq
		result.Deleted = trimmed.Deleted
		result.More = trimmed.More
	}
	retention, loadErr := cs.LoadRetentionState(ctx)
	if loadErr != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: loadErr, StoreRetention: &result}
	}
	result.LocalRetentionThroughSeq = retention.LocalRetentionThroughSeq
	result.PhysicalRetentionThroughSeq = retention.PhysicalRetentionThroughSeq
	result.RetainedMaxSeq = maxUint64(result.RetainedMaxSeq, retention.RetainedMaxSeq)
	return Result{Kind: t.Kind, Fence: t.Fence, StoreRetention: &result}
}

func runStoreLoad(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreLoad
	if payload == nil || deps.Stores == nil {
		return invalidResult(t)
	}
	if err := ctx.Err(); err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	owned := true
	defer func() {
		if owned {
			_ = cs.Close()
		}
	}()
	var initial store.InitialState
	if deps.QuorumLog != nil {
		// Quorum writes can be durable before their cached LEO is published.
		// Cold replicas must load one append/checkpoint-consistent frontier.
		loader, ok := cs.(store.ExactStateLoader)
		if !ok {
			return invalidResult(t)
		}
		exact, loadErr := loader.LoadExactState(ctx)
		initial, err = exact.InitialState, loadErr
	} else {
		initial, err = cs.Load(ctx)
	}
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	retention, err := cs.LoadRetentionState(ctx)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	result := Result{Kind: t.Kind, Fence: t.Fence, StoreLoad: &StoreLoadResult{Store: cs, Initial: initial, Retention: retention}}
	owned = false
	return result
}

func runStoreAppend(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreAppend
	if payload == nil || deps.Stores == nil {
		return invalidResult(t)
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	defer func() { _ = cs.Close() }()
	stored, err := cs.AppendLeader(ctx, store.AppendLeaderRequest{Records: payload.Records, ServerAllocatedMessageIDs: payload.ServerAllocatedMessageIDs})
	err = appendResultError(stored.Outcome, err)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreAppend: &StoreAppendResult{BaseOffset: stored.BaseOffset, LastOffset: stored.LastOffset, Outcome: stored.Outcome}}
}

func appendResultError(outcome store.AppendOutcome, err error) error {
	if !outcome.Valid() {
		return ch.ErrInvalidConfig
	}
	if outcome.Durable() {
		return nil
	}
	if err == nil {
		return ch.ErrInvalidConfig
	}
	return err
}

func runStoreReadLog(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreReadLog
	if payload == nil || deps.Stores == nil {
		return invalidResult(t)
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	defer func() { _ = cs.Close() }()
	read, err := cs.ReadLog(ctx, store.ReadLogRequest{FromOffset: payload.FromOffset, MaxOffset: payload.MaxOffset, MaxBytes: payload.MaxBytes})
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreReadLog: &StoreReadLogResult{Records: read.Records}}
}

func runStoreLookupMessage(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreLookupMessage
	if payload == nil || deps.Stores == nil {
		return invalidResult(t)
	}
	if payload.MessageID == 0 {
		return Result{Kind: t.Kind, Fence: t.Fence, StoreLookupMessage: &StoreLookupMessageResult{}}
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	defer func() { _ = cs.Close() }()
	lookup, ok := cs.(store.MessageLookup)
	if !ok {
		return invalidResult(t)
	}
	msg, found, err := lookup.LookupMessageByID(ctx, payload.MessageID)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreLookupMessage: &StoreLookupMessageResult{Message: msg, Found: found}}
}

func runStoreApply(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreApply
	if payload == nil || deps.Stores == nil {
		return invalidResult(t)
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	defer func() { _ = cs.Close() }()
	applied, err := cs.ApplyFollower(ctx, store.ApplyFollowerRequest{Records: payload.Records, LeaderHW: payload.LeaderHW})
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreApply: &StoreApplyResult{LEO: applied.LEO, CheckpointHW: applied.CheckpointHW}}
}

func runStoreCheckpoint(ctx context.Context, deps Deps, t Task) Result {
	payload := t.StoreCheckpoint
	if payload == nil || deps.Stores == nil {
		return invalidResult(t)
	}
	cs, err := deps.Stores.ChannelStore(t.Fence.ChannelKey, payload.ChannelID)
	if err != nil {
		return Result{Kind: t.Kind, Fence: t.Fence, Err: err}
	}
	if cs == nil {
		return invalidResult(t)
	}
	defer func() { _ = cs.Close() }()
	err = cs.StoreCheckpoint(ctx, payload.Checkpoint)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, StoreCheckpoint: &StoreCheckpointResult{Checkpoint: payload.Checkpoint}}
}

func runRPCPull(ctx context.Context, deps Deps, t Task) Result {
	payload := t.RPCPull
	if payload == nil || deps.Transport == nil {
		return invalidResult(t)
	}
	ctx, cancel := taskExecutionTimeout(ctx, payload.Timeout)
	defer cancel()
	resp, err := deps.Transport.Pull(ctx, payload.Node, payload.Request)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, RPCPull: &RPCPullResult{Response: resp}}
}

func taskExecutionTimeout(parent context.Context, timeout time.Duration) (context.Context, context.CancelFunc) {
	if timeout <= 0 {
		return parent, func() {}
	}
	return context.WithTimeout(parent, timeout)
}

func runRPCAck(ctx context.Context, deps Deps, t Task) Result {
	payload := t.RPCAck
	if payload == nil || deps.Transport == nil {
		return invalidResult(t)
	}
	err := deps.Transport.Ack(ctx, payload.Node, payload.Request)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, RPCAck: &RPCAckResult{}}
}

func maxUint64(a uint64, b uint64) uint64 {
	if a > b {
		return a
	}
	return b
}

func runRPCNotify(ctx context.Context, deps Deps, t Task) Result {
	payload := t.RPCNotify
	if payload == nil || deps.Transport == nil {
		return invalidResult(t)
	}
	err := deps.Transport.Notify(ctx, payload.Node, payload.Request)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, RPCNotify: &RPCNotifyResult{}}
}

func runRPCPullHint(ctx context.Context, deps Deps, t Task) Result {
	payload := t.RPCPullHint
	if payload == nil || deps.Transport == nil {
		return invalidResult(t)
	}
	err := deps.Transport.PullHint(ctx, payload.Node, payload.Request)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, RPCPullHint: &RPCPullHintResult{}}
}

func runMetaResolve(ctx context.Context, deps Deps, t Task) Result {
	payload := t.MetaResolve
	if payload == nil || deps.MetaResolver == nil {
		return invalidResult(t)
	}
	meta, err := deps.MetaResolver.ResolveChannelMeta(ctx, payload.ChannelID)
	return Result{Kind: t.Kind, Fence: t.Fence, Err: err, MetaResolve: &MetaResolveResult{Meta: meta}}
}

func invalidResult(t Task) Result {
	return Result{Kind: t.Kind, Fence: t.Fence, Err: ch.ErrInvalidConfig}
}
