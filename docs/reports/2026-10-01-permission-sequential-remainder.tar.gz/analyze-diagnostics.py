"""Bounded, standard-library receipt validation; no performance qualification."""
import collections
import copy
import datetime
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent
NAMES = ["same-slot-remote", "two-slots-one-remote-leader", "two-remote-leaders", "two-slots-local-leader"]
STAGES = ["gateway.async_dispatch_wait", "gateway.messages_send", "gateway.write_sendack", "message.permission", "message.append_admission_wait"]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
time = lambda s: datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))


def unsafe(value):
    if isinstance(value, dict):
        return any(k.lower() in {"from_uid", "payload", "token"} or unsafe(v) for k, v in value.items())
    if isinstance(value, list):
        return any(unsafe(v) for v in value)
    return False


def varint(data, pos):
    n = 0
    for shift in range(0, 70, 7):
        assert pos < len(data)
        b = data[pos]
        pos += 1
        n |= (b & 127) << shift
        if not b & 128:
            return n, pos
    raise AssertionError("invalid protobuf varint")


def fields(data):
    out = collections.defaultdict(list)
    pos = 0
    while pos < len(data):
        tag, pos = varint(data, pos)
        key, wire = tag >> 3, tag & 7
        assert key > 0
        if wire == 0:
            value, pos = varint(data, pos)
        elif wire == 2:
            length, pos = varint(data, pos)
            assert length <= len(data) - pos
            value, pos = data[pos:pos + length], pos + length
        else:
            raise AssertionError("unexpected profile wire type")
        out[key].append(value)
    return out


def packed(items):
    result = []
    for item in items:
        if isinstance(item, int):
            result.append(item)
        else:
            pos = 0
            while pos < len(item):
                value, pos = varint(item, pos)
                result.append(value)
    return result


def cpu_profile(path):
    # The native profile is gzip-compressed pprof protobuf, not a CPU integral.
    assert 0 < path.stat().st_size <= 8 << 20
    with gzip.GzipFile(fileobj=io.BytesIO(path.read_bytes())) as f:
        data = f.read((64 << 20) + 1)
    assert len(data) <= 64 << 20
    p = fields(data)
    strings = [s.decode("utf-8") for s in p[6]]
    assert strings and strings[0] == ""
    types = []
    for row in p[1]:
        v = fields(row)
        types.append((strings[v[1][0]], strings[v[2][0]]))
    index = types.index(("cpu", "nanoseconds"))
    functions = {}
    for row in p[5]:
        f = fields(row)
        ident, name = f[1][0], strings[f[2][0]]
        assert ident > 0 and ident not in functions
        functions[ident] = name
    locations = {}
    for row in p[4]:
        loc = fields(row)
        ident = loc[1][0]
        assert ident > 0 and ident not in locations
        names = []
        for line in loc[4]:
            fid = fields(line)[1][0]
            assert fid in functions
            names.append(functions[fid])
        locations[ident] = names
    total = 0
    cumulative = collections.Counter()
    for row in p[2]:
        sample = fields(row)
        ids, values = packed(sample[1]), packed(sample[2])
        assert len(values) == len(types) and ids
        assert all(i in locations for i in ids)
        value = values[index]
        assert 0 <= value < 1 << 63
        total += value
        for name in sorted({n for i in ids for n in locations[i]}):
            cumulative[name] += value
    assert total > 0 and p[9][0] > 0 and 0 < p[10][0] <= 8_000_000_000
    handle = "github.com/WuKongIM/WuKongIM/internal/access/api.(*Server).handleMetrics"
    flate = "compress/flate.(*compressor).deflate"
    return {"file": path.name, "sha256": sha(path), "sampled_cpu_ns": total, "profile_duration_ns": p[10][0],
            "metrics_handler_sampled_ns": cumulative[handle], "deflate_sampled_ns": cumulative[flate],
            "metrics_handler_fraction": cumulative[handle] / total, "deflate_fraction": cumulative[flate] / total,
            "top_cumulative": cumulative.most_common(20)}


def validate(report, label, plan, capture_index):
    side = label.split("-")[0]
    assert report["binary_sha256"] == plan["binaries"][side]["sha256"]
    assert report["cpu_probe_sha256"] == plan["probe_sha256"]
    assert report["cohort_candidate"] == (side == "new")
    assert report["product_revision"] == ("424d03eb298b972ec572261d617972eecb5523c5" if side == "old" else "c03fa6cc1712e886d9359822e23be716fdb4534e")
    assert not report["performance_qualified"] and report["diagnostic_placement"] == NAMES[1]
    assert report["binary_build"]["GoVersion"] == "go1.25.11"
    assert report["harness_sources"]["permission_prefix_test.go"] == plan["driver_sources"]["test/e2e/message/send_ban/permission_prefix_test.go"]
    assert [c["name"] for c in report["cases"]] == NAMES
    profiles = "profile" in label
    sampler = profiles and label.endswith("-sampler") and not label.endswith("-no-sampler")
    assert report["sequential_profile_ownership_enabled"] == sampler
    assert report["sequential_profiles_enabled"] == profiles
    assert report["sequential_timeline_enabled"] == (not profiles)
    assert report["passed"] == (label != "old-timeline-negative-control")
    for i, c in enumerate(report["cases"]):
        assert [w["concurrency"] for w in c["windows"]] == [1, 32]
        success_ids = [c["warm_ack"]["client_msg_no"]]
        for w in c["windows"]:
            assert w["completed"] and len(w["acks"]) == 64
            for ack in w["acks"]:
                assert ack["reason"] == 1 and ack["message_id"] > 0 and ack["message_seq"] > 0 and not ack.get("error")
                success_ids.append(ack["client_msg_no"])
            count = w["counts"]
            assert count["messages"] == count["plans"] == 64 and count["facts"] == 128
            assert count["barrier_failed"] == count["admission_busy"] == 0
            assert w["cluster_cpu_ns"] > 0
        assert len(c["after_ban"]) == len(c["after_unban"]) == 32
        for ack in c["after_ban"]:
            assert ack["reason"] == 25 and ack["message_id"] == ack["message_seq"] == 0 and not ack.get("error")
        for ack in c["after_unban"]:
            assert ack["reason"] == 1 and ack["message_id"] > 0 and not ack.get("error")
            success_ids.append(ack["client_msg_no"])
        if profiles and i == 1:
            acks = c["sequential_profile_acks"]
            assert len(acks) == 256
            for ack in acks:
                assert ack["reason"] == 1 and ack["message_id"] > 0 and not ack.get("error")
                success_ids.append(ack["client_msg_no"])
            captures = c["sequential_profiles"]
            assert len(captures) == 6
            assert {(x["node_id"], x["kind"]) for x in captures} == {(n, k) for n in [1, 2, 3] for k in ["cpu", "allocs"]}
            for cap in captures:
                assert not cap.get("error_code") and cap["seconds"] == 4
                assert 0 < (time(cap["returned_at"]) - time(cap["requested_at"])).total_seconds() <= 8
                name = Path(cap["path"]).name
                meta = capture_index[name]
                assert name == label + f'.json.node-{cap["node_id"]}.{cap["kind"]}.pprof'
                assert meta["selected"] == (cap["node_id"] == 1 and cap["kind"] == "cpu")
                assert 0 < meta["bytes"] <= 8 << 20
                path = ROOT / name
                if path.exists():
                    assert path.stat().st_size == meta["bytes"] and sha(path) == meta["sha256"]
                else:
                    assert not meta["selected"]
            samples = c.get("sequential_profile_ownership_samples", [])
            assert (0 < len(samples) <= 200) if sampler else not samples
            if sampler:
                assert all(not x.get("error") for x in samples)
            assert time(c["sequential_profile_traffic_finished_at"]) > time(c["sequential_profile_traffic_started_at"])
        else:
            assert not c.get("sequential_profiles") and not c.get("sequential_profile_acks")
        assert len(success_ids) == (417 if profiles and i == 1 else 161)
        assert len(set(success_ids)) == len(success_ids)
        assert c["history_has_more"] is False
        assert sorted(c["exact_history"]) == sorted(c["expected_history"]) == sorted(success_ids)
        for wi, w in enumerate(c["windows"]):
            rows = w.get("request_timelines", [])
            if profiles or i != 1 or wi != 0:
                assert not rows
                continue
            assert len(rows) == 64
            assert [row["client_msg_no"] for row in rows] == [a["client_msg_no"] for a in w["acks"]]
            for row in rows:
                assert not unsafe(row)
                assert set(row["nodes"]) == {"1", "2", "3"}
                for node, data in row["nodes"].items():
                    assert data["node_id"] == int(node) and len(data["events"]) < 32
                    for e in data["events"]:
                        assert e["client_msg_no"] == row["client_msg_no"] and e.get("duration", 0) >= 0
                ingress = row["nodes"][str(c["ingress"])]
                stages = {e["stage"] for e in ingress["events"]}
                if side == "new":
                    assert set(STAGES) <= stages
                else:
                    assert set(STAGES[:3]) <= stages and not set(STAGES[3:]) & stages
    return True


def main():
    plan = json.loads((ROOT / "diagnostic-plan.json").read_text())
    executions = json.loads((ROOT / "diagnostic-execution.json").read_text())
    assert [e["label"] for e in executions] == plan["fixed_order"]
    assert all(e["exit_code"] == e["expected_exit_code"] for e in executions)
    assert plan["diagnostic_only"] and plan["original_acceptance_unchanged"] and plan["original_rejections"] == 6
    for f, expected in plan["driver_sources"].items():
        assert sha(ROOT / "source" / f) == expected
    captures = json.loads((ROOT / "capture-index.json").read_text())
    reports = {label: json.loads((ROOT / (label + ".json")).read_text()) for label in plan["fixed_order"]}
    for label, report in reports.items():
        validate(report, label, plan, captures)
    # The same native identity/tick checker revalidates every diagnostic window.
    spec = importlib.util.spec_from_file_location("cpu_derivation", ROOT / "derive-cpu.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for report in reports.values():
        module.derive(report)
    for filename, expected in json.loads((ROOT / "cpu-derivation-plan.json").read_text())["inputs"].items():
        assert sha(ROOT / "original" / filename) == expected
        module.derive(json.loads((ROOT / "original" / filename).read_text()))
    stats = {name: cpu_profile(ROOT / name) for name in captures if captures[name]["selected"]}
    timeline = reports["new-timeline"]["cases"][1]["windows"][0]["request_timelines"]
    by = collections.defaultdict(list)
    for row in timeline:
        for node, data in row["nodes"].items():
            for e in data["events"]:
                by[node + "/" + e["stage"]].append(e.get("duration", 0))
    stage_stats = {k: {"count": len(v), "mean_ns": statistics.mean(v), "median_ns": statistics.median(v), "max_ns": max(v)} for k, v in sorted(by.items())}
    slow = max(timeline, key=lambda r: r["client"]["elapsed_us"])
    mutations = {
        "wrong_product": lambda d: d.update(binary_sha256="0" * 64),
        "missing_history": lambda d: d["cases"][1]["exact_history"].pop(),
        "missing_ack": lambda d: d["cases"][1]["windows"][0]["acks"].pop(),
        "swapped_profile": lambda d: d["cases"][1]["sequential_profiles"][0].update(node_id=99),
        "missing_sampler": lambda d: d["cases"][1].update(sequential_profile_ownership_samples=[]),
        "wrong_driver": lambda d: d["harness_sources"].update({"permission_prefix_test.go": "0" * 64}),
    }
    controls = []
    for name, mutate in mutations.items():
        bad = copy.deepcopy(reports["new-profile-sampler"])
        mutate(bad)
        try:
            validate(bad, "new-profile-sampler", plan, captures)
        except (AssertionError, KeyError):
            controls.append({"mutation": name, "rejected": True})
        else:
            raise AssertionError("accepted mutation: " + name)
    bad = copy.deepcopy(reports["new-timeline"])
    events = bad["cases"][1]["windows"][0]["request_timelines"][0]["nodes"]["1"]["events"]
    events[:] = [e for e in events if e["stage"] != "message.permission"]
    try:
        validate(bad, "new-timeline", plan, captures)
    except AssertionError:
        controls.append({"mutation": "missing_timeline_stage", "rejected": True})
    else:
        raise AssertionError("accepted missing stage")
    bad = copy.deepcopy(reports["new-timeline"])
    bad["cases"][1]["windows"][0]["request_timelines"][0]["nodes"]["1"]["events"][0]["payload"] = "forbidden"
    try:
        validate(bad, "new-timeline", plan, captures)
    except AssertionError:
        controls.append({"mutation": "unsafe_timeline_field", "rejected": True})
    else:
        raise AssertionError("accepted unsafe field")
    bad = copy.deepcopy(reports["old-timeline-negative-control"])
    bad["passed"] = True
    try:
        validate(bad, "old-timeline-negative-control", plan, captures)
    except AssertionError:
        controls.append({"mutation": "negative_coverage_accepted", "rejected": True})
    else:
        raise AssertionError("accepted incorrect old coverage")
    bad_index = copy.deepcopy(captures)
    name = next(p["path"] for p in reports["new-profile-sampler"]["cases"][1]["sequential_profiles"] if p["kind"] == "cpu" and p["node_id"] == 1)
    bad_index[Path(name).name]["sha256"] = "0" * 64
    try:
        validate(reports["new-profile-sampler"], "new-profile-sampler", plan, bad_index)
    except AssertionError:
        controls.append({"mutation": "wrong_profile_hash", "rejected": True})
    else:
        raise AssertionError("accepted incorrect profile hash")
    out = {"scope": "Offline receipt and CPU-sample diagnosis; no original gate changes, no profile-derived CPU integral.",
           "original_sequential_rejections": 6, "fixtures": 6, "functional_placement_receipts": 24,
           "old_timeline_coverage": "FAILED: 64 permission and 64 append-wait spans absent; complete functional histories retained",
           "stage_semantics": {"replica.leader.local_durable": "In DurableQuorumLog mode this legacy name encloses the whole submitted quorum task through the leader reactor receiving its exact quorum receipt; not an isolated local WAL or fsync span.",
                               "replica.leader.quorum_wait": "In this mode this is the interval after quorum task completion before reply publication, not the quorum round's peer wait.",
                               "replica.leader.queue_wait": "Reported zero after Elapsed clamps missing or reversed endpoints; does not establish absence of worker or transport queueing."},
           "profiles": stats, "new_timeline_stages": stage_stats, "slowest_target_request": slow, "controls": controls}
    (ROOT / "diagnosis.json").write_text(json.dumps(out, indent=2) + "\n")
    print("Validated six fixed fixtures, 24 placement receipts, 24 profile metadata rows and four ingress CPU profiles; rejected ten report corruptions.")
    for label in plan["fixed_order"][:4]:
        p = stats[label + ".json.node-1.cpu.pprof"]
        print(label, "sampled CPU ms", p["sampled_cpu_ns"] / 1e6, "metrics %", round(p["metrics_handler_fraction"] * 100, 2), "deflate %", round(p["deflate_fraction"] * 100, 2))


if __name__ == "__main__":
    main()
