import datetime, hashlib, json, os, subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
repo = root.parent.parent
harness = repo / '.worktrees/issue-977-darwin-sync-driver'
candidate = repo / '.worktrees/issue-977-darwin-sync-candidate'
old = repo / '.worktrees/issue-977-darwin-sync-old'
go = root / 'go1.25.11/bin/go'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(wt, *args): return subprocess.check_output(['git', '-C', str(wt), *args], text=True).strip()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

assert not (root/'reviewed-pair-plan.json').exists(), 'never overwrite measured evidence'
binding=json.loads((root/'harness-source-binding.json').read_text())
assert binding['drivers']['exact-original-driver']['matches_original']
for name, expected in binding['original'].items():
    path=harness/'test/e2e/message/send_ban'/('../../'+name if name.startswith('suite/') else name)
    assert sha(path)==expected, f'original harness mismatch: {name}'
for wt in [harness, candidate, old]:
    assert not git(wt, 'status', '--porcelain'), f'dirty source: {wt}'
identities = {}
for side, wt in [('old', old), ('new', candidate)]:
    revision = git(wt, 'rev-parse', 'HEAD')
    info = subprocess.check_output([str(go), 'version', '-m', str(root/f'{side}-wukongim')], text=True,
                                    env={**os.environ, 'GOTOOLCHAIN':'local'})
    assert '\tbuild\tvcs.revision='+revision+'\n' in info and '\tbuild\tvcs.modified=false\n' in info
    assert 'go1.25.11\n' in info.split('\n')[0]+'\n'
    (root/f'{side}-binary-build.txt').write_text(info)
    identities[side] = revision
original = json.loads((repo/'tmp/issue-977-sync-syscall-20261001/original-replay/reviewed-pair-plan.json').read_text())
plan = {**original, 'old_revision':identities['old'], 'new_revision':identities['new'],
        'binary_sha256': {side:sha(root/f'{side}-wukongim') for side in ['old','new']},
        'started_at':now(), 'runner_sha256':sha(Path(__file__)),
        'harness_revision':git(harness,'rev-parse','HEAD'), 'harness_binary_sha256':sha(root/'permission-harness'),
        'qualification':False, 'original_failed_rows_preserved':6, 'exact_original_driver':True, 'auxiliary_driver_drift_retained':True,
        'scope_note':'Rebuilt frozen old source; original experiment structure and verifier unchanged. Shared Darwin host. Not a Linux capacity qualification.'}
plan['binary_sha256']['probe'] = sha(root/'permission-cpu-darwin')
(root/'reviewed-pair-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
execution=[]
for label in plan['order']:
    side=label.split('-')[0]
    env={k:v for k,v in os.environ.items() if not k.startswith('WK_E2E_')}
    env.update({'GOMAXPROCS':'4','GOTOOLCHAIN':'local','GOWORK':'off',
                'WK_E2E_BINARY':str(root/f'{side}-wukongim'),
                'WK_E2E_PERMISSION_CPU_PROBE':str(root/'permission-cpu-darwin')})
    if side=='old':
        test='TestPermissionCallerBaseline'
        env.update({'WK_E2E_PERMISSION_BASELINE':'1','WK_E2E_PERMISSION_BASELINE_REPORT':str(root/f'{label}.json')})
    else:
        test='TestPermissionCallerCohorts'
        env.update({'WK_E2E_PERMISSION_COHORTS':'1','WK_E2E_PERMISSION_COHORT_REPORT':str(root/f'{label}.json')})
    command=[str(root/'permission-harness'),'-test.run',f'^{test}$','-test.count=1','-test.timeout=4m','-test.v']
    start=now()
    with (root/f'{label}.log').open('x') as out:
        run=subprocess.run(command,env=env,cwd=harness,stdout=out,stderr=subprocess.STDOUT,timeout=255)
    execution.append({'label':label,'exit_code':run.returncode,'command':command,'report':str(root/f'{label}.json'),
                      'started_at':start,'finished_at':now()})
    (root/'reviewed-pair-execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    print(label,run.returncode,flush=True)
    # Failed functional fixtures stay failed; do not retry or replace them.
    if run.returncode: raise SystemExit(run.returncode)
raise SystemExit(subprocess.call(['python3',str(root/'verify-reviewed-pairs.py')],cwd=root))
