import hashlib,json,subprocess,sys,tarfile,tempfile
from pathlib import Path

archive=Path(sys.argv[1])
with tempfile.TemporaryDirectory(prefix='wk977-bundle-replay-') as d:
    p=Path(d)
    with tarfile.open(archive,'r:gz') as t:
        members=t.getmembers()
        assert len(members)==len({m.name for m in members})
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        for m in members:
            out=p/m.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(t.extractfile(m).read())
    manifest=json.loads((p/'manifest.json').read_text())
    assert {m.name for m in members}=={'manifest.json'}|{x['path'] for x in manifest['files']}
    for x in manifest['files']:
        data=(p/x['path']).read_bytes()
        assert len(data)==x['bytes'] and hashlib.sha256(data).hexdigest()==x['sha256'],x['path']
    expected=(p/'reviewed-pair-verdict.json').read_bytes()
    result=subprocess.run(['python3',str(p/'verify-reviewed-pairs.py')],capture_output=True,text=True)
    assert result.returncode==1 and not result.stderr, 'expected performance rejection, not invalid evidence'
    assert (p/'reviewed-pair-verdict.json').read_bytes()==expected
    verdict=json.loads(expected)
    assert len(verdict['sequential_controls'])==12 and len(verdict['sequential_over_threshold'])==6
    assert verdict['burst_gate_passed'] and not verdict['all_performance_gates_passed']
    print(json.dumps({'verified':True,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                      'files_verified':len(manifest['files']),'exact_verdict_replayed':True,
                      'acceptance_exit':result.returncode,'sequential_failed_rows':6,'burst_failed_rows':0},indent=2))
