import gzip, hashlib, io, json, shutil, subprocess, tarfile
from pathlib import Path

p = Path(__file__).resolve().parent
repo = p.parent.parent
wt = repo / '.worktrees/issue-977-darwin-sync-candidate'
def sha(data): return hashlib.sha256(data).hexdigest()

# These exact-source copies preserve the narrow seam independently of caches.
for name in ['db.go','fs_darwin.go','fs_other.go','fs_darwin_test.go','fs_darwin_integration_test.go']:
    out=p/'source/product'/name;out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes((wt/'pkg/db/internal/engine'/name).read_bytes())
selected = ['failure-contract-plan.json','frozen-instructions.json','harness-source-binding.json',
            'run-pairs.py','verify-reviewed-pairs.py','reviewed-pair-plan.json','reviewed-pair-execution.json',
            'reviewed-pair-verdict.json','artifact-corruption-controls.json','old-binary-build.txt','new-binary-build.txt',
            'cpu-calibration.log','contracts-red.log','contracts-red-2.log','engine-green.log','engine-green-2.log',
            'db-race.log','linux-cross-build.log','module-verify.log','flow-doc-contracts.log',
            'flow-generate.log','flow-render.log','flow-doc-contracts-2.log','acceptance-replay.log','pair-run.log',
            'auxiliary-driver-drift/reviewed-pair-plan.json','auxiliary-driver-drift/reviewed-pair-execution.json',
            'auxiliary-driver-drift/reviewed-pair-verdict.json']
selected += [f'{s}-reviewed-pair-{n}.{ext}' for n in range(1,4) for s in ['old','new'] for ext in ['json','log']]
selected += ['source/product/'+n for n in ['db.go','fs_darwin.go','fs_other.go','fs_darwin_test.go','fs_darwin_integration_test.go']]
selected += ['seal-evidence.py','verify-bundle.py']

def seal(names, output):
    names=sorted(set(names))
    manifest={'version':1,'scope':'Failed Darwin sync candidate experiment; functional evidence and unchanged <=5% acceptance',
              'files':[{'path':n,'bytes':(p/n).stat().st_size,'sha256':sha((p/n).read_bytes())} for n in names]}
    manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
    with output.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz:
            with tarfile.open(fileobj=gz,mode='w') as archive:
                for n in names+['manifest.json']:
                    data=manifest_bytes if n=='manifest.json' else (p/n).read_bytes()
                    info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644
                    archive.addfile(info,io.BytesIO(data))
    return {'path':str(output),'bytes':output.stat().st_size,'members':len(names)+1,'sha256':sha(output.read_bytes())}

review=seal(selected,p/'permission-darwin-sync-selected.tar.gz')
full = selected + ['old-wukongim','new-wukongim','permission-harness','permission-harness-drift',
                   'permission-cpu-darwin','engine-linux-amd64.test']
full += [str(f.relative_to(p)) for f in (p/'auxiliary-driver-drift').glob('*') if f.is_file()]
full += [n for n in ['module-restore.log','module-restore-2.log','old-build.log','new-build.log','new-final-build.log',
                    'harness-build.log','harness-exact-build.log','harness-drift-rebuild.log'] if (p/n).exists()]
local=seal(full,p/'permission-darwin-sync-local.tar.gz')
receipt={'selected':review,'local':local,'measured_revision':json.loads((p/'reviewed-pair-plan.json').read_text())['new_revision'],
         'capacity_qualified':False,'sequential_failed_rows':6,'burst_failed_rows':0,
         'original_archive_sha256':'2eb068e94ce358e333bd43691d546895449a8cb907c1e12bb94f9b0b1e219c5f'}
(p/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
