"""Identical bounded diagnostic-only edits; isolated sources, never the candidate."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
ART = Path(__file__).parent
MOD = ROOT / 'tmp/issue-977-permission-baseline-20260930/modcache/github.com/cockroachdb/pebble/v2@v2.1.4'
PEBBLE = ART / 'pebble'
GO = ART / 'go1.25.11/bin/go'

def edit(root, path, before, after, count=1):
    p = root / path
    s = p.read_text()
    assert s.count(before) == count, (path, before[:80], s.count(before))
    p.write_text(s.replace(before, after))

def add(root, path, s):
    p = root / path
    assert not p.exists()
    p.write_text(s)

common = '''// Diagnostic-only source copy for Issue #977. No product repair or qualification.
// Events exist only during an operator-owned runtime trace and have a hard cap.
'''
replication = '''package replication
import ("context"; "encoding/json"; "fmt"; "runtime/trace"; "sync/atomic"; ch "github.com/WuKongIM/WuKongIM/pkg/channel")
var diagnosticEvents atomic.Uint64
func diagnosticProposal(phase string, manifest ch.ProposalManifest, records []ch.Record, priority uint8, peer uint64, request uint64) {
 if !trace.IsEnabled() { return }
 selected := false
 for _, record := range records { if record.ClientMsgNo == "two-remote-leaders-c1-030" { selected = true; break } }
 if !selected { return }
 n := diagnosticEvents.Add(1); if n > 256 { if n == 257 { trace.Log(context.Background(), "wk977.proposal", `{"phase":"cap"}`) }; return }
 data,_ := json.Marshal(map[string]any{"phase":phase,"cmd":fmt.Sprintf("%x",manifest.CommandID),"digest":fmt.Sprintf("%x",manifest.Digest),"base":manifest.BaseOffset,"last":manifest.LastOffset,"priority":priority,"peer":peer,"request":request})
 trace.Log(context.Background(), "wk977.proposal", string(data))
}
func diagnosticPeer(phase string, node ch.NodeID, priority ExchangePriority, items []queuedPeerItem) {
 for _, item := range items { if item.kind == ExchangeReplicate { diagnosticProposal(phase,item.replicate.Manifest,item.replicate.Records,uint8(priority),uint64(node),item.requestID) } }
}
'''
message = '''package message
import ("context"; "encoding/json"; "fmt"; "runtime/trace"; "sync/atomic"; "github.com/WuKongIM/WuKongIM/pkg/db/internal/engine")
var diagnosticEvents atomic.Uint64
func diagnosticPrepared(phase string, prepared []preparedCommitRows, lane string, batch *engine.Batch) {
 if !trace.IsEnabled() { return }
 for _, item := range prepared {
  selected := false
  for _, row := range item.rows { if row.ClientMsgNo == "two-remote-leaders-c1-030" { selected=true; break } }
  if !selected { continue }
  for _, proposal := range item.proposals {
   n:=diagnosticEvents.Add(1); if n>256 { if n==257 {trace.Log(context.Background(),"wk977.proposal",`{"phase":"cap"}`)}; return }
   m:=proposal.manifest; group:=uint64(0); if batch!=nil {group=batch.DiagnosticID()}
   data,_:=json.Marshal(map[string]any{"phase":phase,"cmd":fmt.Sprintf("%x",m.CommandID),"digest":fmt.Sprintf("%x",m.Digest),"base":m.BaseOffset,"last":m.LastOffset,"lane":lane,"group":group})
   trace.Log(context.Background(),"wk977.proposal",string(data))
  }
 }
}
'''
engine = '''package engine
import ("context"; "encoding/json"; "fmt"; "runtime/trace"; "sync/atomic")
var diagnosticGroups atomic.Uint64
var diagnosticEvents atomic.Uint64
// DiagnosticID joins only this owned physical batch; it is never a metric label.
func (b *Batch) DiagnosticID() uint64 {
 if !trace.IsEnabled() {return 0}; if b.diagnosticID==0 {b.diagnosticID=diagnosticGroups.Add(1)}; return b.diagnosticID
}
func (b *Batch) diagnosticCommit(phase string) {
 if !trace.IsEnabled() {return}; n:=diagnosticEvents.Add(1); if n>512 {if n==513 {trace.Log(context.Background(),"wk977.physical",`{"phase":"cap"}`)};return}
 stats:=b.batch.CommitStats()
 data,_:=json.Marshal(map[string]any{"phase":phase,"group":b.DiagnosticID(),"db":fmt.Sprintf("%p",b.db.pdb),"seq":uint64(b.batch.SeqNum()),"total_ns":int64(stats.TotalDuration),"wait_ns":int64(stats.CommitWaitDuration),"semaphore_ns":int64(stats.SemaphoreWaitDuration),"rotation_ns":int64(stats.WALRotationDuration),"wal_queue_ns":int64(stats.WALQueueWaitDuration)})
 trace.Log(context.Background(),"wk977.physical",string(data))
}
'''

subprocess.run(['python3',str(ART/'verify-proposal-trace.py'),str(ROOT/'tmp/issue-977-remote-three-node-20261001/new.node-1.trace.parsed.txt')],stdout=(ART/'contract-red-final.log').open('w'),check=False)
(ART/'contract-frozen.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ART/'contract.json',ART/'verify-proposal-trace.py']},indent=2)+'\n')
shutil.copytree(MOD, PEBBLE)
PEBBLE.chmod(0o755)
for p in PEBBLE.rglob('*'):
    p.chmod(0o644 if p.is_file() else 0o755)
# The application batch sequence joins the exact standalone WAL writer. File
# and directory identifiers are process-local opaque identities, never paths.
edit(PEBBLE,'db.go','"slices"','"slices"\n "runtime/trace"\n "encoding/json"')
edit(PEBBLE,'db.go','size, err = d.mu.log.writer.WriteRecord(repr, wal.SyncOptions{Done: syncWG, Err: syncErr}, b)',
     'size, err = d.mu.log.writer.WriteRecord(repr, wal.SyncOptions{Done: syncWG, Err: syncErr}, b)\n diagnosticAppend(d, b, size)',count=2)
add(PEBBLE,'diagnostic.go',common+'''package pebble
import ("context"; "encoding/json"; "fmt"; "runtime/trace")
func diagnosticAppend(d *DB,b *Batch,end int64) {
 if !trace.IsEnabled(){return}; if w,ok:=d.mu.log.writer.(interface{DiagnosticStream() string});ok {
 data,_:=json.Marshal(map[string]any{"phase":"append","db":fmt.Sprintf("%p",d),"seq":uint64(b.SeqNum()),"stream":w.DiagnosticStream(),"end":end}); trace.Log(context.Background(),"wk977.wal",string(data))
 }
}
''')
# db.go's imports are used by its helper file instead; avoid touching unrelated code.
edit(PEBBLE,'db.go','\n "runtime/trace"\n "encoding/json"','')
add(PEBBLE,'wal/diagnostic.go',common+'''package wal
import "fmt"
func(w *standaloneWriter) DiagnosticStream() string {return fmt.Sprintf("%p",w.w)}
''')
edit(PEBBLE,'record/log_writer.go','logNum uint32','logNum uint32\n // diagnosticWritten is flusher-owned, counting actual writes for exact sync coverage.\n diagnosticWritten int64\n diagnosticOp uint64')
edit(PEBBLE,'record/log_writer.go','_, err = w.w.Write(data)','err = w.diagnosticWrite(data)')
edit(PEBBLE,'record/log_writer.go','if _, err := w.w.Write(b.buf[b.flushed:]); err != nil {','if err := w.diagnosticWrite(b.buf[b.flushed:]); err != nil {')
edit(PEBBLE,'record/log_writer.go','err := w.s.Sync()','op:=w.diagnosticNextOp()\n w.diagnosticLog("sync_begin",op,0,nil)\n err := w.s.Sync()\n w.diagnosticLog("sync_end",op,0,err)')
edit(PEBBLE,'record/log_writer.go','if popErr := f.pendingSyncs.pop(snap, err); popErr != nil {',
     'op:=w.diagnosticNextOp()\n w.diagnosticLog("release_begin",op,0,err)\n popErr:=f.pendingSyncs.pop(snap, err)\n w.diagnosticLog("release_end",op,0,popErr)\n if popErr != nil {')
add(PEBBLE,'record/diagnostic.go',common+'''package record
import ("context";"encoding/json";"fmt";"runtime/trace";"sync/atomic")
var diagnosticEvents atomic.Uint64
func(w *LogWriter) diagnosticNextOp() uint64 {w.diagnosticOp++;return w.diagnosticOp}
func(w *LogWriter) diagnosticLog(phase string,op uint64,n int,err error){
 if !trace.IsEnabled(){return}; count:=diagnosticEvents.Add(1); if count>4096{if count==4097{trace.Log(context.Background(),"wk977.wal",`{"phase":"cap"}`)};return}
 data,_:=json.Marshal(map[string]any{"phase":phase,"stream":fmt.Sprintf("%p",w),"wal":w.logNum,"op":op,"written":w.diagnosticWritten,"n":n,"error":err!=nil});trace.Log(context.Background(),"wk977.wal",string(data))
}
func(w *LogWriter) diagnosticWrite(data []byte)error{
 op:=w.diagnosticNextOp();w.diagnosticLog("write_begin",op,0,nil)
 n,err:=w.w.Write(data);w.diagnosticWritten+=int64(n);w.diagnosticLog("write_end",op,n,err);return err
}
''')
for name in ('old','candidate'):
    wt=ROOT/'.worktrees'/('issue-977-wal-stages-'+name)
    add(wt,'pkg/channel/replication/diagnostic.go',common+replication)
    add(wt,'pkg/db/message/diagnostic.go',common+message)
    add(wt,'pkg/db/internal/engine/diagnostic.go',common+engine)
    edit(wt,'pkg/db/internal/engine/batch.go','type Batch struct {','type Batch struct {\n // diagnosticID is private to this isolated trace probe.\n diagnosticID uint64')
    edit(wt,'pkg/db/internal/engine/batch.go','opts := pebble.NoSync','b.diagnosticCommit("commit_begin")\n defer b.diagnosticCommit("commit_end")\n opts := pebble.NoSync')
    edit(wt,'pkg/db/message/compat.go','\trequest := commit.Request{\n\t\tLane:      commit.Lane{Name: commitRowsLaneName(lane)', '\tdiagnosticPrepared("submit",prepared,lane,nil)\n defer diagnosticPrepared("submit_end",prepared,lane,nil)\n\trequest := commit.Request{\n\t\tLane:      commit.Lane{Name: commitRowsLaneName(lane)')
    edit(wt,'pkg/db/message/compat.go','\t\t\tfor _, mutation := range mutations {','\t\t\tdiagnosticPrepared("build",prepared,lane,batch)\n\t\t\tfor _, mutation := range mutations {',count=2)
    # The Publish closure has no batch variable; record its own explicit phase.
    edit(wt,'pkg/db/message/compat.go','Publish: func() error {\n\t\t\tdiagnosticPrepared("build",prepared,lane,batch)','Publish: func() error {\n\t\t\tdiagnosticPrepared("publish",prepared,lane,nil)')
    edit(wt,'pkg/channel/replication/store_adapter.go','func (a *storeAdapter) Sync(ctx context.Context, mutations []Mutation) []MutationResult {','func (a *storeAdapter) Sync(ctx context.Context, mutations []Mutation) []MutationResult {\n for _, m:=range mutations {diagnosticProposal("store_begin",m.Manifest,m.Records,uint8(m.Class),0,0)}\n defer func(){for _, m:=range mutations {diagnosticProposal("store_end",m.Manifest,m.Records,uint8(m.Class),0,0)}}()')
    edit(wt,'pkg/channel/replication/runtime.go','return l.runtime.localPool.Submit(ctx, localDurabilityItem{','diagnosticProposal("local_enqueue",proposal.manifest,proposal.records,0,0,0)\n return l.runtime.localPool.Submit(ctx, localDurabilityItem{')
    edit(wt,'pkg/channel/replication/runtime.go','batchStartedAt := time.Now()\n\tfor _, item := range items {','batchStartedAt := time.Now()\n\tfor _, item := range items {\n diagnosticProposal("local_run",item.proposal.manifest,item.proposal.records,0,0,0)')
    edit(wt,'pkg/channel/replication/runtime.go','\t\titem.complete(completion)','\t\tdiagnosticProposal("local_complete",item.proposal.manifest,item.proposal.records,0,0,0)\n\t\titem.complete(completion)')
    edit(wt,'pkg/channel/replication/peer_batcher.go','item.queuedAt = time.Now()','item.queuedAt = time.Now()\n if item.kind==ExchangeReplicate {p:=ExchangePriorityForeground;if deferred{p=ExchangePriorityBackground}; diagnosticProposal("peer_enqueue",item.replicate.Manifest,item.replicate.Records,uint8(p),uint64(node),item.requestID)}')
    edit(wt,'pkg/channel/replication/peer_batcher.go','response, err := callPeerExchange(ctx, b.cfg.Link, node, batch)','diagnosticPeer("peer_begin",node,priority,items)\n response, err := callPeerExchange(ctx, b.cfg.Link, node, batch)\n diagnosticPeer("peer_end",node,priority,items)')
    edit(wt,'pkg/channel/replication/exchange_server.go','seen := make(map[uint64]struct{}, len(batch.Items))','for _, item:=range batch.Items {if item.Replicate!=nil {r:=item.Replicate;diagnosticProposal("receive",r.Manifest,r.Records,uint8(batch.Priority),uint64(from),item.RequestID)}}\n defer func(){for _, item:=range batch.Items {if item.Replicate!=nil {r:=item.Replicate;diagnosticProposal("receive_end",r.Manifest,r.Records,uint8(batch.Priority),uint64(from),item.RequestID)}}}()\n seen := make(map[uint64]struct{}, len(batch.Items))')
    with (wt/'go.mod').open('a') as f:f.write('\n// Isolated Issue #977 diagnosis, never a product dependency change.\nreplace github.com/cockroachdb/pebble/v2 => '+str(PEBBLE)+'\n')
    paths=subprocess.check_output(['git','diff','--name-only'],cwd=wt,text=True).splitlines()+['pkg/channel/replication/diagnostic.go','pkg/db/message/diagnostic.go','pkg/db/internal/engine/diagnostic.go']
    subprocess.run([str(GO.parent/'gofmt'),'-w',*[str(wt/p) for p in paths if p.endswith('.go')]],check=True)
subprocess.run([str(GO.parent/'gofmt'),'-w',str(PEBBLE/'db.go'),str(PEBBLE/'diagnostic.go'),str(PEBBLE/'wal/diagnostic.go'),str(PEBBLE/'record/diagnostic.go'),str(PEBBLE/'record/log_writer.go')],check=True)
print('Identical isolated instrumentation written; no binary built or fixture run.')
