"""Seal original observations and compact positive lineage in separate archives."""
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

ART=Path(__file__).parent
spec=importlib.util.spec_from_file_location('verifier',ART/'verify-proposal-trace.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
files={p.name:p.read_bytes() for p in ART.iterdir() if p.is_file() and p.suffix in ('.json','.log','.py','.patch') and not p.name.startswith(('archive-roundtrip','archive-replay','archive-index'))}
full=dict(files)
selected=dict(files)
for label in ('old','new','old-gap','new-gap'):
    for node in (1,2,3):
        name=f'{label}.node-{node}.events.txt'
        data=(ART/name).read_bytes();full[name]=data
        result=v.verify_node(ART/name)
        wanted={(x['category'],x['time'],x['phase']) for x in result['events']+result['physical']+result['wal_anchor']}
        # Include the exact matching release begin as well as its terminal end.
        release=next(x for x in result['wal_anchor'] if x['phase']=='release_end')
        output=[]
        for line in data.decode().splitlines(True):
            m=v.LOG.search(line);cat=json.loads(m[3]);event=json.loads(json.loads(m[4]));time=int(m[2])
            if (cat,time,event['phase']) in wanted or (event.get('stream')==result['stream'] and event.get('op')==release['op'] and event['phase']=='release_begin'):
                output.append(line)
        selected[name]=''.join(output).encode()
        raw=f'{label}.node-{node}.trace';full[raw]=(ART/raw).read_bytes()

def seal(name,members,mode):
    target=ART/name;assert not target.exists()
    manifest={'mode':mode,'files':{n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(members.items())}}
    members={**members,'manifest.json':(json.dumps(manifest,indent=2)+'\n').encode()}
    with target.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for n,d in sorted(members.items()):
                    info=tarfile.TarInfo(n);info.size=len(d);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(d))
    out=ART/('archive-roundtrip-'+mode);out.mkdir()
    with tarfile.open(target) as tar:
        assert all(m.isfile() and Path(m.name).name==m.name for m in tar.getmembers())
        assert {m.name:tar.extractfile(m).read() for m in tar.getmembers()}==members
        tar.extractall(out,filter='data')
    command=['python3',str(out/'verify-proposal-evidence.py')]+(['--selected'] if mode=='selected' else [])
    p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,p.stdout+p.stderr
    (ART/('archive-roundtrip-'+mode+'.json')).write_text(json.dumps({'command':command,'exit_code':p.returncode,'output':p.stdout,'members':len(members)},indent=2)+'\n')
    return {'name':name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'members':len(members),'mode':mode}

index={'full':seal('permission-proposal-wal-full.tar.gz',full,'full'),'selected':seal('permission-proposal-wal-selected.tar.gz',selected,'selected'),'bounds_note':'Selected archive contains positive exact proposal/physical/WAL lineage and complete E2E reports; no raw trace or complete-capture cap/coverage claim. Full archive contains every raw trace, all custom events, scheduling evidence and source deltas. Trace text decodes are deliberately omitted and reproducible.'}
(ART/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(index))
