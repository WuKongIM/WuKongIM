"""Repeat declared evidence failures against copies of real captured events."""
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile

ART=Path(__file__).parent
spec=importlib.util.spec_from_file_location('verifier',ART/'verify-proposal-trace.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
source=ART/'old.node-1.events.txt'
lines=source.read_text().splitlines(True)
base=v.verify_node(source)
results=[]
for mode in ('missing_build','identity_mismatch','priority_mismatch','missing_sync','sync_error','missing_write','write_error','missing_release','cap_marker','unsafe_field'):
    changed=[]
    for line in lines:
        m=v.LOG.search(line);category=json.loads(m[3]);event=json.loads(json.loads(m[4]))
        target=category=='wk977.proposal'
        covering=event.get('stream')==base['stream']
        if mode=='missing_build' and target and event['phase']=='build':continue
        if mode=='missing_sync' and covering and event['phase']=='sync_end':continue
        if mode=='missing_write' and covering and event['phase']=='write_end':continue
        if mode=='missing_release' and covering and event['phase']=='release_end':continue
        if mode=='identity_mismatch' and target and event['phase']=='build':event['cmd']='0'*64
        if mode=='priority_mismatch' and target and event['phase']=='peer_begin' and event['peer']==2:event['priority']=1
        if mode=='sync_error' and covering and event['phase']=='sync_end':event['error']=True
        if mode=='write_error' and covering and event['phase']=='write_end':event['error']=True
        if mode=='unsafe_field' and target:event['payload']='omitted synthetic sentinel'
        line=line[:m.start(4)]+json.dumps(json.dumps(event,separators=(',',':')))+line[m.end(4):]
        changed.append(line)
    if mode=='cap_marker':
        changed.append('M=1 P=1 G=1 Log Time=1 Task=0 Category="wk977.wal" Message="{\\"phase\\":\\"cap\\"}"\n')
    with tempfile.TemporaryDirectory(prefix='wk977-contract-') as temp:
        path=Path(temp)/'events.txt';path.write_text(''.join(changed))
        cmd=['python3',str(ART/'verify-proposal-trace.py'),str(path),str(ART/'old.node-2.events.txt'),str(ART/'old.node-3.events.txt')]
        p=subprocess.run(cmd,capture_output=True,text=True)
        assert p.returncode!=0,(mode,p.stdout)
        results.append({'failure':mode,'exit_code':p.returncode,'output':p.stdout,'bounded_stderr':p.stderr[-500:]})
(ART/'contract-sensitivity.json').write_text(json.dumps({'declared_before_instrumentation':'contract.json','mutations_of_real_e2e_evidence_only':True,'all_rejected':True,'results':results},indent=2)+'\n')
print('10 declared failure mutations rejected')
