"""Offline contract for bounded public runtime traces from the real-process E2E."""
import json
from pathlib import Path
import re
import sys

ART = Path(__file__).parent
LOG = re.compile(r'G=(\d+) Log Time=(\d+) Task=\d+ Category=("(?:[^"\\]|\\.)*") Message=("(?:[^"\\]|\\.)*")')

def events(path):
    result = []
    for line in path.open():
        m = LOG.search(line)
        if not m:
            continue
        category = json.loads(m[3])
        if not category.startswith('wk977.'):
            continue
        data = json.loads(json.loads(m[4]))
        assert not set(data) & {'payload', 'from_uid', 'token', 'channel_id', 'client_msg_no'}
        assert data['phase'] != 'cap', 'bounded event cap reached'
        result.append({'g': int(m[1]), 'time': int(m[2]), 'category': category, **data})
    assert result, 'missing diagnostic events: uninstrumented capture must fail'
    limits = {'wk977.proposal': 256, 'wk977.physical': 512, 'wk977.wal': 4096}
    assert all(sum(x['category'] == key for x in result) <= limit for key, limit in limits.items())
    return result

def one(items, phase):
    found = [x for x in items if x['phase'] == phase]
    assert len(found) == 1, (phase, len(found))
    return found[0]

def verify_node(path):
    es = events(path)
    proposal = [x for x in es if x['category'] == 'wk977.proposal']
    ids = {(x['cmd'], x['digest'], x['base'], x['last']) for x in proposal}
    assert len(ids) == 1, ('identity mismatch', ids)
    contract = json.loads((ART / 'contract.json').read_text())
    for phase in contract['proposal_phases']:
        one(proposal, phase)
    if any(x['phase'] == 'local_enqueue' for x in proposal):
        for phase in ('local_enqueue', 'local_run', 'local_complete'):
            one(proposal, phase)
        for peer in (2, 3):
            items = [x for x in proposal if x.get('peer') == peer]
            for phase in ('peer_enqueue', 'peer_begin', 'peer_end'):
                one(items, phase)
            assert one(items, 'peer_begin')['priority'] in (1, 2)
    else:
        receive = one(proposal, 'receive')
        finish = one(proposal, 'receive_end')
        assert receive['priority'] in (1, 2) and receive['priority'] == finish['priority']
        assert receive['request'] == finish['request'] and receive['peer'] == finish['peer'] == 1
    build = one(proposal, 'build')
    begin = one([x for x in es if x.get('group') == build['group']], 'commit_begin')
    end = one([x for x in es if x.get('group') == build['group']], 'commit_end')
    append = one([x for x in es if x.get('db') == end['db'] and x.get('seq') == end['seq']], 'append')
    wal = [x for x in es if x.get('stream') == append['stream']]
    # A sync covers precisely the bytes already written when that sync starts.
    syncs = [x for x in wal if x['phase'] == 'sync_begin' and x['written'] >= append['end'] and x['time'] >= append['time']]
    assert syncs, 'missing covering sync'
    sb = min(syncs, key=lambda x: x['time'])
    se = one([x for x in wal if x.get('op') == sb['op']], 'sync_end')
    assert not se['error'] and sb['time'] <= se['time'] <= end['time']
    writes = [x for x in wal if x['phase'] == 'write_end' and x['written'] >= append['end'] and x['time'] <= sb['time']]
    assert writes, 'missing covering write'
    we = min(writes, key=lambda x: x['time'])
    wb = one([x for x in wal if x.get('op') == we['op']], 'write_begin')
    assert not we['error'] and we['n'] > 0
    releases = [x for x in wal if x['phase'] == 'release_end' and se['time'] <= x['time'] <= end['time']]
    assert releases, 'missing terminal sync release'
    return {'identity': list(next(iter(ids))), 'group': build['group'], 'db': end['db'], 'seq': end['seq'], 'stream': append['stream'], 'wal_record_end': append['end'], 'commit_ms': (end['time']-begin['time'])/1e6, 'sync_ms': (se['time']-sb['time'])/1e6, 'write_ms': (we['time']-wb['time'])/1e6, 'events': proposal, 'wal_anchor': [append,wb,we,sb,se,min(releases,key=lambda x:x['time'])], 'physical': [begin,end], 'custom_event_count': len(es)}

if __name__ == '__main__':
    try:
        results = [verify_node(Path(p)) for p in sys.argv[1:]]
        assert results and len({tuple(x['identity']) for x in results}) == 1
        if len(results) == 3:
            for node, result in zip((2, 3), results[1:]):
                sender = one([x for x in results[0]['events'] if x.get('peer') == node], 'peer_begin')
                receiver = one(result['events'], 'receive')
                assert (sender['request'], sender['priority']) == (receiver['request'], receiver['priority'])
        print(json.dumps({'passed': True, 'nodes': results}, indent=2))
    except (AssertionError, KeyError, ValueError) as error:
        print(json.dumps({'passed': False, 'reason': str(error)}))
        sys.exit(1)
