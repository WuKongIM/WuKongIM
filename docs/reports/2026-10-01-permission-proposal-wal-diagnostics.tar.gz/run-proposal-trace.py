"""Bounded, source-pinned local runtime trace diagnosis; never an acceptance run."""
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import tomllib
import urllib.parse
import urllib.request

ROOT = Path('/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM')
ART = ROOT / 'tmp/issue-977-proposal-wal-20261001'
DRIVER = ROOT / '.worktrees/issue-977-wal-stages-driver'
GO = str(ART / 'go1.25.11/bin/go')
TARGET = 'two-remote-leaders-c1-030'
BINARIES = {kind: (ART / ('wukongim-' + source), json.loads((ART / (source + '.instrumented-source.json')).read_text())['revision']) for kind, source in [('old', 'old'), ('new', 'candidate')]}

PROBE = ROOT / 'tmp/issue-977-request-timeline-20260930/permission-cpu-darwin'
MAX_TRACE_BYTES = 16 << 20
RULE = [{'client_msg_no': TARGET, 'sample_rate': 1, 'ttl_seconds': 120}]

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def unsafe(value):
    if isinstance(value, dict):
        return any(key.lower() in ('from_uid', 'payload', 'token') or unsafe(item) for key, item in value.items())
    return isinstance(value, list) and any(unsafe(item) for item in value)

def capture(config, opener, label):
    receipt = {'node_id': config['node_id'], 'requested_at': utc(), 'seconds': 4, 'limit_bytes': MAX_TRACE_BYTES}
    path = ART / f"{label}.node-{config['node_id']}.trace"
    try:
        with opener.open('http://' + config['api_addr'] + '/debug/pprof/trace?seconds=4', timeout=6) as response:
            assert response.status == 200
            data = response.read(MAX_TRACE_BYTES + 1)
        receipt['bytes'] = len(data)
        receipt['oversized'] = len(data) > MAX_TRACE_BYTES
        # An oversized capture is retained as a bounded failed artifact, never parsed as complete.
        path.write_bytes(data[:MAX_TRACE_BYTES])
        receipt['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        receipt['complete_http_response'] = not receipt['oversized']
    except Exception as error:
        receipt['error_type'] = type(error).__name__
    receipt['returned_at'] = utc()
    return receipt

def run(label):
    assert label in ('old', 'new', 'old-gap', 'new-gap')
    kind = 'new' if label.startswith('new') else 'old'
    binary, revision = BINARIES.get(label, BINARIES[kind])
    ART.mkdir(parents=True, exist_ok=True)
    plan_path = ART / f'{label}.plan.json'
    assert not plan_path.exists(), 'An observed run must never be overwritten.'
    driver_revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=DRIVER, text=True).strip()
    assert driver_revision == 'b4edb947210a243a73b070cae899f86a6b56b8d5'
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=DRIVER, text=True)
    dependency = json.loads((ART / 'dependency-source.json').read_text())
    for relative, expected in dependency['modified_files'].items():
        assert hashlib.sha256((Path(dependency['source_copy']) / relative).read_bytes()).hexdigest() == expected
    build = subprocess.check_output([GO, 'version', '-m', str(binary)], text=True)
    assert 'vcs.revision=' + revision in build and 'vcs.modified=false' in build
    save(plan_path, {
        'purpose': 'Capture all three owned nodes for preselected ordinary two-remote-Leader c1-030; separate foreground sender queue, follower scheduling and durable store wait across unchanged old/candidate binaries. Isolated identical source instrumentation; no product candidate change. Full four-placement prefix retained; explicitly unqualified and never replaces comparative acceptance.',
        'runtime_revision': revision, 'driver_revision': driver_revision,
        'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'go_toolchain': {'version': subprocess.check_output([GO, 'version'], text=True).strip(), 'binary_sha256': hashlib.sha256(Path(GO).read_bytes()).hexdigest(), 'archive_recovery': json.loads((ART / 'toolchain.json').read_text())},
        'cpu_probe_sha256': hashlib.sha256(PROBE.read_bytes()).hexdigest(),
        'target': TARGET, 'diagnostic_gap_ms': 2 if label.endswith('-gap') else 0, 'dependency_source': json.loads((ART / 'dependency-source.json').read_text()), 'runtime_env_override': {'WK_DIAGNOSTICS_DEBUG_MATCHES': RULE},
        'trace_bounds': {'node_ids': [1, 2, 3], 'seconds_each': 4, 'timeout_seconds': 6, 'bytes': MAX_TRACE_BYTES, 'requests': 3, 'total_max_bytes': MAX_TRACE_BYTES * 3},
        'timeline_bounds': {'requests': 3, 'seconds_each': 2, 'bytes_each': 65536, 'events_each': 32},
        'failure_modes_declared_before_execution': [
            'No owned config or target phase: no capture; retain failed receipt.',
            'Wrong node/leader or target missing: do not attribute a target cause.',
            'Capture unavailable, oversized, unreadable or without target overlap: retain it as incomplete diagnosis.',
            'Trace wall-clock mapping uncertain: expose uncertainty and do not infer sub-millisecond order.',
            'Functional fixture fails: preserve every observation; no replacement/retry.',
            'Profiling changes latency: report raw timing as diagnostic, never qualification.',
        ],
        'observer': '50-ms host poll of only owned temporary configs/test progress',
        'started_at': utc(),
    })
    tmp = Path(tempfile.mkdtemp(prefix='wkqtrace-', dir='/tmp'))
    env = {key: value for key, value in os.environ.items() if not key.startswith('WK_E2E_') and not key.lower().endswith('_proxy') and key != 'GODEBUG'}
    report_var = 'WK_E2E_PERMISSION_COHORT_REPORT' if kind == 'new' else 'WK_E2E_PERMISSION_BASELINE_REPORT'
    env.update(GOTOOLCHAIN='local', GOPROXY='off', GOWORK='off', GOMAXPROCS='4', GOMODCACHE=str(ROOT / 'tmp/issue-977-permission-baseline-20260930/modcache'), TMPDIR=str(tmp), WK_E2E_BINARY=str(binary), WK_E2E_PERMISSION_CPU_PROBE=str(PROBE), WK_DIAGNOSTICS_DEBUG_MATCHES=json.dumps(RULE))
    env['WK_E2E_PERMISSION_DIAGNOSTIC_GAP_MS'] = '2' if label.endswith('-gap') else '0'
    env[report_var] = str(ART / f'{label}.report.json')
    env['WK_E2E_PERMISSION_COHORTS' if kind == 'new' else 'WK_E2E_PERMISSION_BASELINE'] = '1'
    test = 'TestPermissionCallerCohorts' if kind == 'new' else 'TestPermissionCallerBaseline'
    command = [GO, 'test', '-tags=e2e', './test/e2e/message/send_ban', '-run', '^' + test + '$', '-count=1', '-timeout=4m', '-p=1', '-v']
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    configs, replies, futures, queried = [], [], {}, False
    log_path = ART / f'{label}.log'
    start = time.monotonic()
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor, log_path.open('w') as log:
        child = subprocess.Popen(command, cwd=DRIVER, env=env, stdout=log, stderr=subprocess.STDOUT)
        while child.poll() is None:
            if time.monotonic() - start > 270:
                child.terminate()
                child.wait(timeout=10)
                raise RuntimeError('Owned diagnostic exceeded deadline')
            if not configs:
                for path in tmp.glob('TestPermissionCaller*/*/node*/wukongim.toml'):
                    try:
                        data = path.read_bytes()
                    except FileNotFoundError:
                        continue
                    config = tomllib.loads(data.decode())
                    addr = config['api']['listen_addr']
                    assert addr.startswith('127.0.0.1:')
                    configs.append({'node_id': config['node']['id'], 'api_addr': addr, 'config_sha256': hashlib.sha256(data).hexdigest()})
                if len(configs) != 3:
                    configs = []
            progress = log_path.read_text()
            if not futures and len(configs) == 3 and '=== RUN   ' + test + '/two-remote-leaders' in progress:
                for config in sorted(configs, key=lambda item: item['node_id']):
                    futures[config['node_id']] = executor.submit(capture, config, opener, label)
            if not queried and len(configs) == 3 and '=== RUN   ' + test + '/two-slots-local-leader' in progress:
                queried = True
                for config in sorted(configs, key=lambda item: item['node_id']):
                    reply = {'node_id': config['node_id'], 'queried_at': utc()}
                    try:
                        url = 'http://' + config['api_addr'] + '/debug/diagnostics/message?' + urllib.parse.urlencode({'client_msg_no': TARGET, 'limit': 32})
                        with opener.open(url, timeout=2) as response:
                            assert response.status == 200
                            data = response.read(65537)
                            assert len(data) <= 65536
                        value = json.loads(data)
                        assert not unsafe(value) and value['node_id'] == config['node_id'] and len(value['events']) < 32
                        assert all(event.get('client_msg_no') == TARGET and event.get('duration', 0) >= 0 for event in value['events'])
                        reply['reply'] = value
                    except Exception as error:
                        reply['error_type'] = type(error).__name__
                    replies.append(reply)
                    save(ART / f'{label}.timelines.json', replies)
            time.sleep(.05)
        code = child.wait()
        traces = [futures[node].result() for node in sorted(futures)] if futures else [{'error_type': 'CaptureNotStarted'}]
    receipt = {'exit_code': code, 'command': command, 'owned_tmpdir': str(tmp), 'configs': configs, 'traces': traces, 'queries_executed': len(replies), 'query_errors': [item for item in replies if 'error_type' in item], 'finished_at': utc()}
    try:
        tmp.rmdir()
        receipt['empty_owned_tmpdir_removed'] = True
    except OSError:
        receipt['empty_owned_tmpdir_removed'] = False
    save(ART / f'{label}.execution.json', receipt)
    print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 2:
        TARGET = sys.argv[2]
        assert TARGET == 'two-remote-leaders-c1-030'
        RULE = [{'client_msg_no': TARGET, 'sample_rate': 1, 'ttl_seconds': 120}]
    run(sys.argv[1])
