"""Verify immutable E2E evidence. Selected mode certifies positive lineage only."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ART=Path(__file__).parent
SELECTED='--selected' in sys.argv
def read(name):return json.loads((ART/name).read_text())
spec=importlib.util.spec_from_file_location('verifier',ART/'verify-proposal-trace.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
assert (ART/'old.source.patch').read_bytes()==(ART/'candidate.source.patch').read_bytes()
assert read('original-acceptance-replay.json')['exit_code']==1
assert read('original-acceptance-replay.json')['failed_sequential_rows']==6
assert read('contract-sensitivity.json')['all_rejected']
assert read('contract-frozen.json')['contract.json']==hashlib.sha256((ART/'contract.json').read_bytes()).hexdigest()
assert read('contract-frozen.json')['verify-proposal-trace.py']==hashlib.sha256((ART/'verify-proposal-trace.frozen.py').read_bytes()).hexdigest()
assert all(x['cached_ziphash_verified'] for x in read('dependency-toolchain-verification.json'))
summary=read('proposal-summary.json')
driver=read('driver.instrumented-source.json')['revision']
for label in ('old','new','old-gap','new-gap'):
    kind='candidate' if label.startswith('new') else 'old'
    plan,execution,report=[read(f'{label}.{x}.json') for x in ('plan','execution','report')]
    assert report['product_revision']==plan['runtime_revision']==read(kind+'.instrumented-source.json')['revision']
    assert plan['driver_revision']==driver
    assert report['binary_sha256']==plan['binary_sha256']==read(kind+'.binary.json')['sha256']
    assert report['passed'] and report['performance_qualified'] is False
    assert (report['nodes'],report['message_replicas'],report['metadata_replicas'],report['hash_slots'],report['physical_slots'],report['node_gomaxprocs'],report['driver_gomaxprocs'])==(3,3,1,256,12,4,4)
    assert execution['exit_code']==0 and execution['empty_owned_tmpdir_removed'] and not execution['query_errors']
    assert len(report['cases'])==4
    assert int(report['diagnostic_gap_ms'])==plan['diagnostic_gap_ms']==(2 if label.endswith('-gap') else 0)
    for case in report['cases']:
        assert len(case['exact_history'])==len(set(case['exact_history']))==161
        assert set(case['exact_history'])==set(case['expected_history']) and not case['history_has_more']
        assert len(case['after_ban'])==len(case['after_unban'])==32
        assert all(a['reason']==25 and a['message_id']==a['message_seq']==0 and not a.get('error') for a in case['after_ban'])
        assert all(a['reason']==1 and a['message_id']>0 and a['message_seq']>0 and not a.get('error') for a in case['after_unban'])
        assert [w['concurrency'] for w in case['windows']]==[1,32]
        for window in case['windows']:
            assert window['completed'] and len(window['acks'])==64
            assert len({a['client_msg_no'] for a in window['acks']})==64
            assert all(a['reason']==1 and not a.get('error') for a in window['acks'])
            assert window['counts']['plans']==window['counts']['messages']==64
            assert window['counts']['facts']==128
            assert all(window['counts'][k]==0 for k in ('barrier_failed','admission_busy','cohort_busy'))
    target_case=next(c for c in report['cases'] if c['name']=='two-remote-leaders')
    assert target_case['channel_runtime']['leader']==1 and target_case['ingress']==3
    verdicts=[v.verify_node(ART/f'{label}.node-{node}.events.txt') for node in (1,2,3)]
    assert len({tuple(x['identity']) for x in verdicts})==1
    for node,result in zip((2,3),verdicts[1:]):
        sender=v.one([x for x in verdicts[0]['events'] if x.get('peer')==node],'peer_begin')
        receiver=v.one(result['events'],'receive')
        assert (sender['priority'],sender['request'])==(receiver['priority'],receiver['request'])
    assert [x['wire_priority'] for x in summary['fixed_quartet'][label]['nodes'][0]['peers']]==[0,1]
    assert len(execution['traces'])==3
    for trace in execution['traces']:
        assert not trace.get('error_type') and not trace['oversized'] and trace['complete_http_response']
        assert trace['seconds']==4 and 0<trace['bytes']<=trace['limit_bytes']==16<<20
        if not SELECTED:
            raw=ART/f"{label}.node-{trace['node_id']}.trace"
            assert raw.stat().st_size==trace['bytes'] and hashlib.sha256(raw.read_bytes()).hexdigest()==trace['sha256']
    assert all(n['physical_stats']['rotation_ns']==0 for n in summary['fixed_quartet'][label]['nodes'])
if (ART/'manifest.json').exists():
    for name,item in read('manifest.json')['files'].items():
        p=ART/name;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
print(json.dumps({'passed':True,'selected_only':SELECTED,'functional_cases':16,'exact_target_lineages':12,'original_sequential_acceptance':'FAILED: six rows','scope':'Selected positive lineage and stored receipts; raw complete-capture coverage/cap absence requires full archive.' if SELECTED else 'Raw trace hashes, complete custom events, exact target lineages and retained E2E outputs.'}))
