"""Decode sequentially, retain compact logs and exact-goroutine state evidence.

Full decoded text is reproducible from immutable raw trace; remove it only after
recording its hash and extracting all custom events. Never overlap a live fixture.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ART = Path(__file__).parent
GO = str(ART / 'go1.25.11/bin/go')
HEADER = re.compile(r'M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)')
STATE = re.compile(r'Resource=Goroutine\((\d+)\).* (\w+)->(\w+)')
LOG = re.compile(r'Category=("(?:[^"\\]|\\.)*") Message=("(?:[^"\\]|\\.)*")')

def digest(path):
    return {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def event_stream(path):
    current = None
    for line in path.open():
        if line.startswith('M='):
            if current is not None:
                yield current
            m = HEADER.match(line.rstrip())
            assert m, line
            current = {'g': int(m[3]), 'kind': m[4], 'time': int(m[5]), 'detail': m[6], 'stack': []}
        elif current and line.strip():
            current['stack'].append(line.rstrip())
    if current:
        yield current

def decode(label, node):
    prefix = ART / f'{label}.node-{node}.trace'
    path = prefix.with_suffix('.trace.parsed.txt')
    assert not path.exists()
    with path.open('x') as out:
        p = subprocess.run([GO, 'tool', 'trace', '-d=parsed', str(prefix)], stdout=out, stderr=subprocess.PIPE, timeout=90)
    assert p.returncode == 0, p.stderr[-1000:]
    compact = ART / f'{label}.node-{node}.events.txt'
    assert not compact.exists()
    custom = []
    with compact.open('x') as out:
        for line in path.open():
            if ' Category="wk977.' not in line:
                continue
            out.write(line)
            m = HEADER.match(line.rstrip())
            log = LOG.search(line)
            assert m and log
            custom.append({'g': int(m[3]), 'time': int(m[5]), 'category': json.loads(log[1]), **json.loads(json.loads(log[2]))})
    assert compact.stat().st_size <= 2 << 20
    proposals = [x for x in custom if x['category'] == 'wk977.proposal']
    assert proposals, 'target missing from trace'
    lo, hi = min(x['time'] for x in proposals), max(x['time'] for x in proposals)
    owned = {x['g'] for x in proposals}
    group = next(x['group'] for x in proposals if x['phase'] == 'build')
    physical = [x for x in custom if x.get('group') == group and x['category'] == 'wk977.physical']
    owned.update(x['g'] for x in physical)
    commit_end = next(x for x in physical if x['phase'] == 'commit_end')
    append = [x for x in custom if x.get('db') == commit_end['db'] and x.get('seq') == commit_end['seq'] and x['phase'] == 'append']
    if append:
        owned.update(x['g'] for x in custom if x.get('stream') == append[0]['stream'] and lo <= x['time'] <= hi)
    previous, spans, transitions, ranges, syncs = {}, [], [], [], []
    for event in event_stream(path):
        if event['kind'] == 'Sync' and 'Trace=' in event['detail']:
            m = re.search(r'Trace=(\d+) Mono=(\d+)', event['detail'])
            if m:
                syncs.append({'trace': int(m[1]), 'mono': int(m[2])})
        if event['kind'].startswith('Range') and lo - 50_000_000 <= event['time'] <= hi + 50_000_000:
            ranges.append(event)
        if event['kind'] != 'StateTransition':
            continue
        m = STATE.search(event['detail'])
        if not m or int(m[1]) not in owned:
            continue
        g, before, after = int(m[1]), m[2], m[3]
        if before == after:
            continue
        old = previous.get(g)
        if old:
            duration = min(event['time'], hi) - max(old['time'], lo)
            if duration > 0:
                spans.append({'g': g, 'state': old['state'], 'overlap_ns': duration, 'begin': old['event'], 'end': event})
        if lo <= event['time'] <= hi:
            transitions.append(event)
        previous[g] = {'time': event['time'], 'state': after, 'event': event}
    assert len(spans) <= 500 and len(transitions) <= 500 and len(ranges) <= 100
    wire = ART / f'{label}.node-{node}.wire.txt'
    with wire.open('x') as out:
        p = subprocess.run([GO, 'tool', 'trace', '-d=wire', str(prefix)], stdout=out, stderr=subprocess.PIPE, timeout=90)
    assert p.returncode == 0, p.stderr[-1000:]
    clocks = []
    for line in wire.open():
        m = re.match(r'ClockSnapshot dt=\d+ mono=(\d+) sec=(\d+) nsec=(\d+)', line)
        if m:
            mono, sec, nsec = map(int, m.groups()); clocks.append({'mono': mono, 'wall_ns': sec*1_000_000_000+nsec})
    assert syncs and clocks and len(syncs) <= 100 and len(clocks) <= 100
    mappings = []
    for sync in syncs:
        clock = min(clocks, key=lambda x: abs(x['mono']-sync['mono']))
        mappings.append({'trace': sync['trace'], 'wall_offset': clock['wall_ns'] - clock['mono'] + sync['mono'] - sync['trace']})
    wire_digest = digest(wire);wire.unlink()
    result = {'runtime_clocks': mappings, 'offset_spread_ns': max(x['wall_offset'] for x in mappings)-min(x['wall_offset'] for x in mappings), 'wire_decode': wire_digest, 'label': label, 'node': node, 'target_interval': [lo, hi], 'exact_goroutines': sorted(owned), 'spans': spans, 'transitions': transitions, 'nearby_ranges': ranges, 'full_decode': digest(path), 'compact_logs': digest(compact), 'raw_trace': digest(prefix), 'custom_events': len(custom), 'notes': 'Exact goroutine identity from proposal/physical/WAL logs; spans are overlaps with the whole target operation, never summed across different goroutines as exclusive request time.'}
    (ART / f'{label}.node-{node}.scheduling.json').write_text(json.dumps(result, indent=2)+'\n')
    path.unlink()
    print(json.dumps({k:v for k,v in result.items() if k not in ('spans','transitions','nearby_ranges')}), flush=True)

if __name__ == '__main__':
    for node in (1, 2, 3):
        decode(sys.argv[1], node)
