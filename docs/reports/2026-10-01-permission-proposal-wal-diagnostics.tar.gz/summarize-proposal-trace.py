"""Derive exact per-node phases and a separate cadence contrast; no qualification."""
import datetime
import importlib.util
import json
from pathlib import Path

ART = Path(__file__).parent
spec = importlib.util.spec_from_file_location('contract', ART/'verify-proposal-trace.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)

def read(name):
    return json.loads((ART/name).read_text())

def one(events, phase, peer=None):
    return contract.one([x for x in events if peer is None or x.get('peer') == peer], phase)

def duration(events, begin, end, peer=None):
    return (one(events, end, peer)['time']-one(events, begin, peer)['time'])/1e6

def clock_offset(scheduling, at):
    return min(scheduling['runtime_clocks'], key=lambda x:abs(x['trace']-at))['wall_offset']

def parse_time(value):
    return datetime.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()

results = {}
for label in ('old','new','old-gap','new-gap'):
    report = read(label+'.report.json')
    case = next(c for c in report['cases'] if c['name'] == 'two-remote-leaders')
    window = case['windows'][0]
    ack = next(a for a in window['acks'] if a['client_msg_no']=='two-remote-leaders-c1-030')
    ack_total_ms = sum(a['elapsed_us'] for a in window['acks'])/1000
    residual_ms = window['elapsed_ms']-ack_total_ms
    if label.endswith('-gap'):
        assert residual_ms >= 125, ('63 requested gaps cannot fit the retained wall-time residual',label,residual_ms)
    nodes=[]
    for node in (1,2,3):
        verdict=contract.verify_node(ART/f'{label}.node-{node}.events.txt')
        scheduling=read(f'{label}.node-{node}.scheduling.json')
        es=verdict['events']
        critical_begin=one(es,'local_enqueue' if node==1 else 'receive')
        critical_end=one(es,'local_complete' if node==1 else 'receive_end')
        relevant_spans=[]
        # Keep source stacks for only the exact operation's commit and caller.
        for span in scheduling['spans']:
            a,b=span['begin']['time'],span['end']['time']
            overlap=min(b,critical_end['time'])-max(a,critical_begin['time'])
            if overlap>0:
                relevant_spans.append({**span,'critical_overlap_ns':overlap})
        entry={'node':node,'identity':verdict['identity'],'group':verdict['group'],'db':verdict['db'],'seq':verdict['seq'],'stream':verdict['stream'],'wal_end':verdict['wal_record_end'],
               'store_ms':duration(es,'store_begin','store_end'),'coordinator_before_build_ms':duration(es,'submit','build'),
               'commit_ms':verdict['commit_ms'],'write_ms':verdict['write_ms'],'sync_api_ms':verdict['sync_ms'],
               'physical_stats':verdict['physical'][-1],'exact_events':es,'wal_anchor':verdict['wal_anchor'],
               'runnable_max_ms':max([s['critical_overlap_ns'] for s in relevant_spans if s['state']=='Runnable']or[0])/1e6,
               'critical_scheduling':relevant_spans,'runtime_clocks':scheduling['runtime_clocks'],'clock_spread_ns':scheduling['offset_spread_ns'],
               'verified_event_count':verdict['custom_event_count']}
        if node==1:
            entry['local_queue_ms']=duration(es,'local_enqueue','local_run')
            entry['local_complete_wall_ns']=critical_end['time']+clock_offset(scheduling,critical_end['time'])
            entry['peers']=[]
            for peer in (2,3):
                end=one(es,'peer_end',peer)
                entry['peers'].append({'node':peer,'wire_priority':one(es,'peer_begin',peer)['priority'],'queue_ms':duration(es,'peer_enqueue','peer_begin',peer),'exchange_ms':duration(es,'peer_begin','peer_end',peer),'enqueue_relative_to_local_complete_ms':(one(es,'peer_enqueue',peer)['time']-critical_end['time'])/1e6,'peer_end_wall_ns':end['time']+clock_offset(scheduling,end['time'])})
            foreground=next(p for p in entry['peers'] if p['wire_priority']==0)
            entry['last_required_observed_completion']='foreground_peer' if foreground['peer_end_wall_ns']>entry['local_complete_wall_ns'] else 'leader_local'
        else:
            entry['wire_priority']=one(es,'receive')['priority']
        nodes.append(entry)
    assert len({tuple(n['identity']) for n in nodes})==1
    results[label]={'target_ack_ms':ack['elapsed_us']/1000,'window_p99_ms':window['sendack_p99_us']/1000,'window_cpu_ms':window['cluster_cpu_ns']/1e6,'window_elapsed_ms':window['elapsed_ms'],'gap_ms':int(report['diagnostic_gap_ms']),'cadence_receipt':{'inserted_timer_count':63 if label.endswith('-gap') else 0,'requested_gap_total_ms':126 if label.endswith('-gap') else 0,'raw_ack_sum_ms':ack_total_ms,'wall_minus_ack_sum_ms':residual_ms,'scope':'Source/plan and completed 64-request loop establish timer execution. Client per-gap timestamps are absent because timeline mode was disabled equally in every run; residual includes timer, loop and scheduling overhead, not a per-gap measurement.'},'passed_functional':report['passed'],'performance_qualified':False,'nodes':nodes}
summary={'target':'two-remote-leaders-c1-030','fixed_quartet':results,'scope':'One instrumented diagnostic quartet on a shared Darwin host, not comparative or Linux500 qualification. Per-node identity is exact; wall mappings have measured offset spreads, not certified inter-node error bounds. Sync API timing includes wrapper/syscall/scheduling and trace overhead; it is distinct from the larger ordered publish wait. Background peer is queued after required completions and is not a required quorum voter for this target. Pre-handler transport/receiver queue and uninstrumented portions of SEND-to-ACK remain unallocated.'}
(ART/'proposal-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for label,row in results.items():
    print(label,{k:v for k,v in row.items() if k not in ('nodes','cadence_receipt')},'last',row['nodes'][0]['last_required_observed_completion'])
