"""Recompute state partitions and Linux aggregate deltas from retained inputs."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('probe_contract', ROOT / 'verify-sync-probe.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)


def load(path):
    return json.loads(path.read_text())


def fingerprint(path):
    return {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def target_partitions(prior):
    manifest = load(prior / 'manifest.json')
    for name, record in manifest['files'].items():
        assert fingerprint(prior / name) == record, 'selected input mismatch: ' + name
    result = []
    summary = load(prior / 'proposal-summary.json')
    assert len(summary['fixed_quartet']) == 4
    for label, fixture in summary['fixed_quartet'].items():
        assert len(fixture['nodes']) == 3
        for node in fixture['nodes']:
            anchors = node['wal_anchor']
            append = [x for x in anchors if x['phase'] == 'append']
            begin = [x for x in anchors if x['phase'] == 'sync_begin']
            end = [x for x in anchors if x['phase'] == 'sync_end']
            assert len(append) == len(begin) == len(end) == 1
            append, begin, end = append[0], begin[0], end[0]
            assert (append['db'], append['seq'], append['stream'], append['end']) == (
                node['db'], node['seq'], node['stream'], node['wal_end'])
            assert begin['stream'] == end['stream'] == append['stream']
            assert (begin['op'], begin['g']) == (end['op'], end['g'])
            assert not begin['error'] and not end['error']
            assert begin['written'] >= append['end'] and end['written'] >= begin['written']
            scheduling = load(prior / f'{label}.node-{node["node"]}.scheduling.json')
            assert begin['g'] in scheduling['exact_goroutines']
            states = contract.partition(scheduling['spans'], begin['g'], begin['time'], end['time'])
            result.append({'fixture': label, 'node': node['node'], 'group': node['group'],
                           'db': node['db'], 'seq': node['seq'], 'stream': node['stream'],
                           'sync_op': begin['op'], 'goroutine': begin['g'],
                           'sync_api_trace_ns': end['time'] - begin['time'],
                           'goroutine_state_ns': states,
                           'scheduling_input': fingerprint(prior / f'{label}.node-{node["node"]}.scheduling.json')})
    assert len(result) == 12
    return result


def histogram_rows(snapshot):
    result = {}
    for family in snapshot['families']:
        for metric in family['metric']:
            labels = tuple(sorted((label['name'], label['value']) for label in metric['label']))
            key = (family['name'], labels)
            assert key not in result, 'duplicate histogram identity'
            result[key] = metric['histogram']
    return result


def linux_deltas(directory):
    assert (directory / 'source.sha').read_text().strip() == 'e9909fa320e1c8a6f8be1bd8efd8ceb232078ebf'
    assert (directory / 'go-version.txt').read_text().strip() == 'go version go1.25.11 linux/amd64'
    window = load(directory / 'counters/window.json')
    assert (window['schema'], window['goos'], window['goarch'], window['gomaxprocs'],
            window['operations'], window['handlers_completed']) == (
        'mixed-send-counters/v1', 'linux', 'amd64', 4, 90000, True)
    assert load(directory / 'result.json')['status'] == 'pass'
    arrival = load(directory / 'arrival.json')
    assert (arrival['schema'], arrival['phase'], arrival['qualification']) == ('scheduled-arrival/v1', 'measurement', True)
    assert len(arrival['windows']) == 3
    for cut in arrival['windows']:
        assert (cut['planned'], cut['started'], cut['completed'], cut['errors'], cut['dropped'],
                cut['target_per_second'], cut['started_per_second']) == (30000, 30000, 30000, 0, 0, 500, 500)
        assert cut['scheduled_to_completion_p99_ms'] <= 400
    before = histogram_rows(load(directory / 'counters/before.json'))
    after = histogram_rows(load(directory / 'counters/after.json'))
    result = []
    for (family, label_items), final in after.items():
        labels = dict(label_items)
        if family not in ('wukongim_storage_commit_batch_duration_seconds',
                          'wukongim_storage_commit_request_duration_seconds'):
            continue
        if family.endswith('batch_duration_seconds') and labels['stage'] != 'commit':
            continue
        initial = before[(family, label_items)]
        count = final['sample_count'] - initial['sample_count']
        total = final['sample_sum'] - initial['sample_sum']
        assert count > 0 and total >= 0 and labels['store'] == 'message' and labels['result'] == 'ok'
        assert len(final['bucket']) == len(initial['bucket'])
        buckets = []
        previous = 0
        for first, last in zip(initial['bucket'], final['bucket']):
            assert first['upper_bound'] == last['upper_bound']
            delta = last['cumulative_count'] - first['cumulative_count']
            assert previous <= delta <= count
            buckets.append({'upper_seconds': last['upper_bound'], 'count': delta})
            previous = delta
        threshold = math.ceil(count * .99)
        upper = next((b['upper_seconds'] * 1000 for b in buckets if b['count'] >= threshold), None)
        result.append({'family': family, 'labels': labels, 'samples': count,
                       'sum_seconds': total, 'mean_ms': total * 1000 / count,
                       'p99_bucket_upper_ms': upper, 'buckets': buckets})
    assert len(result) == 12
    names = sorted({family for family, _ in after})
    return {'rows': result, 'retained_families': names,
            'wal_fsync_histogram_retained': any('fsync' in name.lower() for name in names),
            'source': 'e9909fa320e1c8a6f8be1bd8efd8ceb232078ebf',
            'window': window, 'arrival_windows': arrival['windows'], 'data_filesystem': load(directory / 'data-filesystem.json'),
            'scope': 'Different Linux aggregate populations. Commit is not exclusive sync; host disk/pressure is not per-proposal. No exact syscall trace retained.'}


def analyze(prior):
    probe = contract.verify(ROOT)
    phases = load(ROOT / 'probe-result.json')['phases']
    probe_totals = []
    for phase in phases:
        operations = [x for x in probe['operations'] if x['mode'] == phase['mode']]
        states = {state: sum(x['goroutine_state_ns'][state] for x in operations)
                  for state in ('Running', 'Runnable', 'Waiting', 'Syscall')}
        probe_totals.append({'mode': phase['mode'], 'completed': phase['completed'],
                             'fallback_count': phase['fallback_count'] if phase['mode'] == 'scheduled-fullfsync' else None,
                             'fallback_observed': phase['mode'] == 'scheduled-fullfsync',
                             'sync_wall_sum_ms': sum(x['wall_ns'] for x in phase['operations']) / 1e6,
                             'trace_interval_sum_ms': sum(states.values()) / 1e6,
                             'goroutine_state_ms': {k: v / 1e6 for k, v in states.items()},
                             'process_cpu_ms': phase['process_cpu_ms'],
                             'cpu_scope': 'Whole probe process cut encloses writes, sync markers and trace overhead; not a per-sync CPU measure.'})
    return {'schema': 'wk977-sync-observations/v1', 'prior_target_partitions': target_partitions(prior),
            'isolated_probe': probe_totals, 'linux': linux_deltas(ROOT / 'linux'),
            'original_acceptance': load(ROOT / 'original-acceptance-replay.json'),
            'prior_proposal_full_trace_available': False, 'prior_raw_trace_replay_this_followup': False,
            'product_fix': False, 'qualification_replacement': False,
            'scope': 'Observed interval state is elapsed time, not CPU or kernel-exclusive time. Probe confirms visibility behavior only. Regression cause remains unproven.'}


if __name__ == '__main__':
    prior = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'selected'
    print(json.dumps(analyze(prior), indent=2))
