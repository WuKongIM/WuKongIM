module wk977-syncprobe

go 1.25.0

require golang.org/x/sys v0.47.0
