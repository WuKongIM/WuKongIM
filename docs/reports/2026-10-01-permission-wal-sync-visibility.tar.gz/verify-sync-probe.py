"""Offline process-artifact contract; never interpret trace Running as CPU."""
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).parent
HEADER = re.compile(r'M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)')
STATE = re.compile(r'Resource=Goroutine\((\d+)\).* (\w+)->(\w+)')
LOG = re.compile(r'Category=("(?:[^"\\]|\\.)*") Message=("(?:[^"\\]|\\.)*")')


def events(path):
    current = None
    for line in path.open():
        if line.startswith('M='):
            if current is not None:
                yield current
            match = HEADER.match(line.rstrip())
            assert match, 'invalid trace header'
            current = {'g': int(match[3]), 'kind': match[4], 'time': int(match[5]),
                       'detail': match[6], 'stack': []}
        elif current and line.strip():
            current['stack'].append(line.rstrip())
    if current:
        yield current


def partition(spans, goroutine, start, end):
    """Require complete non-overlapping coverage on one goroutine clock."""
    assert 0 < start < end, 'invalid interval'
    cuts = []
    for span in spans:
        if span['g'] != goroutine:
            continue
        lo = max(start, span['begin']['time'])
        hi = min(end, span['end']['time'])
        if lo < hi:
            assert span['state'] in ('Running', 'Runnable', 'Waiting', 'Syscall'), 'unknown state'
            cuts.append((lo, hi, span['state']))
    cursor = start
    result = {state: 0 for state in ('Running', 'Runnable', 'Waiting', 'Syscall')}
    for lo, hi, state in sorted(cuts):
        assert lo == cursor, 'overlapping or incomplete state coverage'
        result[state] += hi - lo
        cursor = hi
    assert cursor == end, 'missing terminal coverage'
    assert sum(result.values()) == end - start
    return result


def verify(base=ROOT):
    result = json.loads((base / 'probe-result.json').read_text())
    assert result['go_version'] == 'go1.25.11'
    assert result['goos'] == 'darwin' and result['goarch'] == 'arm64'
    assert result['gomaxprocs'] == 1 and result['passed']
    phases = result['phases']
    assert [p['mode'] for p in phases] == ['os-sync', 'scheduled-fullfsync']
    trace = base / 'probe.trace'
    assert 0 < trace.stat().st_size <= 8 << 20
    decoded = list(events(base / 'probe.parsed.txt'))
    logs, spans, previous = [], [], {}
    for event in decoded:
        match = LOG.search(event['detail']) if event['kind'] == 'Log' else None
        if match and json.loads(match[1]) == 'wk977.syncprobe':
            logs.append({**event, 'message': json.loads(json.loads(match[2]))})
        state = STATE.search(event['detail']) if event['kind'] == 'StateTransition' else None
        if state:
            goroutine, before, after = int(state[1]), state[2], state[3]
            prior = previous.get(goroutine)
            if prior:
                assert prior[0] == before and prior[1]['time'] <= event['time']
                spans.append({'g': goroutine, 'state': before, 'begin': prior[1], 'end': event})
            previous[goroutine] = (after, event)
    assert len(logs) == 64, 'missing or extra markers'
    summary = []
    for phase in phases:
        assert phase['completed'] == 16 and phase['fallback_count'] == 0
        assert len(phase['operations']) == 16
        for index, operation in enumerate(phase['operations']):
            assert operation['index'] == index and not operation['error']
            selected = [x for x in logs if x['message']['mode'] == phase['mode']
                        and x['message']['index'] == index]
            assert [x['message']['phase'] for x in selected] == ['begin', 'end']
            begin, end = selected
            assert begin['g'] == end['g'] and end['message']['error'] is False
            coverage = partition(spans, begin['g'], begin['time'], end['time'])
            summary.append({'mode': phase['mode'], 'index': index, 'goroutine': begin['g'],
                            'sync_api_trace_ns': end['time'] - begin['time'],
                            'goroutine_state_ns': coverage, 'scope': 'elapsed trace states, not CPU or exclusive kernel time'})
    return {'passed': True, 'completed_syncs': 32, 'operations': summary,
            'qualification_replacement': False, 'fallback_exercised': False}


if __name__ == '__main__':
    try:
        print(json.dumps(verify(), indent=2))
    except (AssertionError, OSError, ValueError, KeyError) as error:
        print(json.dumps({'passed': False, 'reason': str(error)}))
        sys.exit(1)
