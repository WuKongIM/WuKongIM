"""Verify selected artifact inputs, replayable probe and derived observations."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).parent


def verify(prior, root=ROOT):
    manifest = json.loads((root / 'manifest.json').read_text())
    for name, record in manifest['files'].items():
        raw = (root / name).read_bytes()
        assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'], name
    plan = json.loads((root / 'probe-plan.json').read_text())
    for name, field in [('contract.json', 'contract_sha256'), ('probe.go', 'source_sha256'),
                        ('verify-sync-probe.py', 'verifier_sha256')]:
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == plan[field], name
    assert json.loads((root / 'probe-execution.json').read_text())['exit_code'] == 0
    spec = importlib.util.spec_from_file_location('analysis', root / 'analyze-sync-observations.py')
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    derived = analysis.analyze(prior)
    assert derived == json.loads((root / 'sync-observations.json').read_text()), 'derived output mismatch'
    assert derived['original_acceptance']['exit_code'] == 1
    assert derived['original_acceptance']['failed_sequential_rows'] == 6
    assert not derived['product_fix'] and not derived['qualification_replacement']
    return {'passed': True, 'prior_selected_input': str(prior), 'exact_wal_intervals': 12,
            'probe_syncs': 32, 'linux_histogram_rows': 12, 'original_sequential_failed_rows': 6,
            'scope': 'Selected positive state evidence and retained receipts. Prior raw proposal traces remain unavailable; this bundle cannot re-decode them.'}


if __name__ == '__main__':
    try:
        assert len(sys.argv) == 2, 'provide prior selected archive extraction directory'
        print(json.dumps(verify(Path(sys.argv[1])), indent=2))
    except (AssertionError, OSError, ValueError, KeyError) as error:
        print(json.dumps({'passed': False, 'reason': str(error)}))
        sys.exit(1)
