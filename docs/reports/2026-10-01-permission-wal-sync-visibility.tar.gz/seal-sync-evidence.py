"""Seal fresh deterministic artifacts and verify independent extraction."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).parent
PRIOR = ROOT / 'selected'
REPO = ROOT.parent.parent


def fingerprint(path):
    return {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def seal(path, entries):
    assert not path.exists(), 'never overwrite a sealed artifact'
    with path.open('xb') as file:
        with gzip.GzipFile(fileobj=file, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for name, source in sorted(entries.items()):
                    raw = source.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(raw))


def main():
    excluded = {'linux-mixed-artifact.zip', 'original-sequential.tar.gz', 'sync-probe', 'manifest.json'}
    entries = {}
    for directory in ('source', 'linux'):
        for file in (ROOT / directory).rglob('*'):
            if file.is_file():
                entries[file.relative_to(ROOT).as_posix()] = file
    for file in ROOT.iterdir():
        if file.is_file() and file.name not in excluded and file.suffix in ('.json', '.py', '.go', '.mod', '.sum', '.txt', '.log', '.trace'):
            entries[file.name] = file
    manifest = {'schema': 'wk977-sync-selected/v1',
                'files': {name: fingerprint(file) for name, file in sorted(entries.items())},
                'prior_selected_sha256': 'd4f4db6e0c35f26c4b1c3d9f8585c9b6404b65a9467450f777ab27f74af6e0fd',
                'limitations': ['Extract the prior proposal selected archive separately before verification.',
                                'Prior proposal raw traces are unavailable locally and omitted; historical raw-replay receipts cannot be repeated here.',
                                'Native binary, full x/sys ZIP, original paired archive and Linux Artifact ZIP are retained in the larger local bundle.',
                                'Default os.Sync fallback is not observed. Its raw zero-valued field is a placeholder; only scheduled phase instruments fallback.']}
    (ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    entries['manifest.json'] = ROOT / 'manifest.json'
    selected = ROOT / 'permission-sync-visibility-selected.tar.gz'
    seal(selected, entries)
    full_entries = dict(entries)
    full_entries.update({'native-sync-probe': ROOT / 'sync-probe',
                         'linux-mixed-artifact.zip': ROOT / 'linux-mixed-artifact.zip',
                         'original-sequential.tar.gz': ROOT / 'original-sequential.tar.gz',
                         'previous-proposal-selected.tar.gz': REPO / '.worktrees/issue-977-proposal-wal-evidence/docs/reports/2026-10-01-permission-proposal-wal-diagnostics.tar.gz',
                         'xsys-v0.47.0.zip': ROOT / 'modcache/cache/download/golang.org/x/sys/@v/v0.47.0.zip'})
    (ROOT / 'full-inputs.json').write_text(json.dumps({name: fingerprint(file) for name, file in full_entries.items() if name not in entries}, indent=2) + '\n')
    full_entries['full-inputs.json'] = ROOT / 'full-inputs.json'
    full = ROOT / 'permission-sync-visibility-local.tar.gz'
    seal(full, full_entries)
    results = []
    for mode, archive, members in [('selected', selected, entries), ('local', full, full_entries)]:
        directory = ROOT / ('roundtrip-' + mode)
        directory.mkdir(exist_ok=False)
        with tarfile.open(archive) as reader:
            assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in reader.getmembers())
            reader.extractall(directory, filter='data')
        for name, source in members.items():
            assert (directory / name).read_bytes() == source.read_bytes(), name
        verified = subprocess.run(['python3', str(directory / 'verify-sync-evidence.py'), str(PRIOR)], capture_output=True, text=True, timeout=20)
        assert verified.returncode == 0, verified.stdout + verified.stderr
        results.append({'mode': mode, 'members': len(members), **fingerprint(archive), 'roundtrip_byte_identical': True, 'verification': json.loads(verified.stdout)})
    persistent = Path('/Users/tt/.codex/artifacts/issue-977-sync-20261001')
    persistent.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(full, persistent / full.name)
    assert fingerprint(full) == fingerprint(persistent / full.name)
    receipt = {'archives': results, 'persistent_local_bundle': str(persistent / full.name),
               'scope': 'Complete inputs for this follow-up; prior proposal raw traces are absent. Not a restored prior full-capture archive.'}
    (ROOT / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
