//go:build darwin

// This disposable process probe preserves full-sync semantics and records
// runtime state visibility. It is not a product benchmark or a power-loss test.
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"runtime/trace"
	"time"

	"golang.org/x/sys/unix"
)

type operation struct {
	Index  int   `json:"index"`
	WallNS int64 `json:"wall_ns"`
	Error  bool  `json:"error"`
}

type phase struct {
	Mode          string      `json:"mode"`
	Completed     int         `json:"completed"`
	FallbackCount int         `json:"fallback_count"`
	Operations    []operation `json:"operations"`
	ProcessCPUMS  float64     `json:"process_cpu_ms"`
}

// boundedWriter limits the diagnostic trace without modifying the data file.
type boundedWriter struct {
	file      *os.File
	remaining int
}

func (w *boundedWriter) Write(p []byte) (int, error) {
	if len(p) > w.remaining {
		return 0, errors.New("trace byte bound exceeded")
	}
	n, err := w.file.Write(p)
	w.remaining -= n
	return n, err
}

// scheduledFullSync uses the same full-sync command and ENOTSUP-only fallback
// as Go 1.25.11, while x/sys enters the runtime syscall boundary. RawConn keeps
// the file descriptor alive across the operation, including concurrent Close.
func scheduledFullSync(file *os.File) (bool, error) {
	conn, err := file.SyscallConn()
	if err != nil {
		return false, err
	}
	var syncErr error
	var fallback bool
	err = conn.Control(func(fd uintptr) {
		for {
			_, syncErr = unix.FcntlInt(fd, unix.F_FULLFSYNC, 0)
			if errors.Is(syncErr, unix.ENOTSUP) {
				fallback = true
				syncErr = unix.Fsync(int(fd))
			}
			if !errors.Is(syncErr, unix.EINTR) {
				break
			}
		}
	})
	if err != nil {
		return fallback, err
	}
	return fallback, syncErr
}

func processCPU() (float64, error) {
	var usage unix.Rusage
	if err := unix.Getrusage(unix.RUSAGE_SELF, &usage); err != nil {
		return 0, err
	}
	return float64(usage.Utime.Sec+usage.Stime.Sec)*1000 + float64(usage.Utime.Usec+usage.Stime.Usec)/1000, nil
}

func runPhase(dir, mode string) (result phase, err error) {
	result.Mode = mode
	file, err := os.CreateTemp(dir, "sync-data-")
	if err != nil {
		return result, err
	}
	defer func() {
		err = errors.Join(err, file.Close(), os.Remove(file.Name()))
	}()
	before, err := processCPU()
	if err != nil {
		return result, err
	}
	payload := make([]byte, 1024)
	for index := 0; index < 16; index++ {
		if n, writeErr := file.Write(payload); writeErr != nil || n != len(payload) {
			return result, errors.Join(writeErr, io.ErrShortWrite)
		}
		trace.Logf(context.Background(), "wk977.syncprobe", `{"mode":%q,"index":%d,"phase":"begin"}`, mode, index)
		start := time.Now()
		var syncErr error
		if mode == "os-sync" {
			syncErr = file.Sync()
		} else {
			var fallback bool
			fallback, syncErr = scheduledFullSync(file)
			if fallback {
				result.FallbackCount++
			}
		}
		wall := time.Since(start).Nanoseconds()
		trace.Logf(context.Background(), "wk977.syncprobe", `{"mode":%q,"index":%d,"phase":"end","error":%t}`, mode, index, syncErr != nil)
		result.Operations = append(result.Operations, operation{index, wall, syncErr != nil})
		if syncErr != nil {
			return result, syncErr
		}
		result.Completed++
	}
	after, err := processCPU()
	result.ProcessCPUMS = after - before
	return result, err
}

func main() {
	dir := flag.String("out", "", "owned artifact directory")
	flag.Parse()
	if *dir == "" {
		panic("missing output directory")
	}
	runtime.GOMAXPROCS(1)
	file, err := os.OpenFile(filepath.Join(*dir, "probe.trace"), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		panic(err)
	}
	if err := trace.Start(&boundedWriter{file: file, remaining: 8 << 20}); err != nil {
		panic(err)
	}
	phases := make([]phase, 0, 2)
	for _, mode := range []string{"os-sync", "scheduled-fullfsync"} {
		result, phaseErr := runPhase(*dir, mode)
		phases = append(phases, result)
		if phaseErr != nil {
			err = phaseErr
			break
		}
	}
	trace.Stop()
	err = errors.Join(err, file.Close())
	result := map[string]any{"go_version": runtime.Version(), "goos": runtime.GOOS, "goarch": runtime.GOARCH,
		"gomaxprocs": runtime.GOMAXPROCS(0), "passed": err == nil, "phases": phases}
	encoded, encodeErr := json.MarshalIndent(result, "", "  ")
	if encodeErr != nil {
		panic(encodeErr)
	}
	if writeErr := os.WriteFile(filepath.Join(*dir, "probe-result.json"), append(encoded, '\n'), 0600); writeErr != nil {
		panic(writeErr)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "sync probe failed")
		os.Exit(1)
	}
}
