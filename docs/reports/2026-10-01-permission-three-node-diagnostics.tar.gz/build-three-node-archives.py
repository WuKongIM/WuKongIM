"""Create immutable flat evidence archives, with explicit retained/omitted scopes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ART = Path(__file__).parent
COMMON = [
    'probe-plan.json', 'source-instructions.json', 'host-decode-timing.json',
    'toolchain-recovery.json', 'module-cache-recovery.json', 'preflight-failure.json',
    'run-three-node-trace.py', 'run-three-node-trace.preflight.py',
    'analyze-three-node-trace.py', 'decode-three-node-trace.py',
    'summarize-three-node-trace.py', 'verify-three-node-evidence.py',
    'build-three-node-archives.py', 'three-node-summary.json', 'three-node-report.md',
    'original-acceptance-replay.json', 'original-acceptance-replay.log',
]
for label in ('old', 'new'):
    COMMON += [f'{label}.{suffix}' for suffix in ('plan.json', 'execution.json', 'report.json',
                                                'timelines.json', 'log', 'decode-receipt.json')]
FULL = []
for label in ('old', 'new'):
    for node in (1, 2, 3):
        FULL += [f'{label}.node-{node}.{suffix}' for suffix in ('trace', 'analysis.json', 'analysis-command.log',
                                                              'parsed.decode.log', 'wire.decode.log')]


def sha(data):
    return hashlib.sha256(data).hexdigest()


receipts = []
for scope in ('full', 'bounded'):
    names = sorted(COMMON + (FULL if scope == 'full' else []))
    assert len(names) == len(set(names))
    files = {name: (ART / name).read_bytes() for name in names}
    manifest = {'scope': scope,
                'performance_qualified': False,
                'raw_trace_count': 6 if scope == 'full' else 0,
                'omissions': [] if scope == 'full' else ['Six raw runtime traces and full analyses; excerpts cannot certify whole-capture absence/coverage.'],
                'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()}}
    files['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    archive = ART / f'permission-remote-three-node-{scope}.tar.gz'
    assert not archive.exists(), 'Never overwrite an observed evidence archive.'
    with archive.open('xb') as out, gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
        for name, data in sorted(files.items()):
            assert '/' not in name and '..' not in name
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
    extracted = ART / f'archive-roundtrip-{scope}'
    extracted.mkdir(exist_ok=False)
    with tarfile.open(archive) as tar:
        assert len(tar.getmembers()) == len(files)
        for member in tar.getmembers():
            assert member.isfile() and member.name in files
            data = tar.extractfile(member).read()
            assert data == files[member.name]
            (extracted / member.name).write_bytes(data)
    command = ['python3', str(extracted / 'verify-three-node-evidence.py')] + (['--bounded'] if scope == 'bounded' else [])
    result = subprocess.run(command, text=True, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    receipts.append({'scope': scope, 'file': archive.name, 'bytes': archive.stat().st_size,
                     'sha256': sha(archive.read_bytes()), 'members': len(files),
                     'retained_raw_runtime_traces': manifest['raw_trace_count'],
                     'omissions': manifest['omissions'],
                     'roundtrip_verifier_exit_code': result.returncode,
                     'roundtrip_verifier_output': result.stdout.strip()})
(ART / 'three-node-archive-receipt.json').write_text(json.dumps({'archives': receipts,
    'distribution': {'bounded': 'Draft PR #991; raw traces explicitly omitted.',
                     'full': str(ART / 'permission-remote-three-node-full.tar.gz')},
    'comparative_verdict': 'FAILED: 6/12 original sequential rows',
    'performance_qualified': False}, indent=2) + '\n')
print(json.dumps(receipts))
