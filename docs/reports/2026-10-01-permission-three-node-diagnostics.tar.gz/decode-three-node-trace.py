import concurrent.futures, datetime, hashlib, json, subprocess, sys
from pathlib import Path
ART = Path(__file__).parent
GO = sys.argv[2] if len(sys.argv) == 3 else str(ART / 'restored-toolchain/bin/go')
label = sys.argv[1]
assert label in ('old', 'new')
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def decode(node):
    receipt = {'label': label, 'node_id': node, 'started_at': utc(), 'commands': []}
    for mode in ('parsed', 'wire'):
        dst = ART / f'{label}.node-{node}.trace.{mode}.txt'
        assert not dst.exists(), 'Do not overwrite derived output from a prior decode.'
        command = [GO, 'tool', 'trace', '-d=' + mode, str(ART / f'{label}.node-{node}.trace')]
        with dst.open('w') as out, (ART / f'{label}.node-{node}.{mode}.decode.log').open('w') as err:
            result = subprocess.run(command, stdout=out, stderr=err, timeout=90)
        receipt['commands'].append({'command': command, 'exit_code': result.returncode, 'output_bytes': dst.stat().st_size, 'output_sha256': hashlib.sha256(dst.read_bytes()).hexdigest()})
        assert result.returncode == 0
    with (ART / f'{label}.node-{node}.analysis-command.log').open('w') as log:
        result = subprocess.run(['python3', str(ART / 'analyze-three-node-trace.py'), label, str(node)], stdout=log, stderr=subprocess.STDOUT, timeout=90)
    receipt['analysis_exit_code'] = result.returncode
    receipt['finished_at'] = utc()
    assert result.returncode == 0
    return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    receipts = list(pool.map(decode, [1, 2, 3]))
(ART / f'{label}.decode-receipt.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(json.dumps(receipts))
