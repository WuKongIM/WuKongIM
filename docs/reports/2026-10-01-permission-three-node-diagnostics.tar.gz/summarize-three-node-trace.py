"""Bounded evidence summary; temporal follower candidates never become request identities."""
import datetime
import hashlib
import json
from pathlib import Path
import re

ART = Path(__file__).parent


def events(path):
    with path.open() as stream:
        for line in stream:
            if line.startswith('M='):
                match = re.match(r'M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)', line.rstrip())
                assert match
                m, p, g, kind, timestamp, detail = match.groups()
                yield {'m': int(m), 'p': int(p), 'g': int(g), 'kind': kind,
                       'time': int(timestamp), 'detail': detail}


def functions(event):
    return list(dict.fromkeys(line.strip().split(' @ ')[0]
                             for line in event['stack'] if ' @ ' in line))


def phase(span, start):
    funcs = functions(span['begin'])
    joined = '\n'.join(funcs)
    if span['state'] != 'Waiting':
        return None
    if 'commitPipeline).publish' in joined:
        category = 'message_commit_sync_publication_wait'
    elif 'Coordinator).submitResult' in joined:
        category = ('follower_exchange_commit_wait_candidate' if 'ExchangeServer).Handle' in joined
                    else 'leader_message_commit_wait')
    elif 'Conn).Call' in joined and 'QuorumPeerLink).Exchange' in joined:
        category = 'leader_quorum_exchange_wait_candidate'
    else:
        return None
    return {'category': category, 'goroutine': span['goroutine'],
            'from_relative_ns': span['from'] - start, 'to_relative_ns': span['to'] - start,
            'duration_ns': span['duration_ns'], 'target_overlap_ns': span['target_overlap_ns'],
            'functions': funcs, 'begin': span['begin'], 'end': span['end']}


nodes = []
for label in ('old', 'new'):
    for node in (1, 2, 3):
        value = json.loads((ART / f'{label}.node-{node}.analysis.json').read_text())
        start, end = value['target_start_trace_ns'], value['target_end_trace_ns']
        ranges, open_ranges, first, last = [], {}, None, None
        for event in events(ART / f'{label}.node-{node}.trace.parsed.txt'):
            timestamp = event['time']
            first = timestamp if first is None else min(first, timestamp)
            last = timestamp if last is None else max(last, timestamp)
            if not event['kind'].startswith('Range'):
                continue
            match = re.search(r'Name="([^"]+)" Scope=(\S+)', event['detail'])
            if not match:
                continue
            name, scope = match.groups()
            key = (name, scope)
            if event['kind'] == 'RangeBegin':
                open_ranges.setdefault(key, []).append(event)
            elif event['kind'] == 'RangeActive':
                if not open_ranges.get(key):
                    open_ranges[key] = [event]
            elif event['kind'] == 'RangeEnd' and open_ranges.get(key):
                begin = open_ranges[key].pop()
                overlap = max(0, min(end, timestamp) - max(start, begin['time']))
                if overlap and ('GC' in name or 'stop-the-world' in name):
                    ranges.append({'name': name, 'scope': scope, 'begin': begin,
                                   'end': event, 'overlap_ns': overlap,
                                   'clipped_start': begin['kind'] == 'RangeActive'})
        assert first <= start <= end <= last, 'Target interval must be covered by every trace.'
        for (name, scope), stack in open_ranges.items():
            for begin in stack:
                overlap = max(0, min(end, last) - max(start, begin['time']))
                if overlap and ('GC' in name or 'stop-the-world' in name):
                    ranges.append({'name': name, 'scope': scope, 'begin': begin,
                                   'end': None, 'overlap_ns': overlap, 'clipped_end': True})
        assert len(ranges) <= 30
        phases = [item for span in value['active_spans'] if (item := phase(span, start))]
        phases.sort(key=lambda item: item['from_relative_ns'])
        assert len(phases) <= 24
        nodes.append({'label': label, 'node_id': node, 'anchor_node_id': 1,
                      'trace_id': value['trace_id'], 'target': value['target'],
                      'target_ack_us': value['target_ack']['elapsed_us'],
                      'leader_task_duration_ns': value['stage']['duration'],
                      'target_start_trace_ns': start, 'target_end_trace_ns': end,
                      'runtime_sync_clocks': value['runtime_sync_clocks'],
                      'offset_spread_ns': value['offset_spread_ns'],
                      'raw_trace_sha256': hashlib.sha256((ART / f'{label}.node-{node}.trace').read_bytes()).hexdigest(),
                      'trace_covers_anchor': True, 'phases': phases,
                      'gc_overlapping_anchor': ranges,
                      'max_relevant_runnable_overlap_ns': max((span['target_overlap_ns'] for span in value['active_spans'] if span['state'] == 'Runnable'), default=0),
                      'selected_rotation_transition_count': sum('rotateWAL' in '\n'.join(event['stack']) for event in value['transitions']),
                      'selected_transition_count': value['relevant_transition_count']})

timing = json.loads((ART / 'host-decode-timing.json').read_text())
new_decode_finished = datetime.datetime.fromisoformat(timing['new_decode_receipt_mtime'])
old_capture_started = min(datetime.datetime.fromisoformat(trace['requested_at']) for trace in json.loads((ART / 'old.execution.json').read_text())['traces'])
assert new_decode_finished < old_capture_started
result = {'target': 'two-remote-leaders-c1-030', 'performance_qualified': False,
          'comparative_verdict': 'FAILED: 6/12 original sequential rows',
          'identity_limits': 'Leader diagnostic stage has exact request identity. Runtime follower/peer stacks have no function arguments; their temporal pairing is an inference and cannot certify exact follower request identity or priority.',
          'clock_limits': 'Runtime ClockSnapshot mapping plus microsecond diagnostic timestamp rounding. Offset spread is measured, not a certified error bound; do not infer cross-node sub-millisecond order.',
          'host_decode_overlap': {'new_decode_receipt_mtime': new_decode_finished.isoformat(),
                                  'old_capture_started_at': old_capture_started.isoformat(),
                                  'new_decode_finished_before_old_capture': True,
                                  'note': 'New decoding overlapped old fixture setup, but completed before its target-phase capture. No comparative qualification is inferred.'},
          'nodes': nodes}
(ART / 'three-node-summary.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'nodes': len(nodes), 'target_covered_everywhere': True,
                  'gc_overlap_counts': [len(node['gc_overlapping_anchor']) for node in nodes],
                  'performance_qualified': False}))
