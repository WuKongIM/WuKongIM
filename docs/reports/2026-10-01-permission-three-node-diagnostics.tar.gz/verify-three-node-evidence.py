"""Verify frozen functional results, capture bounds and evidence scope offline."""
import hashlib
import json
from pathlib import Path
import sys

ART = Path(__file__).parent
BOUNDED = '--bounded' in sys.argv
TARGET = 'two-remote-leaders-c1-030'
REVISIONS = {'new': 'ec21c1a586941ffd74cfb497f0da4522941bc1a4',
             'old': '424d03eb298b972ec572261d617972eecb5523c5'}


def read(name):
    return json.loads((ART / name).read_text())


def unsafe(value):
    if isinstance(value, dict):
        return any(key.lower() in ('from_uid', 'payload', 'token') or unsafe(item)
                   for key, item in value.items())
    return isinstance(value, list) and any(unsafe(item) for item in value)


reports = {}
for label, revision in REVISIONS.items():
    plan, execution, report = [read(f'{label}.{kind}.json') for kind in ('plan', 'execution', 'report')]
    assert plan['runtime_revision'] == report['product_revision'] == revision
    assert plan['driver_revision'] == 'c0e95b5a45babbd1907c590a9dcdab83e74634a9'
    assert plan['target'] == TARGET and plan['binary_sha256'] == report['binary_sha256']
    assert execution['exit_code'] == 0 and execution['empty_owned_tmpdir_removed']
    assert report['passed'] and report['performance_qualified'] is False
    assert report['nodes'] == report['message_replicas'] == 3 and report['metadata_replicas'] == 1
    assert report['hash_slots'] == 256 and report['physical_slots'] == 12
    assert report['node_gomaxprocs'] == report['driver_gomaxprocs'] == 4
    assert len(report['cases']) == 4
    for case in report['cases']:
        assert len(case['exact_history']) == len(set(case['exact_history'])) == 161
        assert set(case['exact_history']) == set(case['expected_history']) and not case['history_has_more']
        assert len(case['after_ban']) == len(case['after_unban']) == 32
        assert all(ack['reason'] == 25 and ack['message_id'] == ack['message_seq'] == 0 and not ack.get('error') for ack in case['after_ban'])
        assert all(ack['reason'] == 1 and ack['message_id'] > 0 and ack['message_seq'] > 0 and not ack.get('error') for ack in case['after_unban'])
        assert [window['concurrency'] for window in case['windows']] == [1, 32]
        for window in case['windows']:
            assert window['completed'] and len(window['acks']) == 64
            assert len({ack['client_msg_no'] for ack in window['acks']}) == 64
            assert all(ack['reason'] == 1 and ack['message_id'] > 0 and ack['message_seq'] > 0 and not ack.get('error') for ack in window['acks'])
            assert window['counts']['plans'] == window['counts']['messages'] == 64
            assert window['counts']['facts'] == 128
            assert all(window['counts'][key] == 0 for key in ('barrier_failed', 'admission_busy', 'cohort_busy'))
    case = next(case for case in report['cases'] if case['name'] == 'two-remote-leaders')
    assert case['channel_runtime']['leader'] == 1 and case['ingress'] == 3
    assert sum(ack['client_msg_no'] == TARGET for ack in case['windows'][0]['acks']) == 1
    assert len(execution['traces']) == 3 and {trace['node_id'] for trace in execution['traces']} == {1, 2, 3}
    for trace in execution['traces']:
        assert not trace.get('error_type') and not trace['oversized'] and trace['complete_http_response']
        assert trace['seconds'] == 4 and 0 < trace['bytes'] <= trace['limit_bytes'] == 16 << 20
        path = ART / f"{label}.node-{trace['node_id']}.trace"
        if not BOUNDED:
            assert path.stat().st_size == trace['bytes']
            assert hashlib.sha256(path.read_bytes()).hexdigest() == trace['sha256']
    assert execution['queries_executed'] == 3 and not execution['query_errors']
    timelines = read(f'{label}.timelines.json')
    assert {item['node_id'] for item in timelines} == {1, 2, 3}
    for item in timelines:
        reply = item['reply']
        assert not unsafe(reply) and reply['node_id'] == item['node_id']
        assert reply['client_msg_no'] == TARGET and len(reply['events']) < 32
        assert all(event['client_msg_no'] == TARGET and event.get('duration', 0) >= 0 for event in reply['events'])
    reports[label] = report

assert reports['old']['harness_sources'] == reports['new']['harness_sources']
assert reports['old']['harness_sha256'] == reports['new']['harness_sha256']
assert reports['old']['cpu_probe_sha256'] == reports['new']['cpu_probe_sha256']
assert reports['old']['topology_fingerprint'] == reports['new']['topology_fingerprint']
for node in ('1', '2', '3'):
    configs = [{key: value for key, value in report['node_configs'][node]['overrides'].items() if key != 'WK_PLUGIN_SOCKET_PATH'} for report in reports.values()]
    assert configs[0] == configs[1]
summary = read('three-node-summary.json')
assert summary['target'] == TARGET and summary['performance_qualified'] is False
assert len(summary['nodes']) == 6
for node in summary['nodes']:
    assert node['trace_covers_anchor'] and not node['gc_overlapping_anchor']
    for phase in node['phases']:
        if phase['category'] == 'message_commit_sync_publication_wait':
            assert 'LogWriter).flushPending' in '\n'.join(phase['end']['stack'])
            assert 'pendingSyncsWithSyncQueue).pop' in '\n'.join(phase['end']['stack'])
    assert node['selected_rotation_transition_count'] == 0
    assert node['selected_transition_count'] < 300
    assert node['max_relevant_runnable_overlap_ns'] < 20_000
    if not BOUNDED:
        analysis = read(f"{node['label']}.node-{node['node_id']}.analysis.json")
        assert len(analysis['active_spans']) < 120
        assert analysis['target_start_trace_ns'] == node['target_start_trace_ns']
replay = read('original-acceptance-replay.json')
assert replay['exit_code'] == 1 and replay['failed_sequential_rows'] == 6
assert not replay['source_archive_modified']
if (ART / 'manifest.json').exists():
    for name, item in read('manifest.json')['files'].items():
        path = ART / name
        assert path.stat().st_size == item['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
print(json.dumps({'functional_runs_passed': 2, 'placements_checked': 8,
                  'raw_trace_hashes_verified': 0 if BOUNDED else 6,
                  'bounded_scope': BOUNDED,
                  'original_comparative_verdict': 'FAILED: 6/12 sequential rows',
                  'performance_qualified': False}))
