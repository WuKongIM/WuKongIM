#!/opt/homebrew/bin/python3
import os,sys
from pathlib import Path
count=Path(os.environ["WK_E2E_CPU_FAILURE_CONTROL_FILE"])
if count.exists():sys.exit(3)
count.write_text("first cut completed\n")
os.execv(os.environ["WK_E2E_CPU_FAILURE_NATIVE"],[os.environ["WK_E2E_CPU_FAILURE_NATIVE"],*sys.argv[1:]])
