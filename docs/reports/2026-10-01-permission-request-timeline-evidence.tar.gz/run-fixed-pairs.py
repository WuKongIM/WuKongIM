import os, subprocess, json, hashlib, datetime
from pathlib import Path
root=Path("/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM")
art=root/"tmp/issue-977-request-timeline-20260930"
wd=root/".worktrees/issue-977-permission-cohorts"
old=root/"tmp/issue-977-permission-baseline-20260930/wukongim-424d03eb2"
new=art/"wukongim-fixed-source-bound"
probe=art/"permission-cpu-darwin"
base={k:v for k,v in os.environ.items() if not k.startswith("WK_E2E_PERMISSION_")}
base.update(GOWORK="off",GOMAXPROCS="4",GOMODCACHE=str(root/"tmp/issue-977-permission-baseline-20260930/modcache"),WK_E2E_PERMISSION_CPU_PROBE=str(probe))
plan={"order":[f"{side}-fixed-pair-{i}" for i in range(1,4) for side in ["old","new"]],"old_revision":"424d03eb298b972ec572261d617972eecb5523c5","new_revision":"4a5f667447217e4336dfbe58514f2f565530d6b7","profiles":False,"timeline":False,"histogram_extra_families":False,"threshold_percent":5,"acceptance_scope":"the original concurrency-32 table: all four placements in each of three old/new pairs; sequential timing and CPU also retained descriptively, exact functional and count controls mandatory","workload":"unchanged 64 sends per window, 32 sessions, two joined 32-caller waves; original ownership sampler remains; CPU probe cut overhead retained","binary_sha256":{side:hashlib.sha256(path.read_bytes()).hexdigest() for side,path in [("old",old),("new",new),("probe",probe)]},"started_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
plan["runner_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
assert not (art/"fixed-pair-plan.json").exists(),"never overwrite a planned receipt"
(art/"fixed-pair-plan.json").write_text(json.dumps(plan,indent=2)+"\n")
runs=[]
for i in range(1,4):
 for side in ["old","new"]:
  label=f"{side}-fixed-pair-{i}"
  env=base.copy();env["WK_E2E_BINARY"]=str(old if side=="old" else new)
  kind="BASELINE" if side=="old" else "COHORT"
  if side=="old":env.update(WK_E2E_PERMISSION_BASELINE="1",WK_E2E_PERMISSION_BASELINE_REPORT=str(art/(label+".json")))
  else:env.update(WK_E2E_PERMISSION_COHORTS="1",WK_E2E_PERMISSION_COHORT_REPORT=str(art/(label+".json")))
  cmd=["go","test","-tags=e2e","./test/e2e/message/send_ban","-run","^TestPermissionCaller"+("Baseline" if side=="old" else "Cohorts")+"$","-count=1","-timeout=4m","-p=1","-v"]
  with (art/(label+".log")).open("w") as log:code=subprocess.call(cmd,cwd=wd,env=env,stdout=log,stderr=subprocess.STDOUT)
  runs.append({"label":label,"exit_code":code,"command":cmd,"report":str(art/(label+".json")),"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat()})
  (art/"fixed-pair-execution.json").write_text(json.dumps(runs,indent=2)+"\n")
  print(label,"exit",code,flush=True)
  # Every predetermined run is retained, including failed runs. Never retry.
