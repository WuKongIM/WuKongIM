from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parent
out={}
for n in ["timeline","cpu"]:
 f=p/(n+"-failure-retained.json");j=json.loads(f.read_text());w=j["cases"][0]["windows"][-1]
 assert not j["passed"] and len(w["acks"])==64 and w["started_at"] and w["finished_at"] and "cohort_ownership_samples" in w
 if n=="timeline":
  assert len(w["request_timelines"])==64
  nodes=[v for req in w["request_timelines"] for v in req["nodes"].values()]
  assert len(nodes)==192 and sum(v["status"]=="query_failed" for v in nodes)==1
  assert len(j["cases"][0]["exact_history"])==161 and not j["cases"][0]["history_has_more"]
  assert set(j["cases"][0]["exact_history"])==set(j["cases"][0]["expected_history"])
  out[n]={"safe_queries":191,"explicit_failed_queries":1,"acks":64,"exact_history":161,"negative_scenario_failed_as_expected":True}
 else:
  assert "cpu_before" in w and "cluster_cpu_ns" not in w
  out[n]={"acks":64,"sampler_joined_and_retained":True,"missing_cpu_interval_not_zero":True,"negative_scenario_failed_as_expected":True}
 out[n]["report_sha256"]=hashlib.sha256(f.read_bytes()).hexdigest()
(p/"negative-receipt-verdict.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))
