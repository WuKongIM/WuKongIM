"""Standard-library evidence replay; optional independent raw Go trace decoding."""
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
v=importlib.import_module('verify-boundaries')
rotation=importlib.import_module('derive-rotation')

def verify(root):
    root=Path(root);manifest=json.loads((root/'manifest.json').read_text())
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.json'}
    assert actual==set(manifest['files']), 'unlisted/missing artifact'
    for name,binding in manifest['files'].items():
        path=root/name
        assert not path.is_symlink() and path.stat().st_size==binding['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest()==binding['sha256'], ('changed artifact',name)
    for label in ('old','new'):
        assert json.loads(json.dumps(v.verify(root,label)))==json.loads((root/f'{label}.final-verdict.json').read_text())
        states=json.loads((root/f'{label}.rotation-final.json').read_text())
        for n in (1,2,3):
            es=v.read_events(root/f'{label}.node-{n}.events.txt')
            schedule=json.loads((root/f'{label}.node-{n}.scheduling.json').read_text())
            nd=states['nodes'][str(n)]
            assert len(nd['sync_states'])==64
            for o,recorded in enumerate(nd['sync_states']):
                x=v.node_lineage(es,o);sb,se=x['wal'][3:5]
                assert recorded['ordinal']==o and recorded['g']==sb['g']
                assert recorded['interval']==[sb['time'],se['time']]
                assert rotation.cover(schedule['spans'],sb['g'],sb['time'],se['time'])=={k:recorded[k] for k in ('states_ns','spans')}
            for detail in nd['rotations']:
                x=v.node_lineage(es,detail['ordinal']);begin,end=x['physical'];append=x['wal'][0]
                assert detail['g']==begin['g'] and detail['commit_stats_rotation_ns']==end['rotation_ns']>0
                assert detail['physical_begin_to_append_ns']==append['time']-begin['time']
                coverage=detail['state_coverage'];spans=[{**s,'g':begin['g']} for s in coverage['spans']]
                assert rotation.cover(spans,begin['g'],begin['time'],append['time'])==coverage
                sb,se=detail['old_wal_close_markers']
                assert sb in es and se in es and se['time']-sb['time']==detail['old_wal_close_sync_ns']
    raw=[p for p in root.glob('*.trace')]
    assert len(raw)==(6 if manifest['raw_traces_included'] else 0)
    if raw:
        for label in ('old','new'):
            for n in (1,2,3):
                path=root/f'{label}.node-{n}.trace';schedule=json.loads((root/f'{label}.node-{n}.scheduling.json').read_text())
                assert hashlib.sha256(path.read_bytes()).hexdigest()==schedule['raw_sha256']
    # The unchanged original verifier writes its verdict, so execute it only
    # inside a disposable copy and require the recorded rejection byte-for-byte.
    with tempfile.TemporaryDirectory(prefix='wk977-original-replay-') as tmp:
        out=Path(tmp)/'original';shutil.copytree(root/'original',out)
        run=subprocess.run([sys.executable,str(out/'verify-reviewed-pairs.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
        assert run.returncode==1
        assert (out/'reviewed-pair-verdict.json').read_bytes()==(root/'original/reviewed-pair-verdict.json').read_bytes()
        original=json.loads((out/'reviewed-pair-verdict.json').read_text())
        assert len(original['sequential_over_threshold'])==6 and original['burst_gate_passed'] and not original['all_performance_gates_passed']
    return {'passed':True,'functional_placements':8,'exact_proposals':128,'node_lineages':384,
            'raw_traces_present':bool(raw),'raw_traces_redecoded':False,'files':len(actual),
            'original_acceptance':'unchanged six sequential failures; see retained original verifier'}

def redecode(go):
    with tempfile.TemporaryDirectory(prefix='wk977-raw-replay-') as tmp:
        out=Path(tmp)
        for name in ['plan.json','old.json','new.json','verify-boundaries.py']:
            shutil.copy2(ROOT/name,out/name)
        for raw in ROOT.glob('*.trace'):shutil.copy2(raw,out/raw.name)
        assert len(list(out.glob('*.trace')))==6
        decode=importlib.import_module('decode-boundaries')
        for label in ('old','new'):
            for node in (1,2,3):decode.decode(out,label,node,go)
            assert json.loads(json.dumps(v.verify(out,label)))==json.loads((ROOT/f'{label}.final-verdict.json').read_text())
            assert json.loads(json.dumps(rotation.derive(out,label,go)))==json.loads((ROOT/f'{label}.rotation-final.json').read_text())
    return True

if __name__=='__main__':
    result=verify(ROOT)
    if '--redecode' in sys.argv:
        assert '--go' in sys.argv
        result['raw_traces_redecoded']=redecode(sys.argv[sys.argv.index('--go')+1])
    print(json.dumps(result,indent=2))
