"""Re-decode immutable Go1.25.11 runtime traces without executing the product."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

HEADER = re.compile(r'M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)')
STATE = re.compile(r'Resource=Goroutine\((\d+)\).* (\w+)->(\w+)')
LOG = re.compile(r'Category=("(?:[^"\\]|\\.)*") Message=("(?:[^"\\]|\\.)*")')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def decode(root, label, node, go):
    root = Path(root)
    raw = root/f'{label}.node-{node}.trace'
    parsed = root/f'{label}.node-{node}.parsed.txt'
    wire = root/f'{label}.node-{node}.wire.txt'
    assert 0 < raw.stat().st_size <= 16<<20
    assert not parsed.exists() and not wire.exists()
    env = dict(os.environ, GOTOOLCHAIN='local', GOWORK='off')
    for mode, output in [('parsed',parsed),('wire',wire)]:
        with output.open('x') as f:
            subprocess.run([go,'tool','trace','-d='+mode,str(raw)],stdout=f,stderr=subprocess.PIPE,env=env,check=True,timeout=60)
        assert output.stat().st_size <= 150<<20, 'decoded byte cap'
    custom, syncs, last_time = [], [], 0
    logs = root/f'{label}.node-{node}.events.txt'
    assert not logs.exists()
    with logs.open('x') as out:
        for line in parsed.open():
            m = HEADER.match(line)
            if not m: continue
            time = int(m[5]); last_time=max(time,last_time)
            if m[4] == 'Sync':
                s=re.search(r'Trace=(\d+) Mono=(\d+)',m[6])
                if s: syncs.append({'trace':int(s[1]),'mono':int(s[2])})
            if ' Category="wk977.' not in line: continue
            out.write(line)
            log = LOG.search(line); assert log
            custom.append({'g':int(m[3]),'time':time,'category':json.loads(log[1]),**json.loads(json.loads(log[2]))})
    assert logs.stat().st_size <= 8<<20 and len(custom) <= 20480
    owned={e['g'] for e in custom if e['phase']=='sync_begin'}
    previous, spans, ranges = {}, [], []
    for line in parsed.open():
        m = HEADER.match(line)
        if not m: continue
        time = int(m[5])
        if m[4].startswith('Range'):
            # Fixed runtime range names only; no stack, user string or payload.
            name=re.search(r'Name=("(?:[^"\\]|\\.)*")',m[6])
            if name: ranges.append({'kind':m[4],'time':time,'name':json.loads(name[1])})
        if m[4] != 'StateTransition': continue
        s=STATE.search(m[6])
        if not s or int(s[1]) not in owned or s[2] == s[3]: continue
        g=int(s[1]); old=previous.get(g)
        if old and time>old['time']: spans.append({'g':g,'state':old['state'],'begin':old['time'],'end':time})
        previous[g]={'state':s[3],'time':time}
    for g, old in previous.items():
        if last_time>old['time']: spans.append({'g':g,'state':old['state'],'begin':old['time'],'end':last_time})
    assert len(spans) <= 40000 and len(ranges) <= 2000
    clocks=[]
    for line in wire.open():
        m=re.match(r'ClockSnapshot dt=\d+ mono=(\d+) sec=(\d+) nsec=(\d+)',line)
        if m:
            mono,sec,nsec=map(int,m.groups());clocks.append({'mono':mono,'wall_ns':sec*1_000_000_000+nsec})
    assert syncs and clocks and len(syncs) <= 100 and len(clocks) <= 100
    mappings=[]
    for sync in syncs:
        clock=min(clocks,key=lambda x:abs(x['mono']-sync['mono']))
        mappings.append({'trace':sync['trace'],'wall_offset':clock['wall_ns']-clock['mono']+sync['mono']-sync['trace']})
    result={'label':label,'node':node,'runtime_clocks':mappings,
            'offset_spread_ns':max(x['wall_offset'] for x in mappings)-min(x['wall_offset'] for x in mappings),
            'raw_sha256':sha(raw),'parsed_sha256':sha(parsed),'wire_sha256':sha(wire),
            'events_sha256':sha(logs),'custom_event_count':len(custom),
            'wal_goroutines':sorted(owned),'spans':spans,'ranges':ranges}
    (root/f'{label}.node-{node}.scheduling.json').write_text(json.dumps(result,indent=2)+'\n')
    parsed.unlink();wire.unlink()
    print(json.dumps({'label':label,'node':node,'events':len(custom),'states':len(spans),'ranges':len(ranges)}),flush=True)

if __name__ == '__main__':
    for node in (1,2,3): decode(sys.argv[1],sys.argv[2],node,sys.argv[3])
