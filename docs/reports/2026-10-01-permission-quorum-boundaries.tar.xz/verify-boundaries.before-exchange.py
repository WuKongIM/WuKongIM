"""Fail-closed offline contract, written before the owned runtime probe."""
import json
from pathlib import Path
import re
import sys

FORBIDDEN = {'payload', 'from_uid', 'token', 'channel_id', 'client_msg_no'}
LIMITS = {'wk977.proposal': 4096, 'wk977.bridge': 2048,
          'wk977.physical': 2048, 'wk977.wal': 12288}
LOG = re.compile(r'G=(-?\d+) Log Time=(\d+).*Category=("(?:[^"\\]|\\.)*") Message=("(?:[^"\\]|\\.)*")')

def safe(value):
    if isinstance(value, dict):
        assert not FORBIDDEN.intersection(value), 'unsafe diagnostic field'
        for v in value.values(): safe(v)
    elif isinstance(value, list):
        for v in value: safe(v)

def read_events(path):
    events = []
    for line in Path(path).read_text().splitlines():
        m = LOG.search(line)
        if not m: continue
        category = json.loads(m[3])
        if not category.startswith('wk977.'): continue
        data = json.loads(json.loads(m[4]))
        safe(data)
        assert data['phase'] != 'cap', 'event cap reached'
        assert category in LIMITS, 'unknown diagnostic category'
        events.append({'g': int(m[1]), 'time': int(m[2]), 'category': category, **data})
    assert events, 'missing diagnostic events'
    for category, limit in LIMITS.items():
        assert sum(e['category'] == category for e in events) <= limit
    return events

def one(events, phase):
    found = [e for e in events if e['phase'] == phase]
    assert len(found) == 1, (phase, len(found))
    return found[0]

def ordered(*events):
    times = [e['time'] for e in events]
    assert times == sorted(times), ('reversed phase boundaries', times)

def probe_contract(events):
    # Previous positive-only lineage lacks these actual protocol boundaries.
    assert any(e['phase'] == 'round_begin' for e in events), 'missing actual quorum start'
    assert any(e['phase'] == 'round_terminal' for e in events), 'missing quorum terminal callback'
    assert any(e['phase'] == 'reactor_publish' for e in events), 'missing reactor publication'

def node_lineage(events, ordinal):
    proposal = [e for e in events if e['category'] == 'wk977.proposal' and e.get('ordinal') == ordinal]
    ids = {(e['cmd'], e['digest'], e['base'], e['last']) for e in proposal}
    assert len(ids) == 1, ('proposal identity mismatch', ordinal, ids)
    cmd, digest, base, last = next(iter(ids))
    assert re.fullmatch(r'[0-9a-f]{64}', cmd) and re.fullmatch(r'[0-9a-f]{64}', digest)
    assert (base, last) == (ordinal+1, ordinal+2), 'unexpected proposal range'
    submit, build, publish, finish = [one(proposal, phase) for phase in ('submit', 'build', 'publish', 'submit_end')]
    physical = [e for e in events if e['category'] == 'wk977.physical' and e['group'] == build['group']]
    begin, end = one(physical, 'commit_begin'), one(physical, 'commit_end')
    ordered(submit, build, begin, end, publish, finish)
    assert build['group'] > 0 and end['seq'] > 0
    appends = [e for e in events if e['category'] == 'wk977.wal' and e['phase'] == 'append' and e['db'] == end['db'] and e['seq'] == end['seq']]
    append = one(appends, 'append')
    wal = [e for e in events if e['category'] == 'wk977.wal' and e.get('stream') == append['stream']]
    syncs = [e for e in wal if e['phase'] == 'sync_begin' and e['written'] >= append['end'] and e['time'] <= end['time']]
    assert syncs, 'missing covering WAL sync'
    sb = min(syncs, key=lambda e: e['time'])
    se = one([e for e in wal if e.get('op') == sb['op']], 'sync_end')
    writes = [e for e in wal if e['phase'] == 'write_end' and e['written'] >= append['end'] and e['time'] <= sb['time']]
    assert writes, 'missing covering WAL write'
    we = min(writes, key=lambda e: e['time'])
    wb = one([e for e in wal if e.get('op') == we['op']], 'write_begin')
    assert we['n'] > 0 and not we['error'] and not se['error']
    releases = [e for e in wal if e['phase'] == 'release_end' and se['time'] <= e['time'] <= end['time'] and e['written'] >= append['end']]
    assert releases, 'missing covered sync waiter release'
    release = min(releases, key=lambda e: e['time'])
    assert not release['error']
    ordered(begin, append, end)
    ordered(begin, sb, se, release, end)
    return {'identity': [cmd, digest, base, last], 'proposal': proposal,
            'physical': [begin, end], 'wal': [append, wb, we, sb, se, release]}

def verify(root, label):
    root = Path(root)
    report = json.loads((root/f'{label}.json').read_text())
    assert report['passed'] and not report['performance_qualified']
    cases = report['cases']
    names = ['same-slot-remote', 'two-slots-one-remote-leader', 'two-remote-leaders', 'two-slots-local-leader']
    assert [c['name'] for c in cases] == names
    for c in cases:
        assert len(c['exact_history']) == len(set(c['exact_history'])) == 161
        assert set(c['exact_history']) == set(c['expected_history'])
        assert len(c['after_ban']) == len(c['after_unban']) == 32
        assert all(a['reason'] != 1 and a['message_id'] == a['message_seq'] == 0 for a in c['after_ban'])
        for w in c['windows']:
            assert w['completed'] and len(w['acks']) == 64
            assert all(a['reason'] == 1 and a['message_id'] > 0 and a['message_seq'] > 0 and not a.get('error') for a in w['acks'])
    target = cases[1]['windows'][0]
    assert target['concurrency'] == 1 and len(target['quorum_traces']) == 3
    all_events, clocks = {}, {}
    for n in (1, 2, 3):
        all_events[n] = read_events(root/f'{label}.node-{n}.events.txt')
        clocks[n] = json.loads((root/f'{label}.node-{n}.scheduling.json').read_text())
        assert clocks[n]['offset_spread_ns'] <= 2_000_000
    leader = 2
    assert cases[1]['channel_runtime']['leader'] == leader
    probe_contract(all_events[leader])
    rows = []
    for ordinal, ack in enumerate(target['acks']):
        assert ack['client_msg_no'] == f'two-slots-one-remote-leader-c1-{ordinal:03d}'
        nodes = {n: node_lineage(all_events[n], ordinal) for n in (1, 2, 3)}
        assert len({tuple(x['identity']) for x in nodes.values()}) == 1
        cmd = nodes[leader]['identity'][0]
        assert ack['message_seq'] == nodes[leader]['identity'][3]
        p = nodes[leader]['proposal']
        begin, terminal, callback, receipt = [one(p, x) for x in ('round_begin', 'round_terminal', 'quorum_callback', 'quorum_receipt')]
        ordered(begin, terminal, callback, receipt)
        assert terminal['quorum'] == 2 and terminal['votes'] >= terminal['quorum'] and terminal['local_durable'] and not terminal['error']
        votes = [e for e in p if e['phase'] == 'vote']
        assert len(votes) == terminal['votes'] and len({e['peer'] for e in votes}) == len(votes)
        assert any(e['peer'] == leader for e in votes)
        assert all(e['durable'] and not e['error'] for e in votes)
        assert all(begin['time'] <= e['time'] <= terminal['time'] for e in votes)
        bridge = [e for e in all_events[leader] if e['category'] == 'wk977.bridge' and e.get('ordinal') == ordinal]
        assert all(e['cmd'] == cmd and not e['error'] for e in bridge)
        submit, run, complete, reactor, publish = [one(bridge, x) for x in ('reactor_submit', 'worker_run', 'worker_complete', 'reactor_result', 'reactor_publish')]
        ordered(submit, run, begin, terminal, receipt, complete, reactor, publish)
        for follower in (1, 3):
            sent = [e for e in p if e.get('peer') == follower and e['phase'].startswith('peer_')]
            enqueue, send, returned = [one(sent, x) for x in ('peer_enqueue', 'peer_begin', 'peer_end')]
            received = nodes[follower]['proposal']
            recv, reply = one(received, 'receive'), one(received, 'receive_end')
            assert (send['request'],send['priority']) == (recv['request'],recv['priority'])
            assert recv['peer'] == reply['peer'] == leader
            ordered(enqueue, send, returned)
            ordered(recv, nodes[follower]['physical'][0], nodes[follower]['physical'][1], reply)
        def wall(n, e):
            return e['time'] + clocks[n]['runtime_clocks'][0]['wall_offset']
        phases = {'task_ms': (publish['time']-submit['time'])/1e6,
                  'worker_queue_ms': (run['time']-submit['time'])/1e6,
                  'round_ms': (terminal['time']-begin['time'])/1e6,
                  'terminal_to_reactor_ms': (reactor['time']-terminal['time'])/1e6,
                  'reactor_publish_ms': (publish['time']-reactor['time'])/1e6}
        stage_nodes = {}
        for n, x in nodes.items():
            sub, build, pub, end = [one(x['proposal'], s) for s in ('submit', 'build', 'publish', 'submit_end')]
            cb, ce = x['physical']; app, wb, we, sb, se, release = x['wal']
            stage_nodes[n] = {'observed_vote': any(e['peer'] == n for e in votes),
                             'sync_ms': (se['time']-sb['time'])/1e6,
                             'store_collect_ms': (build['time']-sub['time'])/1e6,
                             'pre_sync_ms': (sb['time']-cb['time'])/1e6,
                             'sync_to_physical_end_ms': (ce['time']-se['time'])/1e6,
                             'sync_begin_wall_ns': wall(n,sb), 'sync_end_wall_ns': wall(n,se),
                             'sync_g': sb['g'], 'sync_interval': [sb['time'],se['time']]}
        rows.append({'ordinal': ordinal, 'ack_us': ack['elapsed_us'], 'identity': nodes[leader]['identity'],
                     'phases': phases, 'nodes': stage_nodes, 'votes': votes,
                     'leader_trace_origin': submit['time'], 'leader_wall_origin': wall(leader,submit)})
    slowest = max(rows, key=lambda x: x['ack_us'])
    return {'passed': True, 'label': label, 'requests': rows, 'slowest': slowest,
            'functional_placements': 4, 'diagnostic_only': True}

if __name__ == '__main__':
    try:
        if sys.argv[1] == '--negative':
            probe_contract(read_events(sys.argv[2]))
            result = {'passed': True}
        else:
            result = verify(sys.argv[1], sys.argv[2])
        print(json.dumps(result, indent=2))
    except (AssertionError, KeyError, ValueError) as e:
        print(json.dumps({'passed': False, 'reason': str(e)}))
        sys.exit(1)
