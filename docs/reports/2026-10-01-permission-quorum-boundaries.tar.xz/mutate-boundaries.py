"""Reject corrupted artifact copies; never rerun or mutate a live fixture."""
import hashlib
import importlib
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));v=importlib.import_module('verify-boundaries')

def mutate_event(root,phase,transform,node=2):
    path=root/f'new.node-{node}.events.txt';lines=path.read_text().splitlines(True)
    for i,line in enumerate(lines):
        m=v.LOG.search(line)
        if not m:continue
        data=json.loads(json.loads(m[4]))
        if data.get('phase')!=phase or data.get('ordinal',38)!=38:continue
        data=transform(data)
        if data is None:lines.pop(i)
        else:lines[i]=line[:m.start(4)]+json.dumps(json.dumps(data,separators=(',',':')))+line[m.end(4):]
        break
    else:raise AssertionError(('mutation target missing',phase))
    path.write_text(''.join(lines))
    # Keep the primitive hash consistent so structural checks must reject it.
    schedule=root/f'new.node-{node}.scheduling.json';d=json.loads(schedule.read_text());d['events_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();schedule.write_text(json.dumps(d))

def report_change(root,key,value):
    path=root/'new.json';d=json.loads(path.read_text());d[key]=value;path.write_text(json.dumps(d))

def history_change(root):
    path=root/'new.json';d=json.loads(path.read_text());d['cases'][1]['exact_history'][0]='foreign-message';path.write_text(json.dumps(d))

cases=[('missing_terminal',lambda r:mutate_event(r,'round_terminal',lambda d:None)),
       ('foreign_command',lambda r:mutate_event(r,'reactor_result',lambda d:{**d,'cmd':'00'*32})),
       ('foreign_digest',lambda r:mutate_event(r,'quorum_receipt',lambda d:{**d,'digest':'00'*32})),
       ('nonlocal_proof',lambda r:mutate_event(r,'vote',lambda d:{**d,'peer':3})),
       ('false_local_proof',lambda r:mutate_event(r,'round_terminal',lambda d:{**d,'local_durable':False})),
       ('false_quorum',lambda r:mutate_event(r,'round_terminal',lambda d:{**d,'votes':1})),
       ('unsafe_payload',lambda r:mutate_event(r,'round_begin',lambda d:{**d,'payload':'unsafe'})),
       ('cap_marker',lambda r:mutate_event(r,'round_begin',lambda d:{**d,'phase':'cap'})),
       ('missing_wal_sync',lambda r:mutate_event(r,'sync_end',lambda d:None)),
       ('wrong_peer_request',lambda r:mutate_event(r,'peer_end',lambda d:{**d,'request':-1})),
       ('foreign_product',lambda r:report_change(r,'product_revision','00'*20)),
       ('wrong_history',history_change)]
results=[]
inputs=['plan.json','new.json']+[f'new.node-{n}.{suffix}' for n in (1,2,3) for suffix in ('events.txt','scheduling.json')]
for name,mutate in cases:
    with tempfile.TemporaryDirectory(prefix='wk977-mutant-') as tmp:
        root=Path(tmp)
        for path in inputs:shutil.copy2(ROOT/path,root/path)
        mutate(root)
        try:v.verify(root,'new')
        except (AssertionError,KeyError,ValueError) as e:results.append({'case':name,'rejected':True,'reason':str(e)})
        else:raise AssertionError(('corrupt evidence was accepted',name))
print(json.dumps({'passed':True,'mutations':results},indent=2))
