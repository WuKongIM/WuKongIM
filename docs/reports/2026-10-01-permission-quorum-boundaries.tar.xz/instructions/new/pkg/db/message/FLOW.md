---
scope: package
summary: Stores Channel message logs, indexes, checkpoints, retention state, snapshots, and compatibility leases on the shared DB engine.
---

# Message Database Flow

## Responsibility

`pkg/db/message` owns node-local Channel log persistence on the shared
`pkg/db/internal` engine. It provides canonical Channel leases, atomic append
and follower apply, secondary indexes, checkpoints and history, logical and
physical retention, inspection, and portable backup/restore snapshots.

The compatibility surface maps `pkg/channel` records and offsets to this typed
storage core without transferring shared-engine ownership.

## Boundaries

- Pebble-specific code stays under `pkg/db/internal`; this package must not
  import Pebble directly.
- `MessageDB` owns one registry and physical engine. Each `Channel` or
  `ForChannel` call returns an independently closable lease over a shared
  canonical entry.
- Channel quorum and visibility policy remain in `pkg/channel`; this package
  persists caller-supplied records, progress, and retention state atomically.
- Schema changes follow the parent storage compatibility contract.

## Main Flows

1. Acquiring a Channel reuses one canonical entry; append and follower apply
   transfer its locks/pins to terminal commit ownership, validate sequences and
   duplicates, synchronously commit compatible batches, then publish all rows,
   indexes, checkpoints, history, and frontiers atomically.
   Exact quorum proposals persist versioned authority, command, range,
   predecessor, entry identities, and paired command/range indexes in that same
   synchronous commit; replica HW may advance atomically with its proposal.
2. Reads scan complete primary rows or verified typed indexes, recover LEO
   lazily after reopen/reclamation, and use bounded durable verification for
   idempotency and newest-message lookup. Newest-first primary reads iterate
   natively in reverse and stop while scanning at `Limit` or `MaxBytes`. A
   single-row bounded read first uses the exact durable sequence when supplied;
   a missing row retains predecessor scanning, while corruption and I/O errors
   fail immediately. Unresolved or maximum sequence bounds keep the range scan. Reads
   must never materialize the complete Channel history before truncation.
   Catalog pages follow encoded key order; skip only the exact cursor key.
   Remote client-number lookups additionally cap inspected index entries and
   payload bytes, failing explicitly rather than returning partial matches.
3. Snapshot, backup, restore, truncation, retention, and close stream or mutate
   bounded batches while keeping rows, indexes, catalog, system state, leases,
   and physical engine ownership consistent.

## Invariants and Failure Semantics

- Offline helpers independently read existing columns and verify native proposal
  formats 1 and 2. Format 2 binds message Expire; old format-1 hashes remain
  unchanged. Matched runtimes and full-generation rollback are required after
  format-2 writes. Import adds no empty-key exception, uniqueness relaxation,
  or recovery path and rejects values the native runtime cannot represent.

- A sparse SyncOnce ordinal index (ID 7, complete marker system ID 11) excludes
  internal records from badge rank queries. Existing primary rows are rebuilt in
  bounded batches before the marker is published; channel append ownership
  serializes writers and rank reads. A range count shares one bounded iterator
  across both ranks and proves an empty index once, preserving the retained
  ordinal baseline without caching unread results. Once the complete index is
  proven empty, a constant-size canonical/warm proof avoids repeated storage
  reads while preserving cancellation and engine lifecycle checks. SyncOnce
  staging invalidates it before commit; restore discard and backup-import
  generations fence active and retired entries. All append, replacement, truncate
  and retention paths maintain the index. Portable backups omit the marker and
  rebuild derived entries during import; raw snapshots preserve both together.
  Matched runtimes are required after publication; older writers cannot maintain
  this derived keyspace.
- Sequences are contiguous and monotonic. A durable append updates its primary
  row, global message-ID index, idempotency/client index, sender index, and
  catalog as one atomic unit where applicable.
- A 32,768-entry bounded warm cache retains LEO, idempotency membership, and the
  last committed exact proposal/entry identity across Channel lease reclamation.
  It also shares immutable encoded keys across matching identity generations;
  retained key backing arrays have a separate 16 MiB LRU bound. Reacquisition
  always creates a fresh mutable entry and independently closable lease.
  Fresh exact extensions with node-scoped message-ID allocation proof may
  validate that immutable tail in memory; restart, eviction, replay, recovery,
  suffix mutation, or an invalidated LEO falls back to durable validation.
- Server-allocation proof may skip only existing message-ID reads. In-batch
  duplicate IDs and durable sender/client idempotency remain mandatory.
- Exact retries return only durable, already-durable, definitely-not-written,
  conflict, or outcome-unknown. Durable indexes remain authoritative across
  cache eviction, prefix retention, and reopen; incomplete manifests, chains,
  overlaps, or checkpoints above LEO are corruption.
- Idempotency filter negatives may avoid a read; possible hits always verify
  durable index and message data. Saturation can increase reads, never admit a
  duplicate.
- Caller cancellation stops waiting but cannot release commit-owned locks or
  pins before build, physical commit, publish, or terminal shutdown.
- Retention and truncation remove primary and secondary rows together. Logical
  retention preserves canonical lookup state until physical deletion.
  Suffix cuts never split proposals; recovery replacement is fenced by the
  inspected frontier and atomically replaces complete verified proposal pages.
- Queue-depth publication is monotonic through grouped collection and terminal
  zero. Backup includes committed proposal/entry identities and excludes the
  uncommitted suffix above the selected HW.
- Checkpoint updates are serialized, initialize an explicit zero, never regress
  HW, and preserve epoch and log-start fields.
- Retention reads reuse immutable state in the bounded canonical/warm registry.
  A database-wide generation disables hits/fills during overlapping retention
  mutations, truncation, recovery replacement, discard and either backup import
  path, and invalidates before and after every attempted mutation. Ordinary
  append does not invalidate unchanged retention state; cancellation, close and
  durable decoding errors remain visible.
- Close rejects new work, drains admitted operations and pins, reclaims entries,
  and closes the physical engine exactly once. One lease cannot close another.
- Backup count and content come from one pinned view; restore is exact-retry
  idempotent, conflicts with different state, and cleans partial rows in bounded
  batches before retry.

## Read First

- [Database lifecycle](db.go)
- [Channel lease](channel_log.go)
- [Atomic append](append.go)
- [Secondary indexes](indexes.go)
- [Snapshot state](snapshot.go)

## Update Triggers

Update this file when durable rows or indexes change, lease/registry ownership
changes, commit locking changes, checkpoint or retention semantics change,
backup/restore coverage changes, or the Channel compatibility contract changes.
