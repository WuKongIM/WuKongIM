"""Identical bounded observers for two owned diagnostic source copies."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

def edit(wt, path, before, after, count=1):
    p = wt/path
    text = p.read_text()
    assert text.count(before) == count, (path, before, text.count(before))
    p.write_text(text.replace(before, after))

SELECTOR = '''
func diagnosticOrdinal(records []ch.Record) (int, bool) {
 for _, record := range records {
  suffix, ok := strings.CutPrefix(record.ClientMsgNo, "two-slots-one-remote-leader-c1-")
  if !ok { continue }
  ordinal, err := strconv.Atoi(suffix)
  if err == nil && ordinal >= 0 && ordinal < 64 && suffix == fmt.Sprintf("%03d", ordinal) { return ordinal, true }
 }
 return 0, false
}
'''

BRIDGE = '''
var diagnosticBridges atomic.Uint64

// DiagnosticBoundary is an owned-probe observer, disabled outside runtime tracing.
// It emits only a fixed synthetic ordinal and command identity, never payloads.
func DiagnosticBoundary(phase string, command ch.CommandID, records []ch.Record, err error) {
 if !trace.IsEnabled() { return }
 ordinal, ok := diagnosticOrdinal(records)
 if !ok { return }
 n := diagnosticBridges.Add(1)
 if n > 2048 { if n == 2049 { trace.Log(context.Background(), "wk977.bridge", `{"phase":"cap"}`) }; return }
 data, _ := json.Marshal(map[string]any{"phase":phase, "ordinal":ordinal, "cmd":fmt.Sprintf("%x", command), "error":err != nil})
 trace.Log(context.Background(), "wk977.bridge", string(data))
}

func diagnosticRound(phase string, p durableProposal, voter ch.NodeID, outcome ch.AppendOutcome, result durableRoundResult, quorum int, err error) {
 if !trace.IsEnabled() { return }
 ordinal, ok := diagnosticOrdinal(p.records)
 if !ok { return }
 n := diagnosticEvents.Add(1)
 if n > 2048 { if n == 2049 { trace.Log(context.Background(), "wk977.proposal", `{"phase":"cap"}`) }; return }
 m := p.manifest
 data, _ := json.Marshal(map[string]any{"phase":phase,"ordinal":ordinal,"cmd":fmt.Sprintf("%x", m.CommandID),"digest":fmt.Sprintf("%x",m.Digest),"base":m.BaseOffset,"last":m.LastOffset,"peer":voter,"outcome":uint8(outcome),"durable":outcome.Durable(),"votes":result.durableVotes,"quorum":quorum,"local_durable":result.localDurable,"error":err != nil})
 trace.Log(context.Background(), "wk977.proposal", string(data))
}
'''

for side in ('old', 'new'):
    wt = ROOT/f'.worktrees/issue-977-quorum-boundaries-{side}'
    for path in ('pkg/channel/replication/diagnostic.go','pkg/db/message/diagnostic.go'):
        p=wt/path; text=p.read_text()
        text=text.replace('"runtime/trace"','"runtime/trace"\n"strconv"\n"strings"')
        start=text.index('\tselected := false') if side and 'replication' in path else text.index('\t\tselected := false')
        stop=text.index('\n\tn :=',start) if 'replication' in path else text.index('\n\t\tfor _, proposal :=',start)
        if 'replication' in path:
            text=text[:start]+'ordinal, selected := diagnosticOrdinal(records)\n if !selected { return }'+text[stop:]
            text=text.replace('256','2048').replace('257','2049')
            text=text.replace('"phase": phase,','"phase": phase, "ordinal":ordinal,')
            text+=SELECTOR+BRIDGE
        else:
            selector=SELECTOR.replace('records []ch.Record','rows []MessageRow').replace('range records','range rows')
            # Message row type is discovered below from the typed item.rows slice.
            selector=selector.replace('rows []MessageRow','rows []messageRow')
            text=text[:start]+'ordinal, selected := diagnosticOrdinal(item.rows)\n if !selected { continue }'+text[stop:]
            text=text.replace('256','2048').replace('257','2049')
            text=text.replace('"phase": phase,','"phase": phase, "ordinal":ordinal,')
            text+=selector
        p.write_text(text)
    edit(wt,'pkg/db/internal/engine/diagnostic.go','512','2048')
    edit(wt,'pkg/db/internal/engine/diagnostic.go','513','2049')
    edit(wt,'pkg/channel/replication/quorum_round_state.go',
         '\twrites := []roundWrite{r.reserveLocked(local, roundWriteDirect)}',
         '\tdiagnosticProposal("round_begin", r.proposal.manifest, r.proposal.records, 0, 0, 0)\n\twrites := []roundWrite{r.reserveLocked(local, roundWriteDirect)}')
    edit(wt,'pkg/channel/replication/quorum_round_state.go','\tvar writes []roundWrite\n\tif local',
         '\tdiagnosticRound("vote", r.proposal, voter, c.outcome, r.result, r.quorum, c.err)\n\tvar writes []roundWrite\n\tif local')
    edit(wt,'pkg/channel/replication/quorum_round_state.go','return func() { complete(result, err) }',
         'return func() { diagnosticRound("round_terminal", r.proposal, 0, result.outcome, result, r.quorum, err); complete(result, err) }')
    edit(wt,'pkg/channel/replication/quorum_log.go',
         'l.cfg.Durability, func(result durableRoundResult, err error) {\n\t\tstate.mu.Lock()',
         'l.cfg.Durability, func(result durableRoundResult, err error) {\n\t\tdiagnosticProposal("quorum_callback", round.proposal.manifest, round.proposal.records, 0, 0, 0)\n\t\tstate.mu.Lock()')
    edit(wt,'pkg/channel/replication/quorum_log.go','\t\tcomplete(receipt, err)\n\t})',
         '\t\tdiagnosticProposal("quorum_receipt", round.proposal.manifest, round.proposal.records, 0, 0, 0)\n\t\tcomplete(receipt, err)\n\t})')
    edit(wt,'pkg/channel/worker/quorum_submit.go','\tstarted := time.Now()',
         '\treplication.DiagnosticBoundary("worker_run", task.QuorumCommit.Proposal.CommandID, task.QuorumCommit.Proposal.Records, nil)\n\tstarted := time.Now()')
    edit(wt,'pkg/channel/worker/quorum_submit.go','\t\t\tp.sink.Complete(res)',
         '\t\t\treplication.DiagnosticBoundary("worker_complete", task.QuorumCommit.Proposal.CommandID, task.QuorumCommit.Proposal.Records, res.Err)\n\t\t\tp.sink.Complete(res)\n\t\t\treplication.DiagnosticBoundary("worker_sink_return", task.QuorumCommit.Proposal.CommandID, task.QuorumCommit.Proposal.Records, res.Err)')
    edit(wt,'pkg/channel/reactor/append_flush.go','\t\tsubmitErr = r.submitQuorumCommit',
         '\t\treplication.DiagnosticBoundary("reactor_submit", batch.commandID, batch.records, nil)\n\t\tsubmitErr = r.submitQuorumCommit')
    edit(wt,'pkg/channel/reactor/append.go','"github.com/WuKongIM/WuKongIM/pkg/channel/machine"',
         '"github.com/WuKongIM/WuKongIM/pkg/channel/machine"\n"github.com/WuKongIM/WuKongIM/pkg/channel/replication"')
    edit(wt,'pkg/channel/reactor/append.go','\tcommitErr := result.Err',
         '\treplication.DiagnosticBoundary("reactor_result", batch.commandID, batch.records, result.Err)\n\tcommitErr := result.Err')
    edit(wt,'pkg/channel/reactor/append.go','\tr.completeReplies(rc, decision.Replies, nil)\n\tr.finishAppendInflightBatch(rc, commitErr, now)',
         '\treplication.DiagnosticBoundary("reactor_publish", batch.commandID, batch.records, commitErr)\n\tr.completeReplies(rc, decision.Replies, nil)\n\tr.finishAppendInflightBatch(rc, commitErr, now)')
