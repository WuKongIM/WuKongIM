"""One fixed pair; no retries, no replaced observations or product cache edits."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

LAB=Path(__file__).resolve().parent
REPO=LAB.parents[1]
SOURCE=LAB.parent/'issue-977-darwin-sync-20261001'
DRIVER=REPO/'.worktrees/issue-977-quorum-boundaries-driver'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

assert not (LAB/'execution.json').exists(), 'preserve every original observation'
plan=json.loads((LAB/'plan.json').read_text())
plan['runner_sha256']=sha(Path(__file__))
plan['verifier_before_capture_sha256']=sha(LAB/'verify-boundaries.py')
plan['decoder_sha256']=sha(LAB/'decode-boundaries.py')
plan['source_bindings']={}
for side in ('old','new','driver'):
    wt=REPO/f'.worktrees/issue-977-quorum-boundaries-{side}'
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=wt,text=True)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=wt,text=True).strip()
    binary=LAB/('permission-driver' if side=='driver' else side+'-wukongim')
    plan['source_bindings'][side]={'head':head,'binary_sha256':sha(binary)}
plan['probe_sha256']=sha(SOURCE/'permission-cpu-darwin')
plan['driver_sources']={str(p.relative_to(DRIVER)):sha(p) for p in sorted((DRIVER/'test/e2e/message/send_ban').glob('permission*go'))}
plan['driver_instructions']={p:sha(DRIVER/p) for p in ('AGENTS.md','test/e2e/AGENTS.md','test/e2e/message/AGENTS.md','test/e2e/message/send_ban/AGENTS.md','test/e2e/suite/FLOW.md')}
(LAB/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('WK_E2E_')}
env.update(GOTOOLCHAIN='local',GOWORK='off',GOMAXPROCS='4',WK_E2E_PERMISSION_CPU_PROBE=str(SOURCE/'permission-cpu-darwin'))
with (LAB/'calibration.log').open('x') as f:
    subprocess.run([str(LAB/'permission-driver'),'-test.run','^TestPermissionCPUProbeCalibration$','-test.v','-test.count=1'],cwd=DRIVER,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=30)
execution=[]
for label in plan['fixed_order']:
    e=dict(env,WK_E2E_BINARY=str(LAB/(label+'-wukongim')),WK_E2E_PERMISSION_QUORUM_TRACE='1')
    if label=='old': e.update(WK_E2E_PERMISSION_BASELINE='1',WK_E2E_PERMISSION_BASELINE_REPORT=str(LAB/'old.json'))
    else:e.update(WK_E2E_PERMISSION_COHORTS='1',WK_E2E_PERMISSION_COHORT_REPORT=str(LAB/'new.json'))
    command=[str(LAB/'permission-driver'),'-test.run','^TestPermissionQuorumTracePrefix$','-test.count=1','-test.timeout=4m','-test.v']
    start=now()
    with (LAB/(label+'.log')).open('x') as f:
        run=subprocess.run(command,cwd=DRIVER,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=255)
    execution.append({'label':label,'started_at':start,'finished_at':now(),'command':command,'exit_code':run.returncode})
    (LAB/'execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    print(label,run.returncode,flush=True)
    if run.returncode:raise SystemExit(run.returncode)
