"""Attribute the recorded rotation interval through exact committing goroutines."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

HEADER=re.compile(r'M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)')
STATE=re.compile(r'Resource=Goroutine\((\d+)\).* (\w+)->(\w+)')

def stream(path):
    current=None
    for line in path.open():
        m=HEADER.match(line)
        if m:
            if current:yield current
            current={'g':int(m[3]),'kind':m[4],'time':int(m[5]),'detail':m[6].strip(),'stack':[]}
        elif current and line.strip():current['stack'].append(line.rstrip())
    if current:yield current

def cover(spans,g,lo,hi):
    selected=[]; totals={}
    for s in spans:
        a,b=max(lo,s['begin']),min(hi,s['end'])
        if s['g']!=g or b<=a:continue
        selected.append({'state':s['state'],'begin':a,'end':b})
        totals[s['state']]=totals.get(s['state'],0)+b-a
    selected.sort(key=lambda s:s['begin'])
    assert selected and selected[0]['begin']==lo and selected[-1]['end']==hi, 'incomplete state bounds'
    assert all(a['end']==b['begin'] for a,b in zip(selected,selected[1:])), 'state coverage hole or overlap'
    assert sum(totals.values())==hi-lo
    return {'states_ns':totals,'spans':selected}

def derive(root,label,go):
    root=Path(root);sys.path.insert(0,str(root));v=importlib.import_module('verify-boundaries')
    verdict=v.verify(root,label)
    result={'label':label,'nodes':{},'diagnostic_only':True}
    env=dict(os.environ,GOTOOLCHAIN='local',GOWORK='off')
    for n in (1,2,3):
        es=v.read_events(root/f'{label}.node-{n}.events.txt')
        scheduling=json.loads((root/f'{label}.node-{n}.scheduling.json').read_text())
        lineages=[v.node_lineage(es,o) for o in range(64)]
        rotations=[(o,x) for o,x in enumerate(lineages) if x['physical'][1]['rotation_ns']>0]
        assert rotations, 'no rotation evidence'
        parsed=root/f'{label}.node-{n}.rotation.parsed.txt'
        if not parsed.exists():
            with parsed.open('x') as f:subprocess.run([go,'tool','trace','-d=parsed',str(root/f'{label}.node-{n}.trace')],env=env,stdout=f,stderr=subprocess.PIPE,check=True,timeout=60)
        owned={x['physical'][0]['g'] for _,x in rotations};previous={};spans=[];transitions=[];last=0
        for e in stream(parsed):
            last=max(last,e['time'])
            if e['kind']!='StateTransition':continue
            m=STATE.search(e['detail'])
            if not m or int(m[1]) not in owned or m[2]==m[3]:continue
            g=int(m[1]);old=previous.get(g)
            if old and e['time']>old['time']:spans.append({'g':g,'state':old['state'],'begin':old['time'],'end':e['time']})
            previous[g]={'state':m[3],'time':e['time']}
            transitions.append({**e,'resource_g':g,'before':m[2],'after':m[3]})
        for g,old in previous.items():
            if last>old['time']:spans.append({'g':g,'state':old['state'],'begin':old['time'],'end':last})
        sync_states=[]
        for ordinal,x in enumerate(lineages):
            sb,se=x['wal'][3:5]
            sync_states.append({'ordinal':ordinal,'g':sb['g'],'interval':[sb['time'],se['time']],**cover(scheduling['spans'],sb['g'],sb['time'],se['time'])})
        details=[]
        for ordinal,x in rotations:
            begin,end=x['physical'];append=x['wal'][0];g=begin['g'];lo,hi=begin['time'],append['time']
            close_syncs=[e for e in es if e['category']=='wk977.wal' and e['phase']=='sync_begin' and e['g']==g and lo<=e['time']<=hi and e['stream']!=append['stream']]
            assert len(close_syncs)==1, 'rotation missing exact old-WAL close sync'
            sb=close_syncs[0];se=v.one([e for e in es if e.get('stream')==sb['stream'] and e.get('op')==sb['op']],'sync_end')
            assert not se['error'] and lo<=sb['time']<=se['time']<=hi
            selected=[e for e in transitions if e['resource_g']==g and lo<=e['time']<=hi]
            assert len(selected)<=128 and all(len(e['stack'])<=512 for e in selected)
            syscall_paths=[]
            for e in selected:
                if e['after']!='Syscall':continue
                frames='\n'.join(e['stack'])
                purpose='old_wal_close' if '(*LogWriter).closeInternal' in frames else ('new_wal_create_directory' if '(*StandaloneManager).Create' in frames else 'other')
                syscall_paths.append({'purpose':purpose,'time':e['time'],'stack':e['stack']})
            details.append({'ordinal':ordinal,'g':g,'commit_stats_rotation_ns':end['rotation_ns'],
                            'physical_begin_to_append_ns':hi-lo,'old_wal_close_sync_ns':se['time']-sb['time'],
                            'old_wal_close_markers':[sb,se],'state_coverage':cover(spans,g,lo,hi),
                            'transitions':selected,'syscall_paths':syscall_paths})
        decoded_sha=hashlib.sha256(parsed.read_bytes()).hexdigest()
        assert decoded_sha==scheduling['parsed_sha256'],'independent parse differs from first decode'
        parsed.unlink()
        result['nodes'][n]={'rotations':details,'sync_states':sync_states,'parsed_sha256':decoded_sha}
    return result

if __name__=='__main__':print(json.dumps(derive(sys.argv[1],sys.argv[2],sys.argv[3]),indent=2))
