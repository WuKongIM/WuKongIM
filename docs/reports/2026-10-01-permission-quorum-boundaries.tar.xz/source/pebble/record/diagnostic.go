// Diagnostic-only source copy for Issue #977. No product repair or qualification.
// Events exist only during an operator-owned runtime trace and have a hard cap.
package record

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/trace"
	"sync/atomic"
)

var diagnosticEvents atomic.Uint64

func (w *LogWriter) diagnosticNextOp() uint64 { w.diagnosticOp++; return w.diagnosticOp }
func (w *LogWriter) diagnosticLog(phase string, op uint64, n int, err error) {
	if !trace.IsEnabled() {
		return
	}
	count := diagnosticEvents.Add(1)
	if count > 8192 {
		if count == 8193 {
			trace.Log(context.Background(), "wk977.wal", `{"phase":"cap"}`)
		}
		return
	}
	data, _ := json.Marshal(map[string]any{"phase": phase, "stream": fmt.Sprintf("%p", w), "wal": w.logNum, "op": op, "written": w.diagnosticWritten, "n": n, "error": err != nil})
	trace.Log(context.Background(), "wk977.wal", string(data))
}
func (w *LogWriter) diagnosticWrite(data []byte) error {
	op := w.diagnosticNextOp()
	w.diagnosticLog("write_begin", op, 0, nil)
	n, err := w.w.Write(data)
	w.diagnosticWritten += int64(n)
	w.diagnosticLog("write_end", op, n, err)
	return err
}
