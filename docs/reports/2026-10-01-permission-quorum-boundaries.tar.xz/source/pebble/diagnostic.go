// Diagnostic-only source copy for Issue #977. No product repair or qualification.
// Events exist only during an operator-owned runtime trace and have a hard cap.
package pebble

import (
	"context"
	"encoding/json"
	"fmt"
	"runtime/trace"
	"sync/atomic"
)

var diagnosticAppends atomic.Uint64

func diagnosticAppend(d *DB, b *Batch, end int64) {
	if !trace.IsEnabled() {
		return
	}
	n := diagnosticAppends.Add(1)
	if n > 4096 {
		if n == 4097 {
			trace.Log(context.Background(), "wk977.wal", `{"phase":"cap"}`)
		}
		return
	}
	if w, ok := d.mu.log.writer.(interface{ DiagnosticStream() string }); ok {
		data, _ := json.Marshal(map[string]any{"phase": "append", "db": fmt.Sprintf("%p", d), "seq": uint64(b.SeqNum()), "stream": w.DiagnosticStream(), "end": end})
		trace.Log(context.Background(), "wk977.wal", string(data))
	}
}
