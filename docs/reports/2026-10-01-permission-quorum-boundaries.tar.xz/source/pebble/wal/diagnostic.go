// Diagnostic-only source copy for Issue #977. No product repair or qualification.
// Events exist only during an operator-owned runtime trace and have a hard cap.
package wal

import "fmt"

func (w *standaloneWriter) DiagnosticStream() string { return fmt.Sprintf("%p", w.w) }
