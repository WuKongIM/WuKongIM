"""Reproduce runtime-clock mapping and retain only bounded target-window evidence."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import sys

ART = Path(__file__).parent
label = sys.argv[1]
target = json.loads((ART / f'{label}.plan.json').read_text())['target']
parsed = ART / f'{label}.trace.parsed.txt'
wire = ART / f'{label}.trace.wire.txt'
timelines = json.loads((ART / f'{label}.timelines.json').read_text())
node = next(reply['reply'] for reply in timelines if reply['node_id'] == 2)
stage = next(event for event in node['events'] if event['stage'] == 'replica.leader.local_durable')
at = datetime.datetime.fromisoformat(stage['at'])
end_wall = int(at.timestamp()) * 1_000_000_000 + at.microsecond * 1000
start_wall = end_wall - stage.get('duration', 0)
clocks = []
with wire.open() as stream:
    for line in stream:
        match = re.match(r'ClockSnapshot dt=\d+ mono=(\d+) sec=(\d+) nsec=(\d+)', line)
        if match:
            mono, sec, nsec = map(int, match.groups())
            clocks.append({'mono': mono, 'wall_ns': sec * 1_000_000_000 + nsec})

def events():
    current = None
    with parsed.open() as stream:
        for line in stream:
            if line.startswith('M='):
                if current is not None:
                    yield current
                match = re.match(r'M=(-?\d+) P=(-?\d+) G=(-?\d+) (\w+) Time=(\d+)(.*)', line.rstrip())
                assert match, line
                m, p, g, kind, timestamp, detail = match.groups()
                current = {'m': int(m), 'p': int(p), 'g': int(g), 'kind': kind, 'time': int(timestamp), 'detail': detail, 'stack': []}
            elif current is not None and line.strip():
                current['stack'].append(line.rstrip())
    if current is not None:
        yield current

syncs = []
for event in events():
    if event['kind'] == 'Sync' and 'Trace=' in event['detail']:
        match = re.search(r'Trace=(\d+) Mono=(\d+)', event['detail'])
        trace, mono = map(int, match.groups())
        clock = next(clock for clock in clocks if clock['mono'] == mono)
        syncs.append({**clock, 'trace': trace, 'offset_ns': clock['wall_ns'] - trace})
assert syncs
clock = min(syncs, key=lambda clock: abs(clock['wall_ns'] - start_wall))
start, end = start_wall - clock['offset_ns'], end_wall - clock['offset_ns']
relevant = re.compile(r'(pkg/channel/(replication|worker|reactor)|pkg/db/|cockroachdb/pebble|pkg/workqueue)')
states, spans, selected, ranges = {}, [], [], []
for event in events():
    transition = re.search(r'Resource=Goroutine\((\d+)\).* (\w+)->(\w+)$', event['detail']) if event['kind'] == 'StateTransition' else None
    if transition:
        goroutine, before, after = transition.groups()
        goroutine = int(goroutine)
        previous = states.get(goroutine)
        if previous is not None and before != after:
            overlap = max(0, min(end, event['time']) - max(start, previous['time']))
            if overlap > 0 and relevant.search('\n'.join(previous['stack']) + '\n' + '\n'.join(event['stack'])):
                spans.append({'goroutine': goroutine, 'state': before, 'from': previous['time'], 'to': event['time'], 'duration_ns': event['time'] - previous['time'], 'target_overlap_ns': overlap, 'begin': previous, 'end': event})
        if before != after:
            states[goroutine] = event
    if start <= event['time'] <= end and relevant.search('\n'.join(event['stack'])):
        selected.append(event)
    if start - 100_000_000 <= event['time'] <= end + 100_000_000 and event['kind'].startswith('Range'):
        ranges.append(event)
spans.sort(key=lambda span: span['target_overlap_ns'], reverse=True)
active_spans = sorted((span for span in spans if span['from'] >= start - 1_000_000), key=lambda span: span['target_overlap_ns'], reverse=True)
report = json.loads((ART / f'{label}.report.json').read_text())
case = next(case for case in report['cases'] if case['name'] == 'two-slots-one-remote-leader')
ack = next(ack for ack in case['windows'][0]['acks'] if ack['client_msg_no'] == target)
result = {'label': label, 'target': target, 'trace_id': stage['trace_id'], 'node_id': 2,
          'leader': case['channel_runtime']['leader'], 'passed_functional': report['passed'],
          'target_ack': ack, 'stage': stage, 'runtime_sync_clocks': syncs,
          'clock_note': 'Runtime near-simultaneous time_now/traceClockNow snapshot, plus diagnostics microsecond timestamp rounding; no host-request clock assumption. Offset spread is measured, not a certified bound.',
          'offset_spread_ns': max(clock['offset_ns'] for clock in syncs) - min(clock['offset_ns'] for clock in syncs),
          'target_start_trace_ns': start, 'target_end_trace_ns': end,
          'relevant_transition_count': len(selected), 'span_count': len(spans),
          'spans': spans[:30], 'active_spans': active_spans[:80], 'transitions': selected[:200], 'ranges': ranges[:100],
          'derived_files': {path.name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in [parsed, wire]}}
(ART / f'{label}.analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ['spans', 'active_spans', 'transitions', 'ranges', 'derived_files', 'stage', 'target_ack']}))
for span in active_spans[:10]:
    print(span['goroutine'], span['state'], round(span['duration_ns']/1e6, 3), round(span['target_overlap_ns']/1e6, 3), span['begin']['detail'], ' -> ', span['end']['detail'])
    print('\n'.join(line for line in span['begin']['stack'] if '@' in line)[:700])
