"""Verify retained functional evidence and diagnostic claims, not performance acceptance."""
import hashlib
import json
from pathlib import Path

ART = Path(__file__).parent
expected = {
    'new': ('ec21c1a586941ffd74cfb497f0da4522941bc1a4', '038', True),
    'old': ('424d03eb298b972ec572261d617972eecb5523c5', '038', False),
    'old-rotation': ('424d03eb298b972ec572261d617972eecb5523c5', '003', True),
    'no-coalesce': ('94d3345b9486e0d4d87ef0a8384f6c0fcca6aea2', '003', True),
}
summary = json.loads((ART / 'wal-boundary-summary.json').read_text())
for label, (revision, index, has_rotation) in expected.items():
    plan = json.loads((ART / f'{label}.plan.json').read_text())
    execution = json.loads((ART / f'{label}.execution.json').read_text())
    report = json.loads((ART / f'{label}.report.json').read_text())
    assert plan['runtime_revision'] == report['product_revision'] == revision
    assert plan['binary_sha256'] == report['binary_sha256']
    assert execution['exit_code'] == 0 and report['passed']
    assert execution['trace']['complete_http_response'] and not execution['trace']['oversized']
    assert execution['trace']['bytes'] <= plan['trace_bounds']['bytes']
    assert execution['queries_executed'] == 3 and not execution['query_errors']
    assert execution['empty_owned_tmpdir_removed']
    assert len(report['cases']) == 4
    for case in report['cases']:
        assert len(case['windows']) == 2
        for window in case['windows']:
            assert window['completed'] and len(window['acks']) == 64
            assert all(ack['reason'] == 1 and ack['message_id'] > 0 and ack['message_seq'] > 0 and not ack.get('error') for ack in window['acks'])
        assert len(case['exact_history']) == len(case['expected_history']) == 161
        assert sorted(case['exact_history']) == sorted(case['expected_history'])
        assert len(set(case['expected_history'])) == 161
        assert len(case['after_ban']) == len(case['after_unban']) == 32
        assert all(ack['reason'] == 25 and ack['message_id'] == ack['message_seq'] == 0 for ack in case['after_ban'])
        assert all(ack['reason'] == 1 and ack['message_id'] > 0 and ack['message_seq'] > 0 for ack in case['after_unban'])
    timelines = json.loads((ART / f'{label}.timelines.json').read_text())
    assert sorted(item['node_id'] for item in timelines) == [1, 2, 3]
    for item in timelines:
        assert 'error_type' not in item and len(item['reply']['events']) < 32
        assert all(event['client_msg_no'] == plan['target'] for event in item['reply']['events'])
    proof = summary['runs'][label]
    assert proof['target'].endswith('c1-' + index)
    assert proof['rotation_observed'] == has_rotation
    assert proof['relevant_transition_count'] == len(proof['transitions'])
    assert proof['leader'] == proof['captured_node'] == 2
    if label != 'old':
        assert proof['window_max_client_msg_no'] == proof['target']
    trace_path = ART / f'{label}.node-2.trace'
    if trace_path.exists():
        assert hashlib.sha256(trace_path.read_bytes()).hexdigest() == execution['trace']['sha256']
profiles = json.loads((ART / 'trace-profile-receipt.json').read_text())
assert len(profiles) == 16 and all(item['trace_parser_exit'] == item['pprof_exit'] == 0 for item in profiles)
manifest = ART / 'manifest.json'
if manifest.exists():
    for item in json.loads(manifest.read_text())['files']:
        path = ART / item['path']
        assert path.is_file() and path.stat().st_size == item['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']
print('PASS: four retained functional diagnostics, fixed target/rotation counterfactual, sixteen parsed profiles; comparative acceptance remains FAILED (6/12 sequential rows).')
