"""Freeze separate full-local and bounded-public artifacts without rewriting observations."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ART = Path(__file__).parent
ROOT = ART.parent.parent
DRIVER = ROOT / '.worktrees/issue-977-permission-baseline'
EVIDENCE = ROOT / '.worktrees/issue-977-evidence-split'

def digest(path):
    data = path.read_bytes()
    return {'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def compact(event):
    # Complete selected event header and deduplicated stack lines; no event is invented.
    return {**event, 'stack': list(dict.fromkeys(event['stack']))}

runs = {}
for label in ['new', 'old', 'old-rotation', 'no-coalesce']:
    analysis = json.loads((ART / f'{label}.analysis.json').read_text())
    report = json.loads((ART / f'{label}.report.json').read_text())
    case = next(case for case in report['cases'] if case['name'] == 'two-slots-one-remote-leader')
    window = case['windows'][0]
    assert analysis['relevant_transition_count'] == len(analysis['transitions'])
    transitions = [compact(event) for event in analysis['transitions']]
    rotations = [event for event in transitions if any('(*DB).rotateWAL' in line for line in event['stack'])]
    runs[label] = {
        'target': analysis['target'], 'trace_id': analysis['trace_id'], 'leader': analysis['leader'],
        'captured_node': 2, 'target_ack': analysis['target_ack'], 'leader_stage': analysis['stage'],
        'window_max_client_msg_no': max(window['acks'], key=lambda ack: ack['elapsed_us'])['client_msg_no'],
        'window_max_us': window['sendack_max_us'], 'rotation_observed': bool(rotations),
        'rotation_transition_count': len(rotations),
        'runtime_sync_clocks': analysis['runtime_sync_clocks'], 'clock_note': analysis['clock_note'],
        'offset_spread_ns': analysis['offset_spread_ns'],
        'target_start_trace_ns': analysis['target_start_trace_ns'], 'target_end_trace_ns': analysis['target_end_trace_ns'],
        'relevant_transition_count': len(transitions), 'transitions': transitions,
        'nearby_ranges': [compact(event) for event in analysis['ranges']],
        'derived_text': analysis['derived_files'], 'analysis_file': digest(ART / f'{label}.analysis.json'),
    }
(ART / 'wal-boundary-summary.json').write_text(json.dumps({'comparative_verdict': 'FAILED', 'failed_sequential_rows': 6, 'runs': runs}, indent=2) + '\n')
subprocess.run(['python3', str(ART / 'verify-wal-evidence.py')], check=True)

report = DRIVER / 'docs/reports/2026-10-01-permission-wal-rotation.md'
(ART / report.name).write_bytes(report.read_bytes())
full_files = sorted(path for path in ART.iterdir() if path.is_file() and (
    path.suffix in ['.json', '.py', '.trace', '.pprof', '.bundle', '.md', '.log'] or path.name.endswith('.top.txt')
) and path.name not in ['archive-roundtrip.json', 'wal-archive-receipt.json'])
public_files = [path for path in full_files if path.suffix != '.trace' and not path.name.endswith('.analysis.json') and not path.name.endswith('.analysis-command.log')]

def archive(name, files, scope):
    path = ART / name
    assert not path.exists(), 'Frozen archive must never be overwritten.'
    manifest = {'scope': scope, 'files': [digest(file) for file in files]}
    with path.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            entries = [(file.name, file.read_bytes()) for file in files]
            entries.append(('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode()))
            for filename, data in entries:
                info = tarfile.TarInfo(filename)
                info.size = len(data)
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
    # Independently reopen every member, validate safe flat paths and verify all hashes.
    with tarfile.open(path, 'r:gz') as tar:
        names = tar.getnames()
        assert len(names) == len(set(names)) == len(files) + 1
        assert all(Path(name).name == name and name not in ['.', '..'] for name in names)
        inside = json.load(tar.extractfile('manifest.json'))
        for item in inside['files']:
            data = tar.extractfile(item['path']).read()
            assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
    return {**digest(path), 'members': len(files) + 1, 'scope': scope, 'manifest': manifest}

full = archive('permission-wal-diagnostics-full.tar.gz', full_files, 'Full local evidence including all four raw runtime traces; excludes binaries and large reproducible parsed text dumps.')
public = archive('permission-wal-diagnostics-bounded.tar.gz', public_files, 'Bounded public evidence with complete selected target-window transitions; raw runtime traces and full derived analysis remain in the separate full local archive.')
receipt = {'runtime_candidate': 'ec21c1a586941ffd74cfb497f0da4522941bc1a4', 'driver': 'c0e95b5a45babbd1907c590a9dcdab83e74634a9', 'comparative_verdict': 'FAILED', 'failed_sequential_rows': 6, 'full_local': full, 'bounded_public': public,
           'unchanged_prior_archives': [digest(ROOT / 'tmp/issue-977-sequential-20261001/permission-sequential-evidence.tar.gz'), digest(ROOT / 'tmp/issue-977-sequential-20261001/permission-delivery-followup.tar.gz')]}
(ART / 'wal-archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'full_bytes': full['bytes'], 'public_bytes': public['bytes'], 'full_members': full['members'], 'public_members': public['members']}))
