import json, hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
preview=json.loads((p/"ci-source-parity.json").read_text())["merge_preview_revision"]
rows=[]
for seam in ["channel-append","mixed-send","tcp-sendack"]:
 d=p/"ci-500qps"/f"500qps-{seam}-{preview}-1"
 assert (d/"source.sha").read_text().strip()==preview
 assert json.loads((d/"result.json").read_text())["status"]=="pass"
 a=json.loads((d/"arrival.json").read_text())
 assert a["schema"]=="scheduled-arrival/v1" and a["phase"]=="measurement" and a["qualification"]
 assert len(a["windows"])==3 and len(a["seconds"])==180
 for w in a["windows"]:
  assert w["planned"]==w["started"]==w["completed"]==30000
  assert w["errors"]==w["dropped"]==0 and w["target_per_second"]==500
  assert w["started_per_second"]>=475 and w["scheduled_to_completion_p99_ms"]<=400
 assert sum(w["completed"] for w in a["seconds"])==90000
 assert sum(w["errors"]+w["dropped"] for w in a["seconds"])==0
 host=json.loads((d/"host.json").read_text());cpu=next(x["data"] for x in host["lscpu"] if x["field"]=="CPU(s):")
 assert cpu=="4" and "go1.25.11" in (d/"go-version.txt").read_text()
 profile=None
 if (d/"counters/window.json").exists():
  counter=json.loads((d/"counters/window.json").read_text())
  assert counter["operations"]==90000 and counter["handlers_completed"] and counter["gomaxprocs"]==4 and counter["goos"]=="linux" and counter["goarch"]=="amd64"
  profile=counter["profile_enabled"]
 rows.append({"seam":seam,"source_revision":preview,"artifact_attempt":1,"measurement_windows":3,"completed":90000,"errors":0,"dropped":0,"p99_ms":[w["scheduled_to_completion_p99_ms"] for w in a["windows"]],"binary_sha256":(d/"binary.sha256").read_text().split()[0],"arrival_sha256":hashlib.sha256((d/"arrival.json").read_bytes()).hexdigest(),"visible_cpus":4,"profile_enabled":profile})
r={"run_id":36744694111,"head_revision":"a991974f8d34423b5e59a12bd24e15de21b1a723","merge_preview_revision":preview,"threshold_p99_ms":400,"rows":rows,"all_nine_windows_passed":True,"limitations":"Current prescribed mixed-send seam includes flight recorder/sampler overhead. This is absolute Linux 500 SEND/s qualification, not comparative Darwin CPU evidence or ten-minute nightly/capacity qualification."}
(p/"ci-500qps-verdict.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps(r,indent=2))
