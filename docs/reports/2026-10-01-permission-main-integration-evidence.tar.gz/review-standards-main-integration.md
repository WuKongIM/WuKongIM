# Standards review — current-main integration

Fixed task source `639b7c35f2f8c489a1640e0e59cb41a699623ae0` → clean merge `a991974f8d34423b5e59a12bd24e15de21b1a723`; incoming main `623091def1951fea6746bd9ac3b63a8a9ba30208`. Refs/parents verified. Scope: `git diff 639b7c35..a991974f8`, including the incoming-main/task combination and empty working-copy/untracked scope. Common ancestor is `424d03eb298b972ec572261d617972eecb5523c5`. This is an integration-safety/Standards review, not a performance qualification.

**Documented-standard violations: 0. Actionable Fowler heuristic smells: 0. No confirmed integration blocker.**

Only seven shared documentation files overlap. Every incoming-only file matches main byte-for-byte; every task-only file matches the previous task head. No implementation was manually resolved. Main's demo/archify material was checked for preservation rather than re-reviewed. Both sides' added AGENTS/FLOW/knowledge/Changelog lines survive; manual conflict resolution preserves both Changelog sections. Generated FLOW rows match their source scope, summary and line counts, with no conflict markers.

The protected `.github`/`.agents` trees, including Review Agent policy, match incoming main exactly. Applicable instructions were read directly before package inspection. Fifteen exact merged-source AGENTS/FLOW hashes and the governing architecture, boundedness, testing, lifecycle and protected-policy rules are frozen in `standards-main-integration-instructions.json` outside the worktree.

[Message composition](/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM/.worktrees/issue-977-permission-cohorts/internal/app/wiring.go:797) keeps fresh permission-store/batch ports, policy observers and ordered BatchAdmission while adding main's complete stream-event ports. [Message construction](/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM/.worktrees/issue-977-permission-cohorts/internal/usecase/message/app.go:115) preserves these dependencies alongside main's bounded event slots. Stream orchestration remains in usecase, wire adaptation in access/infra, and composition in app. Its process-level E2E remains in the e2e tier.

Permission/append trace helpers, stages, disabled gates, ordered-prefix scheduling, independent deadline handling and owned cohort lifecycle are unchanged from the reviewed task source. Their source files were compared directly, so no tracing or ownership behavior was lost during integration.

No build or test was run by this reviewer. Relevant merged-source validation and the named FLOW gate require their own receipts. The preserved clean `5b8379497` comparisons remain historical proof for that exact source; they do not establish performance or overall non-regression for `a991974f8`, nor authorize formal review dispatch or merge.
