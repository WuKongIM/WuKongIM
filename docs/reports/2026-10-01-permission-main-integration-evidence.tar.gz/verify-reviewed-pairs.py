import json,hashlib,math
from pathlib import Path
p=Path(__file__).resolve().parent
plan=json.loads((p/"reviewed-pair-plan.json").read_text());execution=json.loads((p/"reviewed-pair-execution.json").read_text())
assert [x["label"] for x in execution]==plan["order"] and all(x["exit_code"]==0 for x in execution)
rows=[];sequential=[];identities=[]
for pair in range(1,4):
 docs=[json.loads((p/f"{side}-reviewed-pair-{pair}.json").read_text()) for side in ["old","new"]]
 a,b=docs
 assert a["harness_sources"]==b["harness_sources"] and a["harness_sha256"]==b["harness_sha256"]
 assert a["cpu_probe_sha256"]==b["cpu_probe_sha256"]==plan["binary_sha256"]["probe"]
 assert a["topology_fingerprint"]==b["topology_fingerprint"]
 for side,j in zip(["old","new"],docs):
  assert j["passed"] and j["product_revision"]==plan[side+"_revision"] and j["binary_sha256"]==plan["binary_sha256"][side]
  assert not j["request_timeline_enabled"] and "profiles" not in j
  assert all(x["Value"]=="false" for x in j["binary_build"]["Settings"] if x["Key"]=="vcs.modified")
  assert j["nodes"]==3 and j["hash_slots"]==256 and j["physical_slots"]==12 and j["message_replicas"]==3 and j["metadata_replicas"]==1
  assert j["node_gomaxprocs"]==j["driver_gomaxprocs"]==4 and j["connections"]==32 and j["sends_per_window"]==64
  identities.append({"pair":pair,"side":side,"revision":j["product_revision"],"report_sha256":hashlib.sha256((p/f"{side}-reviewed-pair-{pair}.json").read_bytes()).hexdigest(),"harness_sources":j["harness_sources"]})
 for node in ["1","2","3"]:
  ca={k:v for k,v in a["node_configs"][node]["overrides"].items() if k!="WK_PLUGIN_SOCKET_PATH"};cb={k:v for k,v in b["node_configs"][node]["overrides"].items() if k!="WK_PLUGIN_SOCKET_PATH"};assert ca==cb
 assert len(a["cases"])==len(b["cases"])==4
 for old,new in zip(a["cases"],b["cases"]):
  assert old["name"]==new["name"] and old["channel"]==new["channel"] and old["ingress"]==new["ingress"]
  assert old["channel_runtime"]==new["channel_runtime"]
  assert old["user_slot"]==new["user_slot"] and old["channel_slot"]==new["channel_slot"]
  for j in [old,new]:
   assert j["final_topology_fingerprint"]==a["topology_fingerprint"]
   assert len(j["exact_history"])==len(set(j["exact_history"]))==161 and set(j["exact_history"])==set(j["expected_history"]) and not j["history_has_more"]
   assert all(x["reason"]==25 and x["message_id"]==x["message_seq"]==0 and not x.get("error") for x in j["after_ban"])
   assert all(x["reason"]==1 and x["message_id"]>0 and x["message_seq"]>0 and not x.get("error") for x in j["after_unban"])
   for w in j["windows"]:
    assert w["completed"] and len(w["acks"])==64 and len({x["client_msg_no"] for x in w["acks"]})==64
    assert all(x["reason"]==1 and x["message_id"]>0 and x["message_seq"]>0 and not x.get("error") for x in w["acks"])
    assert sorted(x["elapsed_us"] for x in w["acks"])[math.ceil(64*.99)-1]==w["sendack_p99_us"]==w["sendack_max_us"]
    assert w["counts"]["plans"]==w["counts"]["messages"]==64 and w["counts"]["facts"]==128
    assert w["counts"]["barrier_failed"]==w["counts"]["admission_busy"]==w["counts"]["cohort_busy"]==0
    before,after=w["cpu_before"],w["cpu_after"];assert before["timebase_numer"]==after["timebase_numer"] and before["timebase_denom"]==after["timebase_denom"]
    assert before["finished_monotonic_ns"]<=after["started_monotonic_ns"] and len(before["processes"])==len(after["processes"])==3
    ticks=0
    for u,v in zip(before["processes"],after["processes"]):
     assert u["pid"]==v["pid"] and u["start_abstime"]==v["start_abstime"] and u["start_abstime"]>0
     assert v["user_ticks"]>=u["user_ticks"] and v["system_ticks"]>=u["system_ticks"]
     ticks+=v["user_ticks"]-u["user_ticks"]+v["system_ticks"]-u["system_ticks"]
    ns=ticks*before["timebase_numer"]/before["timebase_denom"];assert ns>0 and math.isclose(ns,w["cluster_cpu_ns"],rel_tol=1e-12)
  for u,v in zip(old["windows"],new["windows"]):
   assert u["concurrency"]==v["concurrency"]
   row={"pair":pair,"placement":old["name"],"concurrency":u["concurrency"],"old_p99_ms":u["sendack_p99_us"]/1000,"new_p99_ms":v["sendack_p99_us"]/1000,"p99_change_percent":100*(v["sendack_p99_us"]/u["sendack_p99_us"]-1),"old_cpu_ms":u["cluster_cpu_ns"]/1e6,"new_cpu_ms":v["cluster_cpu_ns"]/1e6,"cpu_change_percent":100*(v["cluster_cpu_ns"]/u["cluster_cpu_ns"]-1),"remote_envelopes":[u["counts"]["node_envelopes"],v["counts"]["node_envelopes"]],"local_envelopes":[u["counts"]["local_envelopes"],v["counts"]["local_envelopes"]],"barriers":[u["counts"]["barrier_ok"],v["counts"]["barrier_ok"]]}
   (rows if u["concurrency"]==32 else sequential).append(row)
verdict={"source_revision":plan["new_revision"],"threshold_percent":5,"scope":plan["acceptance_scope"],"identities":identities,"burst_rows":rows,"burst_gate_passed":all(x["p99_change_percent"]<=5 and x["cpu_change_percent"]<=5 for x in rows),"sequential_controls":sequential,"sequential_over_threshold":[x for x in sequential if x["p99_change_percent"]>5 or x["cpu_change_percent"]>5],"capacity_qualified":False,"limits":"64-SEND unpaced single-Channel bursts on shared Darwin host; p99=max; whole-node CPU includes background and cut overhead; one-voter metadata not HA; sequential timing regressions remain explicit; not the unchanged Linux500 SEND/s gate"}
(p/"reviewed-pair-verdict.json").write_text(json.dumps(verdict,indent=2)+"\n")
print(json.dumps({k:v for k,v in verdict.items() if k not in ["identities","sequential_controls"]},indent=2))
