# Spec — main integration increment

Scope: verified clean `639b7c35f2f8c489a1640e0e59cb41a699623ae0` → `a991974f8d34423b5e59a12bd24e15de21b1a723`, integrating main `623091def1951fea6746bd9ac3b63a8a9ba30208`. `git diff HEAD` and untracked discovery were empty. Exact-source instruction and inspected-file digests are frozen in `review-spec-main-integration-instructions.json`.

**0 confirmed Spec findings** in this integration increment.

- Plan lines 65–69 require “Submit selected items in FIFO order” and “retain its full reservation through return.” SEND orchestration, Router, OrderedSubmitter, gateway and Slot cohort implementation are unchanged from the reviewed repair. App construction retains the permission observer, fresh batch/authority stores, submitter and batch admission (`internal/usecase/message/app.go:122–150`); wiring retains both SEND ports (`internal/app/wiring.go:799–847`). No observed merge omission changes FIFO, callback ownership or per-item deadlines.
- Plan lines 86–88 require the existing “all-items context per canonical Channel” and each expired caller's own result. The repaired Router remains byte-identical. Stream notifications use separate optional ports and RPC; `wireMessageEvents` does not replace permission/append capabilities (`internal/app/message_events.go:16–45`). Its synchronous request-owned fanout retains its own admission and inherited five-second context; there is no new background queue sharing OrderedSubmitter callbacks.
- No unrequested behavior attributable to conflict resolution was found. Main-original demo/Archify implementation was excluded from re-review.

**Verification boundary:** Plan line 44 says “Diagnosis timings are not qualification,” and lines 97–99 require an “exact-source three-pair set.” Historical report lines 4/32 explicitly bind measurements to `5b8379497`; the report is unchanged by this merge. Its twelve burst passes and eight sequential regressions remain historical evidence, and cannot qualify `a991974f8`. Line 74's PR/file-count statements are the earlier delivery snapshot; an integration supplement should label them accordingly and record current exact-source gates separately.

This review certifies no new performance, capacity, HA, 500 SEND/s, CI or Issue #977 closure. No builds/tests were run, and pending integration verification was not treated as a permanent implementation omission.
