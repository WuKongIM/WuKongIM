import os,subprocess,json,time
from pathlib import Path
root=Path("/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM")
art=root/"tmp/issue-977-permission-cohorts-20260930"
wd=root/".worktrees/issue-977-permission-cohorts"
base=os.environ.copy()
base.update(GOMODCACHE=str(root/"tmp/issue-977-permission-baseline-20260930/modcache"),GOMAXPROCS="4",GOWORK="off")
runs=[]
for index,candidate in [(1,True),(2,False),(2,True),(3,False),(3,True)]:
    label=("candidate" if candidate else "baseline")+"-paired-"+str(index)
    env=base.copy()
    env["WK_E2E_BINARY"]=str(art/"wukongim-6a1422142") if candidate else str(root/"tmp/issue-977-permission-baseline-20260930/wukongim-424d03eb2")
    if candidate: env.update(WK_E2E_PERMISSION_COHORTS="1",WK_E2E_PERMISSION_COHORT_REPORT=str(art/(label+".json")))
    else: env.update(WK_E2E_PERMISSION_BASELINE="1",WK_E2E_PERMISSION_BASELINE_REPORT=str(art/(label+".json")))
    if candidate and index==3: env["WK_E2E_PERMISSION_BASELINE_PROFILES"]="1"
    cmd=["go","test","-tags=e2e","./test/e2e/message/send_ban","-run","^TestPermissionCaller"+("Cohorts" if candidate else "Baseline")+"$","-count=1","-timeout=4m","-p=1","-v"]
    with (art/(label+".log")).open("w") as log: code=subprocess.call(cmd,cwd=wd,env=env,stdout=log,stderr=subprocess.STDOUT)
    runs.append({"label":label,"exit_code":code,"report":str(art/(label+".json"))})
    (art/"paired-execution.json").write_text(json.dumps(runs,indent=2)+"\n")
    print(label,"exit",code,flush=True)
    # All predetermined runs remain recorded, including failures. No rerun.
