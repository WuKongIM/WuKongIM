# Initial Standards review — Issue #977 cohorts

Fixed product scope: base `fc0905c06f80399635aef0779a5c3e6006bf99c7` → head `6a14221426a418c331aea7cbee596b5350b802ab`; commit `perf(slot): coalesce bounded fresh permission fact cohorts`. Reviewed all 22 files. During review, clean HEAD advanced to `b26e6c859562d9438eed9167c756751551723f6c`; independently reviewed its three-file harness/documentation delta as a supplement. No working-copy or untracked delta remained. Frozen base instruction digests were verified.

## Documented-standard violations: 0

`pkg/slot/proxy/send_permission_cohort.go` keeps raw facts in the existing distributed metadata Store, preserving the root architecture boundary: policy decisions remain outside the proxy. Admission reserves calls/bytes before cloning inputs, with fixed 64-call/4096-fact cohort, 64-active/1024-owned-call/16-MiB credit bounds. The collection deadline is checked under the admission mutex; membership closes before routing or barriers. Managed workers retain existing per-Slot authority, maintenance, snapshot and one failed-group retry behavior.

Cancellation does not release copied facts or credits while a worker can still use them. The final canceled caller joins; completed aligned results retain their credits until that caller resumes. `CloseSendPermissionReads` fences new admission and joins workers. `pkg/cluster/node_lifecycle.go` invokes it before transport/storage closure; restart creates a fresh Store. Failed-start cleanup cannot admit cohort work through Node because `ensureForeground` requires successful startup. Critical lifecycle and ownership constraints have English comments.

Metrics use fixed dimensions, distinguish conservative credits from actual allocator bytes, and wire through composed observers. Changelog, knowledge, spec and applicable FLOW updates describe the resulting behavior. The failure-first plan and red E2E/controlled-contract evidence precede implementation; the implementer also confirmed the metrics unit test preceded production edits. Controlled elapsed-time tests use `integration`; public process E2E remains black-box.

## Actionable heuristic smells: 0

No unnecessary abstraction, scattered policy ownership or actionable duplication was found. The later sampler is fixed to 20-ms cadence/200 observations, canceled and joined, retains unavailable old metrics as absent, and documents scrape overhead and sampled-peak limitations for both comparison sides.

Read-only review; no tests run. First candidate receipt reports PASS against `6a142214…`; this is not evidence for the later sampler source or a capacity qualification. Repeated comparisons, existing scenario regressions and unchanged 500 SEND/s gates remain pending; earlier 4500 SEND/s failure is preserved.
