import os,subprocess,json
from pathlib import Path
root=Path("/Users/tt/Desktop/work/go/WuKongIM-v2/WuKongIM")
art=root/"tmp/issue-977-permission-cohorts-20260930"
records=[]
for candidate in [False,True]:
    label=("candidate" if candidate else "baseline")+"-matched-3"
    env=os.environ.copy()
    for key in list(env):
        if key.startswith("WK_E2E_PERMISSION_"): del env[key]
    env.update(GOMODCACHE=str(root/"tmp/issue-977-permission-baseline-20260930/modcache"),GOMAXPROCS="4",GOWORK="off")
    env["WK_E2E_BINARY"]=str(art/"wukongim-d1deec2b3") if candidate else str(root/"tmp/issue-977-permission-baseline-20260930/wukongim-424d03eb2")
    if candidate: env.update(WK_E2E_PERMISSION_COHORTS="1",WK_E2E_PERMISSION_COHORT_REPORT=str(art/(label+".json")))
    else: env.update(WK_E2E_PERMISSION_BASELINE="1",WK_E2E_PERMISSION_BASELINE_REPORT=str(art/(label+".json")))
    args=["go","test","-tags=e2e","./test/e2e/message/send_ban","-run","^TestPermissionCaller"+("Cohorts" if candidate else "Baseline")+"$","-count=1","-timeout=4m","-p=1","-v"]
    with (art/(label+".log")).open("w") as log: code=subprocess.call(args,cwd=root/".worktrees/issue-977-permission-cohorts",env=env,stdout=log,stderr=subprocess.STDOUT)
    records.append({"label":label,"exit_code":code,"profiles":False})
    (art/"matched-execution.json").write_text(json.dumps(records,indent=2)+"\n")
    print(label,"exit",code,flush=True)
