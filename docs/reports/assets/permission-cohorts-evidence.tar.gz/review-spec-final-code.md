# Spec review — Issue #977 final code

Verified scope: `fc0905c06f80399635aef0779a5c3e6006bf99c7` → `d1deec2b3bc916764699ad9fcf6b9a590c183d10`; four commits, 25 files. Working copy is clean; no untracked files. Sources: Issue #977, send-ban specification, cohort plan. Production Go files are identical to initial `6a14221426a418c331aea7cbee596b5350b802ab`. No code changes or tests by this reviewer.

**0 confirmed code defects, missing implementation requirements, or unauthorized scope findings.**

The seal, independent per-Slot fences/barriers/snapshots, indexed results, one failed-group retry, bounded pre-copy admission, cancellation/publication credit accounting and Node Stop join remain as reviewed. The new assertion directly checks “Canceled callers remain charged until their started work joins” (plan:25–26; `send_permission_cohort_integration_test.go:124–128`) while the surviving barrier is blocked.

The corrected fault preserves “Keep all 192 requests and failure/history assertions” (plan:65–69). `permission_overload_test.go:96–118,123–176,190–200` paces arrivals beyond the collection window, requires positive typed busy across separately recorded admission layers, checks both ownership bounds/drain, all 503/zero IDs, and exact recovery history. The receipt confirms 128 ingress busy, 64 RPCs, receiver peak 64, and only warm/recovered history. No 500 SEND/s gate changed.

For “sample … every 20 ms (at most 200 samples, canceled/joined)” (plan:59–61), the sampler applies equally to both comparison modes, uses request context cancellation, retains errors/missing gauges accurately and joins before assertions (`permission_baseline_test.go:214–220,510–540`). Dashboard units distinguish conservative credits from allocator memory. The slab test uses references instead of copying locks; transport implementation is unchanged.

Verification limits: the inspected existing send-ban log ends PASS (370.852s), and controlled-credit receipt/log pass. These do not certify all final-head gates. The third pair includes extra profiling and local p99 584 versus 341 ms; strict matched no-profile comparison remains outstanding. Exact-head unchanged 500 SEND/s CI and final mandatory-check receipts require completion. Counts/short-burst receipts do not establish CPU cause, capacity, or overturn the earlier 4500 SEND/s failure.

Exact-head instruction SHA-256 freeze:

```json
{
  "AGENTS.md": "d1a79d1ca586c933ee11d984ff3c401e816fc09de13c635febb7fe4d57f50ade",
  "test/e2e/AGENTS.md": "a288a97ffadffb783d47ba373766a78caea1b78ac51b5bdd929585de00f4655c",
  "test/e2e/message/AGENTS.md": "720653e86adc099d8a1e05cba37e3f49ffdbe6e24dfb19b99d6a8a9e7dac98b5",
  "test/e2e/message/send_ban/AGENTS.md": "8943e22dc0f9a4b8d31a38513de3c1d6ef35f9e6f32516231f1072d44a52d8a9",
  "pkg/slot/FLOW.md": "50fa3b3b40af0cba99be178d0bb303a09015a721e33094ff737cff38e838da18",
  "pkg/cluster/FLOW.md": "7805bf0487495f614d282eb4b44f0c923a74c386411c93cf08a098126ef0f2a9",
  "internal/app/FLOW.md": "a198486e92f7b9a120a3a916710daeedf827953d0004307c8909b7bab3bd3cfe",
  "pkg/goroutine/FLOW.md": "5f0a454e44782554d37b6f8ed9cba1eb1662d7a1ba482320cfb9f9f975d5e36e",
  "pkg/db/FLOW.md": "7d4efcb4280d755938455d705a91882a00d84dd6d35610f523fdf51953ffac65",
  "pkg/db/meta/FLOW.md": "5ac4dd50b15f99af41155f6fdd04aa39211a1b0abf3329fc156af6265c60b9e5",
  "test/e2e/suite/FLOW.md": "0c6a02ac8c17899f87c9962a5eda63f82c25dbea356a43743f34bf92eb74073f"
}
```
