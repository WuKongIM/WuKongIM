# Spec review — Issue #977 cohorts, initial

Verified scope: merge-base/base `fc0905c06f80399635aef0779a5c3e6006bf99c7` → HEAD `6a14221426a418c331aea7cbee596b5350b802ab`; one commit, `perf(slot): coalesce bounded fresh permission fact cohorts`, 22 files. Initial working copy was clean; during review, five cancellation-credit assertions were added to `send_permission_cohort_integration_test.go`; that delta was also inspected. No untracked files, product edits or tests by this reviewer. Sources: fetched Issue #977, send-ban specification and cohort plan.

**0 confirmed implementation defects or scope-creep findings.**

The plan requires “Seal precedes route resolution and every barrier” (lines 13–15). Admission checks the arrival cutoff under the same mutex, removes the collecting pointer at seal, then the worker routes only sealed members (`send_permission_cohort.go:94–107,178–199,244`). The existing reader retains independent per-Slot admission, ReadIndex/apply/snapshot/final-fence validation and only one failed-group stale retry.

For “Canceled callers remain charged until their started work joins; result ownership transfers only when the caller resumes” (plan lines 25–26), returned/live/charged state and publication share one mutex (cohort lines 149–163,245–276). Canceled members retain credit while another member executes; final cancellation joins `done`. Finished-but-unscheduled callers retain credit. No double release or stale-success cancellation interleaving was confirmed. The added assertion directly checks both calls/credits while the survivor remains gated; its validation is pending.

For “Close … joins … before Node closes transport or databases” (plan lines 27–28), admission closes before cancellation and WaitGroup join (cohort lines 282–294); Node invokes this before dependency teardown (`node_lifecycle.go:124–126`). Budgets are reserved before cloning, with bounded calls/cohorts/input facts and conservative credits, independently of receiver admission.

Acceptance remains in progress, not permanently missing: source-matched candidate process evidence already shows burst reduction and exact history, while full existing E2E/fault and unchanged 500 SEND/s gates still require final receipts. The old 192-identical-request overload fixture may no longer saturate receiver admission after sharing (`permission_overload_test.go:96–141`); preserve its failure evidence and positive busy/recovery assertions when adapting the workload. Counts alone do not qualify CPU, capacity or the historical failed 4500 SEND/s workload.

Exact-head instruction SHA-256 digests read for this review:

```json
{
  "AGENTS.md": "d1a79d1ca586c933ee11d984ff3c401e816fc09de13c635febb7fe4d57f50ade",
  "pkg/slot/FLOW.md": "50fa3b3b40af0cba99be178d0bb303a09015a721e33094ff737cff38e838da18",
  "pkg/cluster/FLOW.md": "7805bf0487495f614d282eb4b44f0c923a74c386411c93cf08a098126ef0f2a9",
  "internal/app/FLOW.md": "a198486e92f7b9a120a3a916710daeedf827953d0004307c8909b7bab3bd3cfe",
  "pkg/db/FLOW.md": "7d4efcb4280d755938455d705a91882a00d84dd6d35610f523fdf51953ffac65",
  "pkg/db/meta/FLOW.md": "5ac4dd50b15f99af41155f6fdd04aa39211a1b0abf3329fc156af6265c60b9e5",
  "pkg/goroutine/FLOW.md": "5f0a454e44782554d37b6f8ed9cba1eb1662d7a1ba482320cfb9f9f975d5e36e",
  "test/e2e/AGENTS.md": "88c2c1700b0cf6dce979281534b0b14f364e0ecffced3f7e29570a1ee695f900",
  "test/e2e/message/AGENTS.md": "30c42d06a1181a045dd305f4208d5627053137dfdf8530a6fc490ca0d95a9c12",
  "test/e2e/message/send_ban/AGENTS.md": "096cc913265aa4efe8f9850182f69b8cb2de7932f2036bcdd3492187fe968b2d"
}
```
