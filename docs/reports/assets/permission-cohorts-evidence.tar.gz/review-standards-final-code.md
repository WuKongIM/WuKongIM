# Final code Standards review — Issue #977 cohorts

Base: `fc0905c06f80399635aef0779a5c3e6006bf99c7`; HEAD: `d1deec2b3bc916764699ad9fcf6b9a590c183d10` (clean). Reviewed the full 25-file diff plus working-copy/untracked scope (empty), including all additions since initial review. Frozen applicable base AGENTS/FLOW hashes were verified. Production Go files are unchanged from reviewed `6a14221426a418c331aea7cbee596b5350b802ab`.

## Documented-standard violations: 0

Cohort ownership remains within the existing Slot proxy; business policy stays outside it. Admission reserves bounded input/result credits before copying. Seal precedes routing/barriers; per-Slot authority, maintenance and snapshot fences remain intact. Cancellation retains calls/bytes until joined work; live results remain charged until caller transfer. Node Stop closes cohort admission and joins owned work before transport/storage closure; restart constructs a fresh Store. Important lifecycle/budget constraints have English comments.

The new blocked-work integration assertions explicitly require both canceled/live callers to retain calls and credits. Real-time tests remain in integration/E2E tiers. Failure-first evidence and the necessary controlled-port seam are documented; the limited existing slab-test pointer iteration avoids copying `sync.Pool` without changing assertions or transport behavior.

The quorum-loss fixture preserves 192 requests, exact rejection/recovery history and positive saturation evidence. Its documented 5-ms spacing generates separate sealed cohorts; receiver and ingress busy counts stay separate. Both receiver execution and ingress ownership bounds are checked and drained. This fault input change does not alter the 500 SEND/s qualification workload or thresholds. The public 20-ms sampler remains bounded/canceled/joined, and missing old metrics remain absent.

Grafana panels use fixed `kind` dimensions, separate receiver envelopes from ingress calls/cohorts, and identify `budget_bytes` as conservative memory credits, not allocator or receiver-queue bytes. Changelog, knowledge, spec, scenario instructions and applicable FLOW describe current behavior.

## Actionable heuristic smells: 0

No actionable smell beyond documented current responsibilities was found. No unnecessary aggregate service or speculative extension was introduced.

Read-only review; no tests run. Sampled paired functional results do not certify performance: the reported profiling-input mismatch and local-tail increase remain unresolved comparison limits. Strict matched-input comparison, full required checks and unchanged performance gates must retain their actual pending/result status; earlier 4500 SEND/s failure remains failed.
