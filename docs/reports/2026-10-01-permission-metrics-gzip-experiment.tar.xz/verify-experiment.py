import hashlib, json, re, shutil, statistics, subprocess, sys, tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda n: json.loads((root/n).read_text())
manifest = read('manifest.json')
assert len(manifest['files']) <= 128
for name, expected in manifest['files'].items():
    path = root/name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 8*1024*1024
    assert sha(path) == expected, 'manifest mismatch: '+name
assert sha(root/'verify-reviewed-pairs.py') == '90ba64c6dc6af64ca9008fdd7185626ca7e38a2af5811830b47410572d3b70f5'
plan = read('reviewed-pair-plan.json')
assert plan['old_revision'] == '424d03eb298b972ec572261d617972eecb5523c5'
assert plan['new_revision'] == '38d53d3dc555361e1b72bde6ea49a6dd34586f17'
assert plan['harness_revision'] == '2a4a1f4e57a8cb3d5586f10bb1585717c37ea0ab'
assert plan['binary_sha256']['old'] == '24f08c976e52784003bd467635d0a87b1173bcd4ff4e63f3002d6fd0adc844db'
assert plan['binary_sha256']['new'] == '53263101f0bc0ed60ae85be037a414c173af81ef9a3ea8eb267a89b9db5864bc'
assert plan['binary_sha256']['probe'] == '3b111b36e8372d01370bb82bce4efc582a09822394200c586068439dea9e3413'
assert not plan['profiles'] and not plan['timeline'] and not plan['histogram_extra_families']
assert plan['threshold_percent'] == 5 and not plan['qualification']
binding = read('original/harness-source-binding.json')['original']
for side in ['old', 'new']:
    for pair in range(1, 4):
        report = read(f'{side}-reviewed-pair-{pair}.json')
        assert report['harness_sources'] == binding and report['harness_sha256'] == binding['permission_baseline_test.go']
        assert report['product_revision'] == plan[side+'_revision']
# Execute only the exact unchanged original acceptance verifier, in a disposable
# copy. Its expected exit 1 remains a performance failure, not a product pass.
with tempfile.TemporaryDirectory(prefix='wk-gzip-replay-') as td:
    temp = Path(td)
    for name in ['verify-reviewed-pairs.py', 'reviewed-pair-plan.json', 'reviewed-pair-execution.json', *[f'{s}-reviewed-pair-{i}.json' for i in range(1,4) for s in ['old','new']]]:
        shutil.copyfile(root/name, temp/name)
    result = subprocess.run([sys.executable, str(temp/'verify-reviewed-pairs.py')], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert result.returncode == 1 and not result.stderr, result.stderr.decode()[-2000:]
    assert (temp/'reviewed-pair-verdict.json').read_bytes() == (root/'reviewed-pair-verdict.json').read_bytes(), 'changed derived performance verdict'
v = read('reviewed-pair-verdict.json')
assert len(v['sequential_over_threshold']) == 9 and v['burst_gate_passed'] and not v['all_performance_gates_passed']
assert len(v['sequential_controls']) == len(v['burst_rows']) == 12
assert len(read('original/reviewed-pair-verdict.json')['sequential_over_threshold']) == 6
samples = []
for line in (root/'compression-benchmark-final.log').read_text().splitlines():
    m = re.match(r'BenchmarkMetricsScrapeCompression/(\S+)-4\s+200\s+(\d+) ns/op\s+(\d+) wire-B/op\s+(\d+) B/op\s+(\d+) allocs/op', line)
    if m:
        samples.append(dict(zip(['side','ns_per_op','wire_bytes_per_op','allocated_bytes_per_op','allocations_per_op'], [m[1], *[int(x) for x in m.groups()[1:]]])))
assert len(samples) == 6
medians = {side: {key:statistics.median(x[key] for x in samples if x['side']==side) for key in samples[0] if key!='side'} for side in ['upstream-default','product']}
changes = {key:100*(medians['product'][key]/medians['upstream-default'][key]-1) for key in medians['product']}
b = read('benchmark-derived.json')
assert samples == b['samples'] and medians == b['medians'] and changes == b['change_percent'] and not b['qualification']
assert read('red-contract.json')['exit_code'] != 0 and not read('red-contract.json')['production_modified']
assert all(step['exit_code'] == 0 for step in read('build-validation.json'))
assert not read('cleanup.json')['survivors'] and read('cleanup.json')['reruns_or_replacements'] == 0
assert len(read('cleanup.json')['owned_pids']) == 18
assert read('decision.json')['functional_cases_passed'] == 24 and read('decision.json')['send_windows_passed'] == 48
assert read('decision.json')['sequential_rejections'] == 9 and not read('decision.json')['product_delivery_changes']
print(json.dumps({'artifact_verified':True,'functional_cases':24,'send_windows':48,'burst_passed':12,'sequential_rejected':9,'original_verifier_exit':1,'performance_repaired':False,'benchmark_rederived':True}))
