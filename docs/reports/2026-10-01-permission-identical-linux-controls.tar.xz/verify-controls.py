import hashlib, json, math, shutil, statistics, subprocess, sys, tempfile
from pathlib import Path

root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda name: json.loads((root / name).read_text())
OLD = '424d03eb298b972ec572261d617972eecb5523c5'
NEW = '028702ed0c03d72f7566951732fcb2f8b74f4749'
DRIVER = '2a4a1f4e57a8cb3d5586f10bb1585717c37ea0ab'
manifest = read('manifest.json')
assert len(manifest['files']) <= 128
for name, expected in manifest['files'].items():
    path = root / name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 8 * 1024 * 1024
    assert sha(path) == expected, 'manifest mismatch: ' + name
assert sha(root / 'identical/verify-reviewed-pairs.py') == '90ba64c6dc6af64ca9008fdd7185626ca7e38a2af5811830b47410572d3b70f5'
binding = read('identical/harness-source-binding.json')['original']
for name, expected in binding.items():
    assert sha(root / 'sources/driver' / name) == expected
plan = read('identical/reviewed-pair-plan.json')
assert plan['old_revision'] == plan['new_revision'] == OLD
assert plan['harness_revision'] == DRIVER and plan['threshold_percent'] == 5
assert not plan['qualification'] and not plan['profiles'] and not plan['timeline'] and not plan['histogram_extra_families']
assert plan['binary_sha256']['old'] == plan['binary_sha256']['new'] == '24f08c976e52784003bd467635d0a87b1173bcd4ff4e63f3002d6fd0adc844db'
assert plan['binary_sha256']['probe'] == '3b111b36e8372d01370bb82bce4efc582a09822394200c586068439dea9e3413'
assert plan['harness_binary_sha256'] == '558be9a2e88f3ef7de4256c96f578c80f647454d914a45c300c408c2d0b27480'
assert sha(root / 'identical/run-identical.py') == plan['runner_sha256']
assert read('identical/cpu-calibration.json')['exit_code'] == 0
for pair in range(1, 4):
    for side in ['old', 'new']:
        d = read(f'identical/{side}-reviewed-pair-{pair}.json')
        assert d['harness_sources'] == binding and d['harness_sha256'] == binding['permission_baseline_test.go']
        assert not d['cohort_candidate'] and not d['performance_qualified']
# The original acceptance validator remains unchanged and must still fail.
# Replay in a disposable copy so no captured evidence is rewritten.
with tempfile.TemporaryDirectory(prefix='wk-controls-replay-') as td:
    temp = Path(td)
    names = ['verify-reviewed-pairs.py', 'reviewed-pair-plan.json', 'reviewed-pair-execution.json']
    names += [f'{s}-reviewed-pair-{i}.json' for i in range(1, 4) for s in ['old', 'new']]
    for name in names:
        shutil.copyfile(root / 'identical' / name, temp / name)
    r = subprocess.run([sys.executable, str(temp / 'verify-reviewed-pairs.py')], capture_output=True, timeout=30)
    assert r.returncode == 1 and not r.stderr, r.stderr.decode()[-1500:]
    assert (temp / 'reviewed-pair-verdict.json').read_bytes() == (root / 'identical/reviewed-pair-verdict.json').read_bytes()
verdict = read('identical/reviewed-pair-verdict.json')
assert len(verdict['sequential_controls']) == len(verdict['burst_rows']) == 12
assert len(verdict['sequential_over_threshold']) == 8
assert sum(x['p99_change_percent'] > 5 or x['cpu_change_percent'] > 5 for x in verdict['burst_rows']) == 5
assert not verdict['all_performance_gates_passed']
assert len(read('prior/original/reviewed-pair-verdict.json')['sequential_over_threshold']) == 6
assert len(read('prior/gzip/reviewed-pair-verdict.json')['sequential_over_threshold']) == 9

lp = read('linux/plan.json')
assert lp['old_revision'] == OLD and lp['new_revision'] == NEW and lp['driver_revision'] == DRIVER
assert not lp['driver_source_modified'] and not lp['native_cpu_probe'] and not lp['qualification']
assert lp['original_20ms_full_metrics_sampling'] and lp['extra_stage_families'] and not lp['extra_stage_scrapes']
assert lp['image'] == 'sha256:63cacf247cfd45aa03d105a9a86e2811f978514997be98068979ba6e4c2d0534'
assert lp['cpu_limit'] == 4 and lp['memory_limit'] == '4g'
commands = read('linux/command-plan.json')
assert sha(root / 'linux/run-linux.py') == commands['runner_sha256']
execution = read('linux/execution.json')
assert [x['label'] for x in execution] == lp['order'] == ['old-linux-path', 'new-linux-path']
assert all(x['exit_code'] == 0 for x in execution)
assert [x['command'] for x in execution] == [x['command'] for x in commands['commands']]
for row in execution:
    cmd = row['command']
    assert '--cpus=4' in cmd and '--memory=4g' in cmd and '--network=none' in cmd and lp['image'] in cmd
    assert 'WK_E2E_PERMISSION_STAGES=1' in cmd and not any('WK_E2E_PERMISSION_CPU_PROBE' in x for x in cmd)
builds = read('linux/build-receipts.json')
expected_bins = ['5b6da289b2591133a8f85c57b3fa14db9ba854c4616aa057dc27ddb2aebfdd09', 'a3fa89d4261dd66b82d10b8194e6d5bd65a3de289f0205d2a280de4dc1123bce', 'cfa2c8e0b0e2671888c69629b5297ed7bba29522819b098aae1417f4c62ee2d4']
assert [x['binary_sha256'] for x in builds] == expected_bins and all(x['exit_code'] == 0 for x in builds)
docs = [read('linux/' + side + '-linux-path.json') for side in ['old', 'new']]
a, b = docs
assert a['topology_fingerprint'] == b['topology_fingerprint']
for index, d in enumerate(docs):
    assert d['passed'] and not d['performance_qualified'] and d['cohort_candidate'] == bool(index)
    assert d['product_revision'] == [OLD, NEW][index] and d['binary_sha256'] == expected_bins[index]
    assert d['harness_sources'] == binding and d['harness_sha256'] == binding['permission_baseline_test.go']
    assert d['host_os'] == 'linux' and d['host_arch'] == 'arm64'
    assert d['nodes'] == d['message_replicas'] == 3 and d['metadata_replicas'] == 1
    assert d['hash_slots'] == 256 and d['physical_slots'] == 12
    assert d['connections'] == 32 and d['sends_per_window'] == 64 and d['driver_gomaxprocs'] == d['node_gomaxprocs'] == 4
    assert not d['request_timeline_enabled'] and not d['sequential_profiles_enabled'] and not d['sequential_timeline_enabled']
    assert all(x['Value'] == 'false' for x in d['binary_build']['Settings'] if x['Key'] == 'vcs.modified')
    assert 'cpu_probe_sha256' not in d and len(d['cases']) == 4
for node in ['1', '2', '3']:
    configs = [{k:v for k,v in d['node_configs'][node]['overrides'].items() if k != 'WK_PLUGIN_SOCKET_PATH'} for d in docs]
    assert configs[0] == configs[1]

def stage(w, node, family, labels):
    key = 'stage_cut|wukongim_' + family + '_sum|' + labels
    countkey = key.replace('_sum|', '_count|')
    after, before = w['after'][str(node)], w['before'][str(node)]
    count = after.get(countkey, 0) - before.get(countkey, 0)
    if count <= 0:
        return None
    return {'count':count, 'mean_us':(after[key] - before.get(key, 0)) / count * 1e6}

rows = []
for old, new in zip(a['cases'], b['cases']):
    for key in ['name', 'channel', 'ingress', 'channel_runtime', 'user_slot', 'channel_slot']:
        assert old[key] == new[key]
    for c in [old, new]:
        assert c['channel_runtime']['replicas'] == c['channel_runtime']['isr'] == [1, 2, 3]
        assert c['final_topology_fingerprint'] == a['topology_fingerprint']
        assert len(c['exact_history']) == len(set(c['exact_history'])) == 161
        assert set(c['exact_history']) == set(c['expected_history']) and not c['history_has_more']
        assert len(c['after_ban']) == len(c['after_unban']) == 32
        assert all(x['reason'] == 25 and x['message_id'] == x['message_seq'] == 0 and not x.get('error') for x in c['after_ban'])
        assert all(x['reason'] == 1 and x['message_id'] > 0 and x['message_seq'] > 0 and not x.get('error') for x in c['after_unban'])
        assert [w['concurrency'] for w in c['windows']] == [1, 32]
        for w in c['windows']:
            assert w['completed'] and len(w['acks']) == 64 and len({x['client_msg_no'] for x in w['acks']}) == 64
            assert all(x['reason'] == 1 and x['message_id'] > 0 and x['message_seq'] > 0 and not x.get('error') for x in w['acks'])
            assert sorted(x['elapsed_us'] for x in w['acks'])[math.ceil(64 * .99) - 1] == w['sendack_p99_us'] == w['sendack_max_us']
            assert not w.get('cpu_before') and not w.get('cpu_after') and not w.get('cluster_cpu_ns')
            assert w['counts']['plans'] == w['counts']['messages'] == 64 and w['counts']['facts'] == 128
            assert all(w['counts'][k] == 0 for k in ['barrier_failed', 'admission_busy', 'cohort_busy'])
            assert 0 < len(w['cohort_ownership_samples']) <= 200
            assert stage(w, c['ingress'], 'message_permission_duration_seconds', 'result=ok|stage=plan')['count'] == 64
            append_count = stage(w, c['channel_runtime']['leader'], 'channelv2_append_stage_duration_seconds', 'result=ok|stage=runtime_append_wait')['count']
            assert append_count == 64 if w['concurrency'] == 1 else append_count > 0
    for u, v in zip(old['windows'], new['windows']):
        if u['concurrency'] == 1:
            assert all(u['counts'][k] == v['counts'][k] for k in ['node_envelopes', 'local_envelopes', 'barrier_ok', 'slot_groups'])
            assert v['counts']['cohorts'] == v['counts']['cohort_requests'] == 64 and v['counts']['cohort_facts'] == 128
        else:
            assert v['counts']['barrier_ok'] < u['counts']['barrier_ok']
            assert v['counts']['node_envelopes'] + v['counts']['local_envelopes'] < u['counts']['node_envelopes'] + u['counts']['local_envelopes']
        row = {'placement':old['name'], 'concurrency':u['concurrency'], 'p99_change_percent':100 * (v['sendack_p99_us'] / u['sendack_p99_us'] - 1)}
        for side, c, w in [('old', old, u), ('new', new, v)]:
            row[side] = {'p99_ms':w['sendack_p99_us'] / 1000, 'median_ms':statistics.median(x['elapsed_us'] for x in w['acks']) / 1000,
                'elapsed_ms':w['elapsed_ms'], 'sample_count':len(w['cohort_ownership_samples']),
                'rpc':stage(w, c['ingress'], 'message_permission_duration_seconds', 'result=ok|stage=rpc'),
                'append_wait':stage(w, c['channel_runtime']['leader'], 'channelv2_append_stage_duration_seconds', 'result=ok|stage=runtime_append_wait')}
        rows.append(row)
derived = {'qualification':False, 'native_cpu_measured':False, 'rows':rows,
    'sequential_p99_over_five_percent':sum(x['p99_change_percent'] > 5 for x in rows if x['concurrency'] == 1),
    'limits':'One fixed Linux ARM64 pair; scoped completed-population means, not individual request spans. Original Darwin gates remain failed. No CPU integral, Linux AMD64 capacity or causal proof.'}
assert derived['sequential_p99_over_five_percent'] == 2
if '--derive' in sys.argv:
    (root / 'linux-derived.json').write_text(json.dumps(derived, indent=2) + '\n')
else:
    assert derived == read('linux-derived.json')
decision = read('decision.json')
assert not any(decision[k] for k in ['qualification', 'performance_repaired', 'product_runtime_changes', 'original_failures_waived', 'linux_native_cpu_measured'])
assert decision['aa_sequential_rejected'] == 8 and decision['aa_burst_rejected'] == 5 and decision['linux_sequential_p99_over_five_percent'] == 2
assert decision['original_candidate_sequential_failures'] == 6 and decision['rejected_gzip_sequential_failures'] == 9
assert len(read('verification-mutants.json')) == 9 and all(x['rehashed_manifest'] and x['rejected'] and x['exit_code'] != 0 for x in read('verification-mutants.json'))
cleanup = read('cleanup.json')
assert len(cleanup['owned_native_pids']) == 18 and not cleanup['survivors'] and not cleanup['owned_linux_containers'] and cleanup['reruns_or_replacements'] == 0
print(json.dumps({'artifact_verified':True, 'functional_cases':32, 'send_windows':64, 'identical_sequential_rejections':8,
    'identical_burst_rejections':5, 'original_verifier_exit':1, 'linux_sequential_p99_rejections':2,
    'linux_native_cpu_measured':False, 'performance_repaired':False}))
