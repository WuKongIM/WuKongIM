import datetime, hashlib, json, os, subprocess
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parent.parent
driver = repo / '.worktrees/issue-977-darwin-sync-driver'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
plan = json.loads((lab / 'plan.json').read_text())
receipts = json.loads((lab / 'build-receipts.json').read_text())
assert not (lab / 'execution.json').exists(), 'Never overwrite or replace a diagnostic run'
for row in receipts:
    assert row['exit_code'] == 0
    assert sha(lab / (row['side'] + '-linux-arm64')) == row['binary_sha256']
assert subprocess.check_output(['git', '-C', str(driver), 'rev-parse', 'HEAD'], text=True).strip() == plan['driver_revision']
assert not subprocess.check_output(['git', '-C', str(driver), 'status', '--porcelain'], text=True).strip()
bindings = json.loads((lab.parent / 'issue-977-identical-control-20261001/harness-source-binding.json').read_text())['original']
for name, expected in bindings.items():
    path = driver / 'test/e2e/message/send_ban' / ('../../' + name if name.startswith('suite/') else name)
    assert sha(path) == expected

commands = []
for side, label, mode, report_env, test in [
    ('old', 'old-linux-path', 'WK_E2E_PERMISSION_BASELINE', 'WK_E2E_PERMISSION_BASELINE_REPORT', 'TestPermissionCallerBaseline'),
    ('new', 'new-linux-path', 'WK_E2E_PERMISSION_COHORTS', 'WK_E2E_PERMISSION_COHORT_REPORT', 'TestPermissionCallerCohorts'),
]:
    command = ['docker', 'run', '--rm', '--name', 'codex-977-' + label + '-20261001',
        '--label', 'codex.owner=issue-977-linux-path-20261001',
        '--cpus=4', '--memory=4g', '--network=none',
        '--mount', 'type=bind,src=' + str(repo) + ',dst=' + str(repo) + ',readonly',
        '--mount', 'type=bind,src=' + str(lab) + ',dst=' + str(lab),
        '--workdir', str(driver),
        '--env', 'GOMAXPROCS=4', '--env', 'GOWORK=off', '--env', 'GOTOOLCHAIN=local',
        '--env', 'WK_E2E_BINARY=' + str(lab / (side + '-linux-arm64')),
        '--env', mode + '=1', '--env', report_env + '=' + str(lab / (label + '.json')),
        '--env', 'WK_E2E_PERMISSION_STAGES=1', plan['image'], str(lab / 'driver-linux-arm64'),
        '-test.run', '^' + test + '$', '-test.count=1', '-test.timeout=4m', '-test.v']
    commands.append({'label': label, 'command': command})
(lab / 'command-plan.json').write_text(json.dumps({'written_before_execution': now(),
    'runner_sha256': sha(Path(__file__)), 'qualification': False, 'commands': commands}, indent=2) + '\n')
execution = []
for row in commands:
    start = now()
    with (lab / (row['label'] + '.log')).open('x') as out:
        result = subprocess.run(row['command'], cwd=driver, stdout=out, stderr=subprocess.STDOUT, timeout=260)
    execution.append({**row, 'started_at': start, 'finished_at': now(), 'exit_code': result.returncode})
    (lab / 'execution.json').write_text(json.dumps(execution, indent=2) + '\n')
    print(row['label'], result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
