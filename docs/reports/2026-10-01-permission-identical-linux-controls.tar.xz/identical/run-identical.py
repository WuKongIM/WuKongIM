import datetime, hashlib, json, os, subprocess
from pathlib import Path
root = Path(__file__).resolve().parent
repo = root.parent.parent
base = root.parent/'issue-977-darwin-sync-20261001'
driver = repo/'.worktrees/issue-977-darwin-sync-driver'
product = repo/'.worktrees/issue-977-darwin-sync-old'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda wt,*args: subprocess.check_output(['git','-C',str(wt),*args],text=True).strip()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not (root/'reviewed-pair-plan.json').exists(), 'never overwrite evidence'
assert not git(driver,'status','--porcelain') and not git(product,'status','--porcelain')
assert git(driver,'rev-parse','HEAD') == '2a4a1f4e57a8cb3d5586f10bb1585717c37ea0ab'
revision = git(product,'rev-parse','HEAD')
assert revision == '424d03eb298b972ec572261d617972eecb5523c5'
binding=json.loads((root/'harness-source-binding.json').read_text())['original']
for name, expected in binding.items():
    path=driver/'test/e2e/message/send_ban'/('../../'+name if name.startswith('suite/') else name)
    assert sha(path)==expected
info=subprocess.check_output([str(base/'go1.25.11/bin/go'),'version','-m',str(base/'old-wukongim')],env={**os.environ,'GOTOOLCHAIN':'local'},text=True)
assert 'vcs.revision='+revision+'\n' in info and 'vcs.modified=false\n' in info
(root/'product-binary-build.txt').write_text(info)
original=json.loads((base/'reviewed-pair-plan.json').read_text())
plan={**original,'old_revision':revision,'new_revision':revision,'binary_sha256':{'old':sha(base/'old-wukongim'),'new':sha(base/'old-wukongim'),'probe':sha(base/'permission-cpu-darwin')},'harness_binary_sha256':sha(base/'permission-harness'),'started_at':now(),'runner_sha256':sha(Path(__file__)),'diagnostic':'A/A identical-old-binary control','test_mode_both_sides':'TestPermissionCallerBaseline','qualification':False,'scope_note':'Identical frozen old binary and original baseline test on both sides. Legacy old/new report names only satisfy the unchanged verifier format. Fixed full-prefix sampling/CPU/p99 cuts and +5% thresholds; no candidate qualification or waiver of prior failures. No reruns or replacements. Shared Darwin host.'}
assert plan['binary_sha256']['old']=='24f08c976e52784003bd467635d0a87b1173bcd4ff4e63f3002d6fd0adc844db'
(root/'reviewed-pair-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('WK_E2E_')}
env.update({'GOMAXPROCS':'4','GOTOOLCHAIN':'local','GOWORK':'off','WK_E2E_BINARY':str(base/'old-wukongim'),'WK_E2E_PERMISSION_CPU_PROBE':str(base/'permission-cpu-darwin')})
cal=[str(base/'permission-harness'),'-test.run','^TestPermissionCPUProbeCalibration$','-test.count=1','-test.timeout=20s','-test.v']
with (root/'cpu-calibration.log').open('x') as out:r=subprocess.run(cal,cwd=driver,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=25)
(root/'cpu-calibration.json').write_text(json.dumps({'command':cal,'exit_code':r.returncode,'finished_at':now()},indent=2)+'\n')
assert r.returncode==0
execution=[]
for label in plan['order']:
    runenv={**env,'WK_E2E_PERMISSION_BASELINE':'1','WK_E2E_PERMISSION_BASELINE_REPORT':str(root/(label+'.json'))}
    command=[str(base/'permission-harness'),'-test.run','^TestPermissionCallerBaseline$','-test.count=1','-test.timeout=4m','-test.v']
    start=now()
    with (root/(label+'.log')).open('x') as out:r=subprocess.run(command,cwd=driver,env=runenv,stdout=out,stderr=subprocess.STDOUT,timeout=255)
    execution.append({'label':label,'exit_code':r.returncode,'command':command,'report':str(root/(label+'.json')),'started_at':start,'finished_at':now()})
    (root/'reviewed-pair-execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    print(label,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
raise SystemExit(subprocess.call(['python3',str(root/'verify-reviewed-pairs.py')],cwd=root))
